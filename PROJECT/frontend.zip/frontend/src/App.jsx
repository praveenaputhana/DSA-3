import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

// Pages
import Home from './pages/Home';
import AllEvents from './pages/AllEvents';
import EventDetails from './pages/EventDetails';
import BookingPage from './pages/BookingPage';
import MyBookings from './pages/MyBookings';
import MyTickets from './pages/MyTickets';
import NotificationsPage from './pages/NotificationsPage';
import Profile from './pages/Profile';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './components/AdminDashboard';
import BookingConfirmation from './pages/BookingConfirmation';
import PaymentPage from './pages/PaymentPage';
import PaymentSuccessPage from './pages/PaymentSuccessPage';

export default function App() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Scroll to Top on every route transition */}
      <ScrollToTop />

      {/* Background Atmosphere */}
      <div className="bg-mesh" />

      {/* Global Navigation Bar */}
      <Navbar />

      {/* Main Multi-Page Routed Content */}
      <main style={{ flex: 1, position: 'relative', zIndex: 1 }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/events" element={<AllEvents />} />
          <Route path="/events/:id" element={<EventDetails />} />
          <Route path="/events/:id/book" element={<BookingPage />} />
          <Route path="/book/:id" element={<BookingPage />} />
          <Route path="/payment/:orderId" element={<PaymentPage />} />
          <Route path="/pay/:orderId" element={<PaymentPage />} />
          <Route path="/payment-success/:orderId" element={<PaymentSuccessPage />} />
          <Route path="/confirmation/:id" element={<BookingConfirmation />} />
          <Route path="/booking-confirmation/:id" element={<BookingConfirmation />} />
          <Route path="/my-bookings" element={<MyBookings />} />
          <Route path="/my-tickets" element={<MyTickets />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      {/* Global Footer */}
      <Footer />
    </div>
  );
}
