import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Ticket, 
  Calendar, 
  MapPin, 
  Clock, 
  User, 
  Download, 
  Printer, 
  Star, 
  CheckCircle2, 
  AlertTriangle,
  QrCode,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import QRCode from 'qrcode';
import { api } from '../services/api';
import FeedbackModal from '../components/FeedbackModal';

export default function MyTickets() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [feedbackEvent, setFeedbackEvent] = useState(null);
  const [feedbackSuccess, setFeedbackSuccess] = useState('');

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = async () => {
    setLoading(true);
    try {
      const res = await api.getMyTickets();
      const rawTickets = res.tickets || [];

      // Ensure every ticket has a valid high-resolution QR data URL
      const processed = await Promise.all(
        rawTickets.map(async (t) => {
          let qr = t.qrCodeUrl || t.qr_code_image || t.qr_image;
          if (!qr) {
            try {
              qr = await QRCode.toDataURL(t.qrData || t.ticketCode || t.ticket_code || 'TKT-PASS', {
                errorCorrectionLevel: 'H',
                margin: 2,
                width: 320,
                color: { dark: '#0f172a', light: '#ffffff' }
              });
            } catch (err) {
              console.error('QR generation error for ticket:', err);
            }
          }
          return { ...t, qrCodeUrl: qr };
        })
      );

      setTickets(processed);
    } catch (err) {
      console.error('Failed to load tickets:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTicket = (t) => {
    const ev = t.event || {};
    const title = ev.title || t.title || t.event_title || 'Campus Event';
    const venue = ev.venue || t.venue || 'Campus Venue';
    const banner = ev.banner_url || ev.bannerUrl || t.banner_url || t.event_banner_url || '';
    const ticketCode = t.ticketCode || t.ticket_code || 'TKT-PASS';
    const qrImage = t.qrCodeUrl || t.qr_code_image || t.qr_image || '';
    const attendeeName = t.attendee_name || t.attendeeName || 'Attendee';
    const bookingRef = t.bookingReference || t.booking_reference || 'REF-ACTIVE';
    const startTime = ev.start_time || ev.startTime || t.start_time || '09:00';
    const endTime = ev.end_time || ev.endTime || t.end_time || '17:00';

    const dateFormatted = (ev.event_date || t.event_date) ? new Date(ev.event_date || t.event_date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }) : 'Scheduled Date';

    const ticketHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>EventHub Pass - ${ticketCode}</title>
          <meta charset="utf-8">
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #060913; color: #fff; padding: 40px 20px; display: flex; justify-content: center; }
            .ticket-card { width: 100%; max-width: 500px; background: #0e1526; border: 2px dashed #6366f1; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
            .poster { width: 100%; height: 180px; object-fit: cover; }
            .body { padding: 24px; }
            .title { font-size: 20px; font-weight: 800; color: #fff; margin-bottom: 6px; }
            .badge { display: inline-block; background: #10b981; color: #fff; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; margin-bottom: 16px; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; background: rgba(255,255,255,0.03); padding: 14px; border-radius: 12px; font-size: 13px; }
            .grid dt { color: #94a3b8; font-size: 11px; text-transform: uppercase; font-weight: 600; margin-bottom: 2px; }
            .grid dd { color: #fff; font-weight: 600; }
            .qr-box { text-align: center; padding: 18px; background: rgba(0,0,0,0.3); border-radius: 14px; margin-top: 10px; }
            .qr-box img { width: 150px; height: 150px; background: #fff; padding: 10px; border-radius: 10px; display: block; margin: 0 auto 10px; }
            .code { font-family: monospace; font-size: 16px; font-weight: 800; color: #38bdf8; letter-spacing: 1px; }
            .btn-print { margin-top: 20px; width: 100%; padding: 12px; background: #6366f1; color: #fff; border: none; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; }
            @media print { .btn-print { display: none; } body { background: #fff; color: #000; padding: 0; } .ticket-card { border-color: #000; box-shadow: none; } }
          </style>
        </head>
        <body>
          <div class="ticket-card">
            ${banner ? `<img src="${banner}" class="poster" alt="" />` : ''}
            <div class="body">
              <span class="badge">OFFICIAL EVENT PASS</span>
              <h1 class="title">${title}</h1>
              <div class="grid">
                <div><dt>Attendee</dt><dd>${attendeeName}</dd></div>
                <div><dt>Booking Ref</dt><dd>${bookingRef}</dd></div>
                <div><dt>Event Date</dt><dd>${dateFormatted}</dd></div>
                <div><dt>Timing</dt><dd>${startTime} - ${endTime}</dd></div>
                <div style="grid-column: span 2;"><dt>Venue</dt><dd>${venue}</dd></div>
                <div><dt>Status</dt><dd>${t.status}</dd></div>
                <div><dt>Seat</dt><dd>${t.seatIdentifier || t.seat_identifier || 'General'}</dd></div>
              </div>
              <div class="qr-box">
                ${qrImage ? `<img src="${qrImage}" alt="QR Pass" />` : ''}
                <div class="code">${ticketCode}</div>
                <div style="font-size: 11px; color: #94a3b8; margin-top: 4px;">Present at venue entrance for gate check-in</div>
              </div>
              <button class="btn-print" onclick="window.print()">Print / Save PDF</button>
            </div>
          </div>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(ticketHtml);
      printWindow.document.close();
    } else {
      const blob = new Blob([ticketHtml], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `EventHub_Pass_${ticketCode}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="container" style={{ padding: '40px 20px 80px 20px', maxWidth: 900 }}>
      
      {/* Page Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.4rem)', fontWeight: 800, marginBottom: 6 }}>
            My Digital QR Tickets
          </h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
            Present your scannable QR ticket at the campus venue gate for instant check-in
          </p>
        </div>
        <Link to="/my-bookings" className="btn btn-secondary" style={{ fontSize: 13, padding: '8px 16px' }}>
          <span>View All Bookings</span>
        </Link>
      </div>

      {feedbackSuccess && (
        <div style={{
          background: 'rgba(16, 185, 129, 0.15)',
          border: '1px solid rgba(16, 185, 129, 0.4)',
          borderRadius: 10,
          padding: '12px 16px',
          color: '#34d399',
          fontSize: 13,
          marginBottom: 20,
          display: 'flex',
          alignItems: 'center',
          gap: 8
        }}>
          <CheckCircle2 size={18} />
          <span>{feedbackSuccess}</span>
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-dim)' }}>
          Loading your QR tickets from MongoDB...
        </div>
      ) : tickets.length === 0 ? (
        <div className="luxe-card" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <QrCode size={48} color="var(--text-dim)" style={{ marginBottom: 16 }} />
          <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>No Tickets Found</h3>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>
            You do not have any active event tickets yet. Reserve a seat to get an instant digital boarding pass!
          </p>
          <Link to="/events" className="btn btn-primary">
            Explore Events & Book Now
          </Link>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
          {tickets.map((t) => {
            const isActive = t.status === 'ACTIVE';
            const isCheckedIn = t.status === 'CHECKED_IN';
            const isCancelled = t.status === 'CANCELLED';

            const ev = t.event || {};
            const title = ev.title || t.title || t.event_title || 'Campus Event';
            const category = ev.category || t.category || t.event_category || 'Campus Event';
            const venue = ev.venue || t.venue || 'Campus Venue';
            const banner = ev.banner_url || ev.bannerUrl || t.banner_url || t.event_banner_url || '';
            const ticketCode = t.ticketCode || t.ticket_code;
            const bookingRef = t.bookingReference || t.booking_reference || 'REF-N/A';
            const qrImage = t.qrCodeUrl || t.qr_code_image || t.qr_image || '';
            const startTime = ev.start_time || ev.startTime || t.start_time || '09:00 AM';
            const attendeeName = t.attendee_name || t.attendeeName || 'Attendee';

            const eventDateStr = (ev.event_date || t.event_date) ? new Date(ev.event_date || t.event_date).toLocaleDateString([], {
              weekday: 'short',
              month: 'short',
              day: 'numeric',
              year: 'numeric'
            }) : 'Upcoming';

            return (
              <div
                key={t.id || ticketCode}
                className="boarding-pass"
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'minmax(0, 1.8fr) minmax(0, 1.2fr)',
                  opacity: isCancelled ? 0.6 : 1
                }}
              >
                {/* Left Side: Pass Metadata */}
                <div style={{ padding: 28, display: 'flex', flexDirection: 'column', gap: 16, borderRight: '1px dashed rgba(255, 255, 255, 0.15)' }}>
                  
                  {/* Top Status & Brand */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 11, fontWeight: 800, color: '#38bdf8', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                      EventHub Official Boarding Pass
                    </span>
                    <span className={`badge ${isActive ? 'badge-emerald' : isCheckedIn ? 'badge-cyan' : 'badge-rose'}`}>
                      {isActive ? 'Ready for Entry' : isCheckedIn ? 'Checked-In at Venue' : 'Cancelled'}
                    </span>
                  </div>

                  {/* Event Title & Category */}
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: '#a5b4fc', textTransform: 'uppercase', marginBottom: 4 }}>
                      {category}
                    </div>
                    <h2 style={{ fontSize: 20, fontWeight: 800, lineHeight: 1.3, color: '#fff' }}>
                      {title}
                    </h2>
                  </div>

                  {/* Event Grid Details */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, fontSize: 13, color: 'var(--text-muted)' }}>
                    <div>
                      <span style={{ fontSize: 11, color: 'var(--text-dim)', display: 'block', marginBottom: 2 }}>EVENT DATE</span>
                      <strong style={{ color: '#fff', display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Calendar size={14} color="#6366f1" />
                        <span>{eventDateStr}</span>
                      </strong>
                    </div>

                    <div>
                      <span style={{ fontSize: 11, color: 'var(--text-dim)', display: 'block', marginBottom: 2 }}>TIME</span>
                      <strong style={{ color: '#fff', display: 'flex', alignItems: 'center', gap: 6 }}>
                        <Clock size={14} color="#06b6d4" />
                        <span>{startTime}</span>
                      </strong>
                    </div>

                    <div style={{ gridColumn: 'span 2' }}>
                      <span style={{ fontSize: 11, color: 'var(--text-dim)', display: 'block', marginBottom: 2 }}>VENUE</span>
                      <strong style={{ color: '#fff', display: 'flex', alignItems: 'center', gap: 6 }}>
                        <MapPin size={14} color="#10b981" />
                        <span>{venue}</span>
                      </strong>
                    </div>

                    <div>
                      <span style={{ fontSize: 11, color: 'var(--text-dim)', display: 'block', marginBottom: 2 }}>ATTENDEE NAME</span>
                      <strong style={{ color: '#fff', display: 'flex', alignItems: 'center', gap: 6 }}>
                        <User size={14} color="#818cf8" />
                        <span>{attendeeName}</span>
                      </strong>
                    </div>

                    <div>
                      <span style={{ fontSize: 11, color: 'var(--text-dim)', display: 'block', marginBottom: 2 }}>BOOKING REF</span>
                      <strong style={{ color: '#38bdf8' }}>
                        {bookingRef}
                      </strong>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div style={{ marginTop: 'auto', paddingTop: 14, borderTop: '1px solid rgba(255, 255, 255, 0.08)', display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                    <button
                      onClick={() => handleDownloadTicket(t)}
                      className="btn btn-secondary"
                      style={{ fontSize: 12, padding: '6px 14px', display: 'inline-flex', alignItems: 'center', gap: 6 }}
                      title="Download or Print Ticket Pass"
                    >
                      <Download size={14} />
                      <span>Download Ticket</span>
                    </button>

                    <button
                      onClick={() => setFeedbackEvent({ id: t.event_id || ev.id, title })}
                      className="btn btn-secondary"
                      style={{ fontSize: 12, padding: '6px 14px', color: '#fbbf24', borderColor: 'rgba(251, 191, 36, 0.3)' }}
                    >
                      <Star size={14} fill="#fbbf24" />
                      <span>Rate & Review</span>
                    </button>
                  </div>
                </div>

                {/* Right Side: QR Code Pass */}
                <div style={{
                  padding: 24,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: 'rgba(0, 0, 0, 0.25)',
                  textAlign: 'center',
                  gap: 12
                }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-dim)', letterSpacing: '0.05em' }}>
                    SCAN AT ENTRANCE
                  </div>

                  {/* QR Image */}
                  <div style={{
                    padding: 10,
                    background: '#ffffff',
                    borderRadius: 14,
                    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.6)',
                    border: '2px solid #6366f1'
                  }}>
                    {qrImage ? (
                      <img
                        src={qrImage}
                        alt={`QR Code ${ticketCode}`}
                        style={{ width: 140, height: 140, display: 'block', borderRadius: 4 }}
                      />
                    ) : (
                      <div style={{ width: 140, height: 140, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#64748b' }}>
                        <RefreshCw size={24} className="spin-animation" />
                      </div>
                    )}
                  </div>

                  {/* Alphanumeric Code */}
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 800, color: '#38bdf8', letterSpacing: '0.08em' }}>
                      {ticketCode}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 2 }}>
                      1 Ticket • 1 Entry Only
                    </div>
                  </div>

                  {qrImage && (
                    <a
                      href={qrImage}
                      download={`EventHub_QR_${ticketCode}.png`}
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 6,
                        fontSize: 11.5,
                        color: '#38bdf8',
                        textDecoration: 'none',
                        background: 'rgba(56, 189, 248, 0.1)',
                        border: '1px solid rgba(56, 189, 248, 0.3)',
                        padding: '4px 10px',
                        borderRadius: 8,
                        fontWeight: 600
                      }}
                    >
                      <Download size={12} />
                      <span>Save QR Image (.png)</span>
                    </a>
                  )}

                  {isCheckedIn && (
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 4,
                      fontSize: 11,
                      color: '#34d399',
                      fontWeight: 600,
                      background: 'rgba(16, 185, 129, 0.1)',
                      padding: '4px 10px',
                      borderRadius: 'var(--radius-pill)'
                    }}>
                      <CheckCircle2 size={12} />
                      <span>Verified at Gate</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Rating & Feedback Modal */}
      {feedbackEvent && (
        <FeedbackModal
          event={feedbackEvent}
          onClose={() => setFeedbackEvent(null)}
          onSuccess={(msg) => {
            setFeedbackSuccess(msg);
            setTimeout(() => setFeedbackSuccess(''), 4000);
          }}
        />
      )}
    </div>
  );
}
