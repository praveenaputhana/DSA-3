import React, { useState, useEffect } from 'react';
import { Bell, Check, Clock, AlertTriangle, Info, Calendar, Sparkles, CheckCheck, Plus, Send, X, RefreshCw } from 'lucide-react';
import { api, getUser } from '../services/api';

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('ALL');
  const [showBroadcastModal, setShowBroadcastModal] = useState(false);
  const [broadcastLoading, setBroadcastLoading] = useState(false);
  const [actionMsg, setActionMsg] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    message: '',
    type: 'GENERAL'
  });

  const currentUser = getUser();
  const isAdmin = currentUser?.role === 'admin';

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const res = await api.getNotifications();
      setNotifications(res.notifications || []);
    } catch (err) {
      console.error('Failed to load notifications:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkRead = async (id) => {
    try {
      await api.markNotificationRead(id);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    } catch (err) {
      console.error('Failed to mark read:', err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      setActionMsg('All notifications marked as read.');
      setTimeout(() => setActionMsg(''), 3000);
    } catch (err) {
      console.error('Failed to mark all read:', err);
    }
  };

  const handleBroadcast = async (e) => {
    e.preventDefault();
    if (!formData.title || !formData.message) return;

    setBroadcastLoading(true);
    try {
      await api.sendNotification(formData);
      setActionMsg('Campus alert broadcasted successfully!');
      setShowBroadcastModal(false);
      setFormData({ title: '', message: '', type: 'GENERAL' });
      loadNotifications();
      setTimeout(() => setActionMsg(''), 4000);
    } catch (err) {
      alert(err.message || 'Failed to broadcast announcement.');
    } finally {
      setBroadcastLoading(false);
    }
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const filtered = filterType === 'ALL'
    ? notifications
    : notifications.filter(n => n.type === filterType);

  const getBadgeForType = (type) => {
    switch (type) {
      case 'URGENT':
        return <span className="badge badge-rose">Urgent</span>;
      case 'UPDATE':
        return <span className="badge badge-cyan">Update</span>;
      case 'REMINDER':
        return <span className="badge badge-emerald">Reminder</span>;
      default:
        return <span className="badge badge-indigo">Announcement</span>;
    }
  };

  return (
    <div className="container" style={{ padding: '40px 20px 80px 20px', maxWidth: 880 }}>
      
      {/* Page Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
            <h1 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.4rem)', fontWeight: 800 }}>
              Campus Announcements & Alerts
            </h1>
            {unreadCount > 0 && (
              <span className="badge badge-rose" style={{ fontSize: 12 }}>
                {unreadCount} new
              </span>
            )}
          </div>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
            Real-time event updates, venue schedules, booking notifications & campus broadcasts
          </p>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={loadNotifications}
            className="btn btn-secondary"
            style={{ padding: '8px 12px', fontSize: 12 }}
            title="Refresh announcements"
          >
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            <span>Refresh</span>
          </button>

          {unreadCount > 0 && (
            <button
              onClick={handleMarkAllRead}
              className="btn btn-secondary"
              style={{ padding: '8px 14px', fontSize: 12 }}
              title="Mark all as read"
            >
              <CheckCheck size={15} color="#34d399" />
              <span>Mark All Read</span>
            </button>
          )}

          {isAdmin && (
            <button
              onClick={() => setShowBroadcastModal(true)}
              className="btn btn-primary"
              style={{ padding: '8px 16px', fontSize: 12 }}
            >
              <Plus size={15} />
              <span>Broadcast Alert</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['ALL', 'URGENT', 'UPDATE', 'REMINDER', 'GENERAL'].map(t => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`category-pill ${filterType === t ? 'active' : ''}`}
              style={{ padding: '6px 14px', fontSize: 12 }}
            >
              {t === 'ALL' ? 'All Alerts' : t.charAt(0) + t.slice(1).toLowerCase()}
            </button>
          ))}
        </div>
        <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>
          Showing {filtered.length} notification{filtered.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Action Banner */}
      {actionMsg && (
        <div style={{
          background: 'rgba(16, 185, 129, 0.15)',
          border: '1px solid rgba(16, 185, 129, 0.4)',
          borderRadius: 10,
          padding: '12px 16px',
          color: '#34d399',
          fontSize: 13,
          marginBottom: 20,
          display: 'flex',
          alignItems: 'center',
          gap: 8
        }}>
          <CheckCheck size={18} />
          <span>{actionMsg}</span>
        </div>
      )}

      {/* Content Feed */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-dim)' }}>
          <RefreshCw size={24} className="animate-spin" style={{ margin: '0 auto 12px auto' }} />
          <div>Loading campus announcements...</div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="luxe-card" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <Bell size={48} color="var(--text-dim)" style={{ marginBottom: 16 }} />
          <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>No Notifications</h3>
          <p style={{ fontSize: 14, color: 'var(--text-muted)' }}>
            {filterType === 'ALL'
              ? 'You are all caught up! When organizers broadcast announcements or you make bookings, they will appear here.'
              : `No notifications found under the "${filterType}" filter.`}
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {filtered.map(n => {
            const dateStr = new Date(n.created_at).toLocaleString([], {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div
                key={n.id}
                className="luxe-card"
                style={{
                  padding: 20,
                  display: 'flex',
                  gap: 16,
                  alignItems: 'flex-start',
                  borderLeft: !n.is_read ? '4px solid #6366f1' : '1px solid var(--border-subtle)',
                  background: !n.is_read ? 'rgba(99, 102, 241, 0.05)' : 'var(--bg-card)'
                }}
              >
                <div style={{
                  padding: 10,
                  borderRadius: 12,
                  background: !n.is_read ? 'rgba(99, 102, 241, 0.15)' : 'rgba(255, 255, 255, 0.05)',
                  color: n.type === 'URGENT' ? '#f43f5e' : '#38bdf8',
                  flexShrink: 0
                }}>
                  {n.type === 'URGENT' ? <AlertTriangle size={20} /> : <Bell size={20} />}
                </div>

                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6, flexWrap: 'wrap', gap: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      {getBadgeForType(n.type)}
                      {n.event_title && (
                        <span style={{ fontSize: 12, color: '#38bdf8', fontWeight: 600 }}>
                          • {n.event_title}
                        </span>
                      )}
                    </div>
                    <span style={{ fontSize: 12, color: 'var(--text-dim)', display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Clock size={12} />
                      <span>{dateStr}</span>
                    </span>
                  </div>

                  <h3 style={{ fontSize: 16, fontWeight: 700, color: '#fff', marginBottom: 6 }}>
                    {n.title}
                  </h3>

                  <p style={{ fontSize: 14, color: '#cbd5e1', lineHeight: 1.5 }}>
                    {n.message}
                  </p>
                </div>

                {!n.is_read && (
                  <button
                    onClick={() => handleMarkRead(n.id)}
                    className="btn btn-secondary"
                    style={{ padding: '6px 10px', fontSize: 11, flexShrink: 0 }}
                    title="Mark as read"
                  >
                    <Check size={14} />
                    <span>Read</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Admin Broadcast Announcement Modal */}
      {showBroadcastModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.75)',
          backdropFilter: 'blur(6px)',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 20
        }}>
          <div className="luxe-card" style={{ maxWidth: 540, width: '100%', padding: 28, position: 'relative' }}>
            <button
              onClick={() => setShowBroadcastModal(false)}
              style={{
                position: 'absolute',
                top: 20,
                right: 20,
                background: 'transparent',
                border: 'none',
                color: 'var(--text-dim)',
                cursor: 'pointer'
              }}
            >
              <X size={20} />
            </button>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <div style={{
                width: 38,
                height: 38,
                borderRadius: 10,
                background: 'rgba(99, 102, 241, 0.15)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#818cf8'
              }}>
                <Send size={18} />
              </div>
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700, color: '#fff' }}>Broadcast Campus Alert</h3>
                <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Publish an announcement to all attendee feeds</p>
              </div>
            </div>

            <form onSubmit={handleBroadcast}>
              <div style={{ marginBottom: 14 }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 6 }}>
                  Alert Type
                </label>
                <select
                  className="input-field"
                  value={formData.type}
                  onChange={e => setFormData({ ...formData, type: e.target.value })}
                  style={{ width: '100%', background: '#090d16' }}
                >
                  <option value="GENERAL">General Announcement</option>
                  <option value="URGENT">Urgent Alert</option>
                  <option value="UPDATE">Schedule / Venue Update</option>
                  <option value="REMINDER">Event Reminder</option>
                </select>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 6 }}>
                  Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Hackathon Venue Shift to Lab 4"
                  className="input-field"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  style={{ width: '100%' }}
                />
              </div>

              <div style={{ marginBottom: 20 }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 6 }}>
                  Message Content *
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Provide complete instructions or updates for attendees..."
                  className="input-field"
                  value={formData.message}
                  onChange={e => setFormData({ ...formData, message: e.target.value })}
                  style={{ width: '100%', resize: 'vertical' }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button
                  type="button"
                  onClick={() => setShowBroadcastModal(false)}
                  className="btn btn-secondary"
                  disabled={broadcastLoading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={broadcastLoading}
                >
                  {broadcastLoading ? 'Broadcasting...' : 'Publish Announcement'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
