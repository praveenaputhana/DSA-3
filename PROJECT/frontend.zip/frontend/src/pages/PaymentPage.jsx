import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate, useLocation, Link } from 'react-router-dom';
import {
  ArrowLeft,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  Copy,
  Check,
  Clock,
  Send,
  Eye,
  HelpCircle,
} from 'lucide-react';
import { api } from '../services/api';

const PHONEPE_QR_IMAGE = '/phonepe-qr.png';
const UPI_ID = 'puthanapraveena@ibl';
const POLL_INTERVAL_MS = 3000;

export default function PaymentPage() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const initOrder = location.state?.paymentData || null;
  const [order, setOrder] = useState(initOrder);
  const [loading, setLoading] = useState(!initOrder);
  const [error, setError] = useState('');

  const [paymentStatus, setPaymentStatus] = useState('pending');
  const [secondsRemaining, setSecondsRemaining] = useState(600);

  const [txnRef, setTxnRef] = useState('');
  const [refError, setRefError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [refSubmitted, setRefSubmitted] = useState(false);

  const [copied, setCopied] = useState(false);
  const [showRefHelp, setShowRefHelp] = useState(false);

  const pollRef = useRef(null);
  const countdownRef = useRef(null);

  useEffect(() => {
    window.scrollTo(0, 0);
    if (!initOrder && orderId) {
      loadOrder();
    } else if (initOrder) {
      startPolling(initOrder.order_id || orderId);
      startCountdown();
    }
    return () => {
      clearInterval(pollRef.current);
      clearInterval(countdownRef.current);
    };
  }, [orderId]);

  const loadOrder = async () => {
    setLoading(true);
    try {
      const res = await api.checkPaymentStatus(orderId);
      if (res.verified) {
        navigateToSuccess(res);
        return;
      }
      if (res.reference_submitted) {
        setRefSubmitted(true);
        setPaymentStatus('reference_submitted');
      }
      const orderRes = await fetch('/api/payments/order/' + orderId, {
        headers: { Authorization: 'Bearer ' + localStorage.getItem('eventhub_token') },
      });
      const orderData = await orderRes.json();
      if (orderData.success) setOrder(orderData);
    } catch (err) {
      setError(err.message || 'Could not load payment order.');
    } finally {
      setLoading(false);
      startPolling(orderId);
      startCountdown();
    }
  };

  const startPolling = (targetId) => {
    clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const res = await api.checkPaymentStatus(targetId);
        if (res.verified) {
          clearInterval(pollRef.current);
          clearInterval(countdownRef.current);
          navigateToSuccess(res);
          return;
        }
        if (res.reference_submitted) {
          setRefSubmitted(true);
          setPaymentStatus('reference_submitted');
        }
        if (res.status === 'FAILED') {
          clearInterval(pollRef.current);
          setPaymentStatus('failed');
          setError('Your payment reference was rejected or the order expired.');
        }
      } catch (e) {
        // network blip — keep polling
      }
    }, POLL_INTERVAL_MS);
  };

  const startCountdown = () => {
    clearInterval(countdownRef.current);
    countdownRef.current = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(countdownRef.current);
          clearInterval(pollRef.current);
          setPaymentStatus('failed');
          setError('Seat hold expired (10 min). Please book again.');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const navigateToSuccess = (statusRes) => {
    const targetId = statusRes.order_id || orderId;
    navigate('/payment-success/' + targetId, {
      state: {
        orderData: order,
        statusRes,
        bookingId: statusRes.booking_id,
      },
    });
  };

  const handleSubmitReference = async () => {
    const ref = txnRef.trim();
    if (!ref) {
      setRefError('Please enter your UPI transaction reference number.');
      return;
    }
    if (ref.length < 6) {
      setRefError('Reference seems too short. Check your PhonePe / UPI app.');
      return;
    }
    setRefError('');
    setSubmitting(true);
    try {
      const res = await api.submitPaymentReference({
        order_id: order?.order_id || orderId,
        transaction_reference: ref,
        upi_app: 'PhonePe',
      });
      if (res.success) {
        if (res.already_verified) {
          const statusRes = await api.checkPaymentStatus(order?.order_id || orderId);
          navigateToSuccess(statusRes);
          return;
        }
        setRefSubmitted(true);
        setPaymentStatus('reference_submitted');
      } else {
        setRefError(res.message || 'Could not submit reference. Try again.');
      }
    } catch (err) {
      setRefError(err.message || 'Server error. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoApproval = async () => {
    const targetId = order?.order_id || orderId;
    try {
      await api.simulateQrPayment(targetId);
      const res = await api.checkPaymentStatus(targetId);
      if (res.verified) {
        clearInterval(pollRef.current);
        clearInterval(countdownRef.current);
        navigateToSuccess(res);
      }
    } catch (err) {
      setError('Demo error: ' + err.message);
    }
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: '40px 20px', maxWidth: 600, textAlign: 'center' }}>
        <div className="luxe-card" style={{ padding: 52 }}>
          <RefreshCw size={36} color="#6366f1" className="spin-animation" style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>Loading Payment...</h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>Fetching order from backend</p>
        </div>
      </div>
    );
  }

  if (paymentStatus === 'failed') {
    return (
      <div className="container" style={{ padding: '40px 20px', maxWidth: 560, textAlign: 'center' }}>
        <div className="luxe-card" style={{ padding: 44 }}>
          <AlertTriangle size={48} color="#f43f5e" style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 22, fontWeight: 800, color: '#fff', marginBottom: 8 }}>Payment Failed or Expired</h2>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>{error || 'Unable to process this payment.'}</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to="/events" className="btn btn-primary">Browse Events</Link>
            <Link to="/my-bookings" className="btn btn-secondary">My Bookings</Link>
          </div>
        </div>
      </div>
    );
  }

  const ev = order?.event || {};
  const totalAmount = parseFloat(order?.amount || 0);
  const quantity = order?.quantity || 1;
  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeStr = mins + ':' + (secs < 10 ? '0' : '') + secs;

  return (
    <div className="container" style={{ padding: '20px 20px 80px', maxWidth: 720 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
        <Link to={ev.id ? '/book/' + ev.id : '/events'} className="btn btn-secondary"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 13, padding: '7px 14px' }}>
          <ArrowLeft size={15} />
          <span>Back</span>
        </Link>
        <span style={{ fontSize: 12, color: 'var(--text-dim)', fontWeight: 600, letterSpacing: '0.04em' }}>STEP: SCAN &amp; PAY</span>
      </div>

      <div className="luxe-card" style={{ padding: '28px 24px', background: '#0d1424', border: '1.5px solid rgba(99,102,241,0.4)', borderRadius: 22, boxShadow: '0 24px 60px rgba(0,0,0,0.75)' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 10, paddingBottom: 18, borderBottom: '1px solid var(--border-subtle)', marginBottom: 22 }}>
          <div>
            <span style={{ fontSize: 11, fontWeight: 700, color: '#818cf8', textTransform: 'uppercase' }}>Payment For</span>
            <h2 style={{ fontSize: 17, fontWeight: 800, color: '#fff', marginTop: 2 }}>{ev.title || 'Campus Event'}</h2>
            <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>{ev.venue || ''} &bull; {quantity} Ticket(s)</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <span style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>Order ID</span>
            <div style={{ color: '#38bdf8', fontFamily: 'monospace', fontWeight: 700, fontSize: 12 }}>{order?.order_id || orderId}</div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>

          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: 'rgba(109,40,217,0.18)', border: '1.5px solid rgba(109,40,217,0.5)', padding: '6px 22px', borderRadius: 20, color: '#c4b5fd', fontSize: 13, fontWeight: 900, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 14 }}>
            <Smartphone size={15} />
            <span>ACCEPTED HERE &mdash; PhonePe</span>
          </div>

          <div style={{ fontSize: 12, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 700, marginBottom: 2 }}>Scan &amp; Pay Exactly</div>
          <h1 style={{ fontSize: 'clamp(2.4rem,6vw,3.4rem)', fontWeight: 900, color: '#fff', margin: '0 0 18px', lineHeight: 1 }}>&#x20B9;{totalAmount.toFixed(2)}</h1>

          <div style={{ background: '#ffffff', padding: 10, borderRadius: 18, boxShadow: '0 16px 50px rgba(0,0,0,0.9)', border: '3px solid #7c3aed', marginBottom: 16, display: 'inline-block' }}>
            <img src={PHONEPE_QR_IMAGE} alt="PhonePe QR - PUTHANA PRAVEENA" style={{ width: 240, height: 'auto', display: 'block', borderRadius: 8 }} />
          </div>

          <div style={{ background: 'rgba(109,40,217,0.12)', border: '1px solid rgba(109,40,217,0.3)', borderRadius: 14, padding: '10px 22px', marginBottom: 18, minWidth: 230 }}>
            <div style={{ fontSize: 10.5, color: '#c4b5fd', textTransform: 'uppercase', fontWeight: 700, marginBottom: 3, letterSpacing: '0.07em' }}>Pay To</div>
            <div style={{ fontSize: 17, fontWeight: 900, color: '#fff', letterSpacing: '0.04em', marginBottom: 5 }}>PUTHANA PRAVEENA</div>
            <button onClick={() => { navigator.clipboard.writeText(UPI_ID); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
              style={{ background: 'none', border: '1px solid rgba(165,180,252,0.3)', borderRadius: 8, color: '#a5b4fc', fontSize: 12, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 10px' }}>
              {copied ? <Check size={12} color="#34d399" /> : <Copy size={12} />}
              <span>{copied ? 'Copied!' : UPI_ID}</span>
            </button>
          </div>

          <p style={{ fontSize: 13, color: 'var(--text-muted)', maxWidth: 420, lineHeight: 1.6, marginBottom: 18 }}>
            Open <strong style={{ color: '#c4b5fd' }}>PhonePe</strong>, Google Pay, Paytm or BHIM, scan the QR above and pay <strong style={{ color: '#fff' }}>&#x20B9;{totalAmount.toFixed(2)}</strong> exactly. Then enter your transaction ID below.
          </p>

          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12.5, color: secondsRemaining < 120 ? '#fca5a5' : '#fef08a', background: secondsRemaining < 120 ? 'rgba(239,68,68,0.1)' : 'rgba(234,179,8,0.1)', border: '1px solid ' + (secondsRemaining < 120 ? 'rgba(239,68,68,0.3)' : 'rgba(234,179,8,0.3)'), padding: '6px 16px', borderRadius: 20, marginBottom: 22, fontWeight: 600 }}>
            <Clock size={13} />
            <span>Seat hold expires in <strong style={{ fontFamily: 'monospace' }}>{timeStr}</strong></span>
          </div>

          {!refSubmitted ? (
            <div style={{ width: '100%', maxWidth: 460, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(99,102,241,0.25)', borderRadius: 16, padding: '20px', textAlign: 'left' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#e2e8f0' }}>Enter Your Transaction ID</div>
                <button onClick={() => setShowRefHelp(v => !v)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', display: 'flex' }}>
                  <HelpCircle size={16} />
                </button>
              </div>

              {showRefHelp && (
                <div style={{ background: 'rgba(56,189,248,0.08)', border: '1px solid rgba(56,189,248,0.2)', borderRadius: 10, padding: '10px 14px', fontSize: 12, color: '#94a3b8', lineHeight: 1.55, marginBottom: 12 }}>
                  <strong style={{ color: '#38bdf8' }}>Where to find your Transaction ID:</strong><br />
                  PhonePe: Open app &rarr; Transaction History &rarr; Select payment &rarr; Copy the UTR / Reference number.<br />
                  Google Pay: Open app &rarr; View Transaction &rarr; UPI Transaction ID.<br />
                  It usually looks like: 409834012345678 or T24101234ABCD
                </div>
              )}

              <input
                type="text"
                value={txnRef}
                onChange={e => { setTxnRef(e.target.value); setRefError(''); }}
                onKeyDown={e => e.key === 'Enter' && handleSubmitReference()}
                placeholder="e.g. 409834012345678 or T24101234ABCD"
                style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: refError ? '1px solid #f43f5e' : '1px solid rgba(99,102,241,0.35)', borderRadius: 10, padding: '11px 14px', color: '#fff', fontSize: 14, fontFamily: 'monospace', outline: 'none', boxSizing: 'border-box' }}
              />
              {refError && <div style={{ fontSize: 12, color: '#f87171', marginTop: 6 }}>{refError}</div>}

              <button
                type="button"
                onClick={handleSubmitReference}
                disabled={submitting}
                style={{ marginTop: 12, width: '100%', padding: '13px 0', background: submitting ? 'rgba(99,102,241,0.4)' : 'linear-gradient(135deg,#6366f1 0%,#4f46e5 100%)', border: 'none', borderRadius: 12, color: '#fff', fontSize: 15, fontWeight: 800, cursor: submitting ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: '0 6px 24px rgba(99,102,241,0.4)' }}
              >
                {submitting ? <RefreshCw size={16} className="spin-animation" /> : <Send size={16} />}
                <span>{submitting ? 'Submitting...' : 'Submit Transaction Reference'}</span>
              </button>

              <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11.5, color: 'var(--text-dim)', marginTop: 10 }}>
                <ShieldCheck size={13} color="#10b981" />
                <span>Admin reviews your reference. Page auto-advances once verified.</span>
              </div>
            </div>
          ) : (
            <div style={{ width: '100%', maxWidth: 460, background: 'rgba(234,179,8,0.07)', border: '1.5px solid rgba(234,179,8,0.4)', borderRadius: 16, padding: '22px 20px', textAlign: 'center' }}>
              <div style={{ width: 54, height: 54, borderRadius: '50%', background: 'rgba(234,179,8,0.15)', border: '2px solid rgba(234,179,8,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
                <Eye size={26} color="#facc15" />
              </div>
              <h3 style={{ fontSize: 18, fontWeight: 900, color: '#fff', marginBottom: 6 }}>Pending Verification</h3>
              <div style={{ fontSize: 12, color: '#fef08a', background: 'rgba(234,179,8,0.12)', border: '1px solid rgba(234,179,8,0.3)', padding: '4px 14px', borderRadius: 10, fontFamily: 'monospace', fontWeight: 700, display: 'inline-block', marginBottom: 10 }}>
                REF: {txnRef}
              </div>
              <p style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.6, marginBottom: 14, maxWidth: 380, margin: '0 auto 14px' }}>
                Your reference was submitted. This page will <strong style={{ color: '#fff' }}>automatically advance</strong> once admin approves.
              </p>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: 'rgba(234,179,8,0.1)', border: '1px solid rgba(234,179,8,0.3)', padding: '7px 18px', borderRadius: 20, color: '#fef08a', fontSize: 13, fontWeight: 600 }}>
                <RefreshCw size={13} className="spin-animation" color="#facc15" />
                <span>Checking automatically every 3 seconds...</span>
              </div>
            </div>
          )}

          <div style={{ marginTop: 24, padding: '12px 18px', background: 'rgba(255,255,255,0.02)', border: '1px dashed rgba(255,255,255,0.12)', borderRadius: 12, width: '100%', maxWidth: 460 }}>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 7, textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.06em' }}>
              Evaluation / Demo Mode
            </div>
            <button type="button" onClick={handleDemoApproval} className="btn btn-secondary"
              style={{ padding: '7px 16px', fontSize: 12, color: '#38bdf8', borderColor: 'rgba(56,189,248,0.4)' }}>
              Simulate Bank Approval &amp; Proceed
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
