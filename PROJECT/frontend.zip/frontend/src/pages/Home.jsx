import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Sparkles, 
  ArrowRight, 
  Calendar, 
  QrCode, 
  ShieldCheck, 
  Users, 
  Search, 
  CheckCircle2, 
  Zap,
  TrendingUp
} from 'lucide-react';
import { api, getUser } from '../services/api';
import EventCard from '../components/EventCard';
import BookingModal from '../components/BookingModal';

export default function Home() {
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [bookingEvent, setBookingEvent] = useState(null);
  const [searchKeyword, setSearchKeyword] = useState('');
  const navigate = useNavigate();
  const currentUser = getUser();

  useEffect(() => {
    loadHomeData();
  }, []);

  const loadHomeData = async () => {
    setLoading(true);
    try {
      const [eventsRes, catsRes] = await Promise.all([
        api.getEvents(),
        api.getCategories()
      ]);
      setEvents(eventsRes.events || []);
      setCategories(catsRes.categories || []);
    } catch (err) {
      console.error('Failed to load home data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchKeyword.trim()) {
      navigate(`/events?search=${encodeURIComponent(searchKeyword.trim())}`);
    } else {
      navigate('/events');
    }
  };

  // Top featured hackathons and technical events
  const featuredEvents = events.filter(e => 
    (e.category && (e.category.toLowerCase().includes('hackathon') || e.category.toLowerCase().includes('contest') || e.category.toLowerCase().includes('workshop')))
  ).slice(0, 3);

  const upcomingPreview = events.slice(0, 6);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 64, paddingBottom: 60 }}>
      
      {/* 1. HERO SECTION */}
      <section style={{
        position: 'relative',
        padding: '70px 0 50px 0',
        overflow: 'hidden'
      }}>
        <div className="container" style={{ textAlign: 'center', maxWidth: 920 }}>
          
          {/* Top Announcement Pill */}
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            padding: '6px 16px',
            borderRadius: 'var(--radius-pill)',
            background: 'rgba(99, 102, 241, 0.12)',
            border: '1px solid rgba(99, 102, 241, 0.3)',
            marginBottom: 24,
            fontSize: 13,
            color: '#a5b4fc',
            fontWeight: 600,
            boxShadow: '0 0 15px rgba(99, 102, 241, 0.2)'
          }}>
            <Sparkles size={16} color="#38bdf8" />
            <span>Campus Event Management & Attendee Self-Service Platform</span>
          </div>

          {/* Main Title */}
          <h1 style={{
            fontSize: 'clamp(2.4rem, 5vw, 4rem)',
            fontWeight: 900,
            lineHeight: 1.15,
            marginBottom: 20,
            letterSpacing: '-0.03em'
          }}>
            Experience Campus Life With <br />
            <span style={{
              background: 'linear-gradient(135deg, #6366f1 0%, #38bdf8 50%, #34d399 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Instant Self-Service & Digital Passports
            </span>
          </h1>

          {/* Subtitle */}
          <p style={{
            fontSize: 'clamp(1rem, 2vw, 1.2rem)',
            color: 'var(--text-muted)',
            lineHeight: 1.6,
            marginBottom: 36,
            maxWidth: 720,
            margin: '0 auto 36px auto'
          }}>
            Discover technical hackathons, coding contests, workshops, and cultural fests.
            Reserve seats in real-time and generate tamper-proof digital tickets with unique QR verification.
          </p>

          {/* Quick Search Form */}
          <form
            onSubmit={handleSearchSubmit}
            style={{
              display: 'flex',
              alignItems: 'center',
              background: '#0b1324',
              border: '1px solid rgba(255, 255, 255, 0.12)',
              borderRadius: 'var(--radius-pill)',
              padding: '6px 8px 6px 20px',
              maxWidth: 580,
              margin: '0 auto 32px auto',
              boxShadow: '0 12px 32px rgba(0, 0, 0, 0.5)'
            }}
          >
            <Search size={18} color="var(--text-dim)" style={{ marginRight: 10, flexShrink: 0 }} />
            <input
              type="text"
              placeholder="Search hackathons, coding, AI workshops, venues..."
              value={searchKeyword}
              onChange={e => setSearchKeyword(e.target.value)}
              style={{
                flex: 1,
                background: 'transparent',
                border: 'none',
                color: '#fff',
                fontSize: 14,
                outline: 'none'
              }}
            />
            <button type="submit" className="btn btn-cyan" style={{ padding: '10px 22px' }}>
              <span>Search</span>
            </button>
          </form>

          {/* CTA Action Buttons */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 14, flexWrap: 'wrap' }}>
            <Link to="/events" className="btn btn-primary" style={{ padding: '12px 28px', fontSize: 15 }}>
              <span>Explore All Events</span>
              <ArrowRight size={18} />
            </Link>

            {currentUser ? (
              <Link to="/my-tickets" className="btn btn-emerald" style={{ padding: '12px 28px', fontSize: 15 }}>
                <QrCode size={18} />
                <span>My QR Tickets</span>
              </Link>
            ) : (
              <Link to="/register" className="btn btn-secondary" style={{ padding: '12px 28px', fontSize: 15 }}>
                <span>Create Free Account</span>
              </Link>
            )}

            {currentUser && currentUser.role === 'admin' && (
              <Link to="/admin" className="btn btn-cyan" style={{ padding: '12px 28px', fontSize: 15 }}>
                <ShieldCheck size={18} />
                <span>Manage Events</span>
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* 2. CATEGORIES CHIP BAR */}
      <section className="container">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 style={{ fontSize: 18, fontWeight: 700, color: '#fff' }}>Browse by Category</h3>
          <Link to="/events" style={{ fontSize: 13, color: '#38bdf8', fontWeight: 600 }}>
            View All ({categories.length}) →
          </Link>
        </div>

        <div style={{
          display: 'flex',
          gap: 10,
          overflowX: 'auto',
          paddingBottom: 8,
          scrollbarWidth: 'none'
        }}>
          <button
            onClick={() => navigate('/events')}
            className="category-pill active"
          >
            All Categories
          </button>
          {categories.map(cat => (
            <button
              key={cat.id || cat.name}
              onClick={() => navigate(`/events?category=${encodeURIComponent(cat.name)}`)}
              className="category-pill"
            >
              {cat.name}
            </button>
          ))}
        </div>
      </section>

      {/* 3. FEATURED HACKATHONS SECTION */}
      {featuredEvents.length > 0 && (
        <section className="container">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
            <div style={{
              padding: 8,
              borderRadius: 10,
              background: 'rgba(99, 102, 241, 0.15)',
              color: '#818cf8'
            }}>
              <Zap size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: 22, fontWeight: 800 }}>Featured Hackathons & Technical Summits</h2>
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                Premier campus competitions with 24-hr prototyping and real-time seat reservations
              </p>
            </div>
          </div>

          <div className="grid-events">
            {featuredEvents.map(event => (
              <EventCard
                key={event.id || event._id}
                event={event}
              />
            ))}
          </div>
        </section>
      )}

      {/* 4. UPCOMING EVENTS GRID */}
      <section className="container">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }}>
          <div>
            <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>Upcoming Campus Events</h2>
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
              Real-time seat quotas tracked in MongoDB database
            </p>
          </div>
          <Link to="/events" className="btn btn-secondary" style={{ fontSize: 13, padding: '8px 16px' }}>
            <span>Explore Events</span>
            <ArrowRight size={14} />
          </Link>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-dim)' }}>
            Loading events from MongoDB database...
          </div>
        ) : events.length === 0 ? (
          <div className="luxe-card" style={{ textAlign: 'center', padding: 48 }}>
            <Calendar size={48} color="var(--text-dim)" style={{ marginBottom: 12 }} />
            <h4 style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>No Events Available</h4>
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
              Please run the database seed script to populate sample campus events.
            </p>
          </div>
        ) : (
          <div className="grid-events">
            {upcomingPreview.map(event => (
              <EventCard
                key={event.id || event._id}
                event={event}
              />
            ))}
          </div>
        )}
      </section>

      {/* 5. VALUE PROPOSITION TILES */}
      <section className="container">
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: 24
        }}>
          <div className="luxe-card" style={{ padding: 28 }}>
            <div style={{
              width: 48,
              height: 48,
              borderRadius: 14,
              background: 'rgba(99, 102, 241, 0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#818cf8',
              marginBottom: 16
            }}>
              <QrCode size={24} />
            </div>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Digital QR Boarding Passes</h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.6 }}>
              Instant unique ticket generation upon reservation. Download or display on your mobile phone for frictionless check-in.
            </p>
          </div>

          <div className="luxe-card" style={{ padding: 28 }}>
            <div style={{
              width: 48,
              height: 48,
              borderRadius: 14,
              background: 'rgba(6, 182, 212, 0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#06b6d4',
              marginBottom: 16
            }}>
              <CheckCircle2 size={24} />
            </div>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Strict Duplicate Prevention</h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.6 }}>
              Guaranteed event security: Once checked in at the gate, duplicate entries are blocked immediately with exact audit timestamps.
            </p>
          </div>

          <div className="luxe-card" style={{ padding: 28 }}>
            <div style={{
              width: 48,
              height: 48,
              borderRadius: 14,
              background: 'rgba(16, 185, 129, 0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#10b981',
              marginBottom: 16
            }}>
              <Users size={24} />
            </div>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Atomic Capacity Control</h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.6 }}>
              MongoDB transactional concurrency control ensures zero overbooking, with automatic seat restoration when bookings are cancelled.
            </p>
          </div>
        </div>
      </section>

      {/* Value proposition section end */}
    </div>
  );
}
