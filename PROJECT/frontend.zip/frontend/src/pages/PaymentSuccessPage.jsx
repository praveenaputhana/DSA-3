import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation, Link } from 'react-router-dom';
import {
  CheckCircle,
  Calendar,
  MapPin,
  Clock,
  Ticket,
  RefreshCw,
  AlertTriangle,
  CreditCard,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import { api, getUser } from '../services/api';

export default function PaymentSuccessPage() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const currentUser = getUser();

  const passedOrder = location.state?.orderData || null;
  const passedStatus = location.state?.statusRes || null;
  const passedBookingId = location.state?.bookingId || null;

  const [order, setOrder] = useState(passedOrder);
  const [statusData, setStatusData] = useState(passedStatus);
  const [loading, setLoading] = useState(!passedOrder || !passedStatus);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
    if (!passedOrder || !passedStatus) {
      loadData();
    }
  }, [orderId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [statusRes, orderRes] = await Promise.all([
        api.checkPaymentStatus(orderId),
        fetch('/api/payments/order/' + orderId, {
          headers: { Authorization: 'Bearer ' + localStorage.getItem('eventhub_token') },
        }).then(r => r.json()),
      ]);
      setStatusData(statusRes);
      if (orderRes.success) setOrder(orderRes);
      if (!statusRes.verified) {
        navigate('/payment/' + orderId, { replace: true });
      }
    } catch (err) {
      setError(err.message || 'Failed to load payment details.');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmBooking = async () => {
    const bookingId = passedBookingId || statusData?.booking_id;
    if (!bookingId) {
      setError('Booking ID not found. Please check My Bookings.');
      return;
    }
    setConfirming(true);
    setError('');
    try {
      const res = await api.confirmBooking(bookingId);
      if (!res.success) throw new Error(res.message || 'Confirmation failed.');
      const finalId = res.booking?.id || res.booking?.booking_reference || bookingId;
      navigate('/booking-confirmation/' + finalId, { state: { bookingData: res } });
    } catch (err) {
      setError(err.message || 'Confirmation failed. Your payment is saved — check My Bookings.');
      setConfirming(false);
    }
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: '40px 20px', maxWidth: 600, textAlign: 'center' }}>
        <div className="luxe-card" style={{ padding: 52 }}>
          <RefreshCw size={36} color="#10b981" className="spin-animation" style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>Verifying Payment...</h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>Please wait while we confirm your payment</p>
        </div>
      </div>
    );
  }

  const ev = order?.event || {};
  const totalAmount = parseFloat(order?.amount || statusData?.amount || 0);
  const quantity = order?.quantity || 1;
  const paymentRef = statusData?.payment_id || statusData?.transaction_reference || orderId;

  const fmt = (dateStr) => {
    if (!dateStr) return '';
    try { return new Date(dateStr).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }); }
    catch { return dateStr; }
  };

  const fmtTime = (t) => {
    if (!t) return '';
    try {
      const [h, m] = t.split(':');
      const hr = parseInt(h);
      return (hr % 12 || 12) + ':' + m + (hr < 12 ? ' AM' : ' PM');
    } catch { return t; }
  };

  return (
    <div className="container" style={{ padding: '20px 20px 80px', maxWidth: 680 }}>

      {/* Success Hero */}
      <div className="luxe-card" style={{ padding: '36px 28px', background: 'linear-gradient(160deg,#0d1f2d 0%,#0d1424 60%,#0f1720 100%)', border: '2px solid rgba(16,185,129,0.4)', borderRadius: 24, boxShadow: '0 24px 60px rgba(0,0,0,0.8)', textAlign: 'center', marginBottom: 20 }}>

        <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'rgba(16,185,129,0.18)', border: '3px solid #10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 18px', boxShadow: '0 0 50px rgba(16,185,129,0.5)' }}>
          <CheckCircle size={46} color="#10b981" />
        </div>

        <span className="badge badge-emerald" style={{ fontSize: 11, marginBottom: 10, display: 'inline-block' }}>PAYMENT VERIFIED</span>

        <h1 style={{ fontSize: 'clamp(1.9rem,4vw,2.6rem)', fontWeight: 900, color: '#fff', marginBottom: 8 }}>
          Payment Successful!
        </h1>
        <p style={{ fontSize: 15, color: '#94a3b8', maxWidth: 400, margin: '0 auto 22px', lineHeight: 1.6 }}>
          Your payment of <strong style={{ color: '#fff' }}>&#x20B9;{totalAmount.toFixed(2)}</strong> has been verified.
          Click Confirm Booking to generate your entry ticket.
        </p>

        {/* Detail pills */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, justifyContent: 'center', marginBottom: 24 }}>
          {ev.title && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.3)', borderRadius: 10, padding: '6px 14px', fontSize: 13, color: '#c7d2fe' }}>
              <Ticket size={14} />
              <span>{ev.title}</span>
            </div>
          )}
          {ev.event_date && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.25)', borderRadius: 10, padding: '6px 14px', fontSize: 13, color: '#c7d2fe' }}>
              <Calendar size={14} />
              <span>{fmt(ev.event_date)}</span>
            </div>
          )}
          {ev.start_time && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.25)', borderRadius: 10, padding: '6px 14px', fontSize: 13, color: '#c7d2fe' }}>
              <Clock size={14} />
              <span>{fmtTime(ev.start_time)}</span>
            </div>
          )}
          {ev.venue && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.25)', borderRadius: 10, padding: '6px 14px', fontSize: 13, color: '#c7d2fe' }}>
              <MapPin size={14} />
              <span>{ev.venue}</span>
            </div>
          )}
        </div>

        {/* Summary table */}
        <div style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, padding: '16px 20px', textAlign: 'left', marginBottom: 24, maxWidth: 440, margin: '0 auto 24px' }}>
          {[
            { label: 'Tickets', value: quantity + ' Ticket(s)' },
            { label: 'Amount Paid', value: '₹' + totalAmount.toFixed(2) },
            { label: 'Payment Ref', value: paymentRef },
            { label: 'Attendee', value: currentUser?.name || 'You' },
          ].map(({ label, value }) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.06)', fontSize: 13 }}>
              <span style={{ color: 'var(--text-muted)' }}>{label}</span>
              <span style={{ color: '#fff', fontWeight: 600, fontFamily: label === 'Payment Ref' ? 'monospace' : undefined, fontSize: label === 'Payment Ref' ? 11.5 : 13 }}>{value}</span>
            </div>
          ))}
        </div>

        {error && (
          <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 10, padding: '10px 16px', fontSize: 13, color: '#fca5a5', marginBottom: 16, textAlign: 'center' }}>
            {error}
          </div>
        )}

        <button
          type="button"
          onClick={handleConfirmBooking}
          disabled={confirming}
          style={{ padding: '16px 48px', fontSize: 16, fontWeight: 900, background: confirming ? 'rgba(16,185,129,0.4)' : 'linear-gradient(135deg,#10b981 0%,#059669 100%)', color: '#fff', border: 'none', borderRadius: 14, cursor: confirming ? 'not-allowed' : 'pointer', display: 'inline-flex', alignItems: 'center', gap: 10, boxShadow: '0 8px 30px rgba(16,185,129,0.5)', marginBottom: 14 }}
        >
          {confirming ? <RefreshCw size={20} className="spin-animation" /> : <CheckCircle size={20} />}
          <span>{confirming ? 'Generating Entry Ticket...' : 'Confirm Booking'}</span>
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: 5, justifyContent: 'center', fontSize: 12, color: 'var(--text-dim)' }}>
          <ShieldCheck size={13} color="#10b981" />
          <span>Clicking confirms booking in MySQL &amp; generates your separate entry QR ticket</span>
        </div>
      </div>

      {/* Bottom navigation */}
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
        <Link to="/my-bookings" className="btn btn-secondary" style={{ fontSize: 13 }}>My Bookings</Link>
        <Link to="/events" className="btn btn-secondary" style={{ fontSize: 13 }}>Browse More Events</Link>
      </div>
    </div>
  );
}
