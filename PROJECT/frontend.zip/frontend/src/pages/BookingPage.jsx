import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Ticket, 
  CreditCard, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle, 
  Sparkles, 
  Plus, 
  Minus, 
  User, 
  Lock, 
  Mail, 
  RefreshCw,
  ExternalLink,
  QrCode,
  Info,
  Key
} from 'lucide-react';
import { api, getUser, setToken, setUser } from '../services/api';

export default function BookingPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Selection State
  const [quantity, setQuantity] = useState(1);
  const [selectedSlot, setSelectedSlot] = useState('Standard Entry Pass');
  
  // Lifecycle Stages: 
  // 'select' -> 'generating_qr' -> 'payment_qr' -> 'payment_verified' -> 'confirming' -> 'gateway_setup_required' | 'failed'
  const [stage, setStage] = useState('select'); 
  
  // Payment QR & Gateway State
  const [paymentQrData, setPaymentQrData] = useState(null);
  const [gatewaySetupInfo, setGatewaySetupInfo] = useState(null);
  const [pendingBookingId, setPendingBookingId] = useState(null);
  const [failureReason, setFailureReason] = useState('');
  const [timeRemaining, setTimeRemaining] = useState(600); // 10 minutes in seconds

  // Attendee Account State
  const [userState, setUserState] = useState(getUser());
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginName, setLoginName] = useState('');
  const [loginPhone, setLoginPhone] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Polling ref
  const pollTimerRef = useRef(null);

  // Load Event Data on Mount
  useEffect(() => {
    loadEventData();
    return () => {
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    };
  }, [id]);

  // 10-Minute Countdown Timer for Payment QR
  useEffect(() => {
    let timer = null;
    if (stage === 'payment_qr' && timeRemaining > 0) {
      timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            setStage('failed');
            setFailureReason('Payment QR hold has expired (10 minutes). Reserved seats released back to pool.');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [stage, timeRemaining]);

  const loadEventData = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getEventById(id);
      if (res.event) {
        setEvent(res.event);
        if (res.event.schedule) {
          setSelectedSlot(`General Session (${res.event.start_time || 'Main Event'})`);
        }
      } else {
        throw new Error('Event details could not be found.');
      }
    } catch (err) {
      console.error('Failed to load event for booking:', err);
      setError(err.message || 'Could not load event data.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: '24px 20px 80px', maxWidth: 760, textAlign: 'center' }}>
        <div className="luxe-card" style={{ padding: '60px 20px' }}>
          <RefreshCw size={36} color="#6366f1" className="spin-animation" style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>Loading Booking Details...</h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>
            Fetching live ticket availability from MySQL database
          </p>
        </div>
      </div>
    );
  }

  if (error || !event) {
    return (
      <div className="container" style={{ padding: '24px 20px 80px', maxWidth: 760, textAlign: 'center' }}>
        <div className="luxe-card" style={{ padding: '40px 24px' }}>
          <AlertTriangle size={48} color="#f43f5e" style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 22, fontWeight: 800, color: '#fff', marginBottom: 8 }}>Event Not Available</h2>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>
            {error || 'Unable to locate this event for booking.'}
          </p>
          <Link to="/events" className="btn btn-primary" style={{ padding: '10px 20px', display: 'inline-flex', alignItems: 'center', gap: 8 }}>
            <ArrowLeft size={16} />
            <span>Browse All Events</span>
          </Link>
        </div>
      </div>
    );
  }

  const pricePerTicket = parseFloat(event.price || 0);
  const isFree = pricePerTicket === 0;
  const totalAmount = pricePerTicket * quantity;
  const available = event.available_seats !== undefined ? event.available_seats : (event.availableSeats !== undefined ? event.availableSeats : 100);
  const isSoldOut = available <= 0;
  const maxAllowed = Math.min(5, Math.max(1, available));

  const formattedEventDate = event.event_date ? new Date(event.event_date).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }) : 'Scheduled Date';

  // Quantity Handlers
  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
      setError('');
    }
  };

  const handleIncrease = () => {
    if (quantity < maxAllowed) {
      setQuantity(prev => prev + 1);
      setError('');
    } else if (quantity >= available) {
      setError(`Only ${available} seat(s) available.`);
    } else {
      setError('Maximum 5 passes allowed per reservation.');
    }
  };

  // Quick Account Handler (Uses logged-in user's details without fixed emails)
  const handleQuickAuth = async (e) => {
    e.preventDefault();
    setLoginError('');
    if (!loginEmail.trim() || !loginPassword) {
      setLoginError('Please enter both your email address and password.');
      return;
    }

    setLoginLoading(true);
    try {
      const res = await api.login({
        email: loginEmail.trim(),
        password: loginPassword,
        name: loginName.trim() || undefined
      });
      setToken(res.token);
      setUser(res.user);
      setUserState(res.user);
      setLoginError('');
    } catch (err) {
      try {
        const regRes = await api.register({
          name: loginName.trim() || loginEmail.split('@')[0],
          email: loginEmail.trim(),
          password: loginPassword,
          phone: loginPhone.trim() || '9876543210'
        });
        setToken(regRes.token);
        setUser(regRes.user);
        setUserState(regRes.user);
        setLoginError('');
      } catch (regErr) {
        setLoginError(err.message || regErr.message || 'Authentication failed. Please verify credentials.');
      }
    } finally {
      setLoginLoading(false);
    }
  };

  // Step 2: Proceed to Payment -> Generate Dynamic Payment QR
  const handleProceedToPayment = async () => {
    if (!userState) {
      setError('Please provide your name and email below before proceeding.');
      return;
    }

    if (available <= 0) {
      setError('Sorry, this event is completely sold out.');
      return;
    }

    // Free events: Skip payment completely
    if (isFree) {
      setStage('payment_verified');
      setPendingBookingId('free');
      return;
    }

    setStage('generating_qr');
    setError('');
    setFailureReason('');

    try {
      const res = await api.generatePaymentQr({
        event_id: event.id,
        quantity: quantity,
        num_seats: quantity
      });

      // Always navigate to the payment page.
      // The payment page displays the uploaded PhonePe QR (PUTHANA PRAVEENA)
      // regardless of whether the gateway is fully configured.
      // order_id is required for backend verification polling.
      if (!res.order_id) {
        throw new Error(res.message || 'Could not create payment order on backend.');
      }

      // Open payment page immediately at the top of the screen (ScrollToTop handles this)
      navigate(`/payment/${res.order_id}`, {
        state: {
          paymentData: { ...res, event },
          event
        }
      });

    } catch (err) {
      console.warn('Generate QR Error:', err);
      setStage('slot_selection');
      setError(err.message || 'Could not initiate payment. Please try again.');
    }
  };

  // Poll backend for verified payment status (No "I Have Paid" button!)
  const startPaymentStatusPolling = (orderId) => {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);

    pollTimerRef.current = setInterval(async () => {
      try {
        const statusRes = await api.checkPaymentStatus(orderId);
        if (statusRes.success && (statusRes.status === 'SUCCESS' || statusRes.verified)) {
          clearInterval(pollTimerRef.current);
          setPendingBookingId(statusRes.booking_id);
          // Requirement: After verified payment, show “Payment Successful” and a “Confirm Booking” button
          setStage('payment_verified');
        }
      } catch (e) {
        // Continue polling until expiration
      }
    }, 2500);
  };

  // Test Mode Verification Trigger (Convenient for local demonstration without real mobile scan)
  const handleSimulatePaymentCapture = async () => {
    if (!paymentQrData?.order_id) return;
    try {
      await api.simulateQrPayment(paymentQrData.order_id);
      // Trigger status check immediately
      const statusRes = await api.checkPaymentStatus(paymentQrData.order_id);
      if (statusRes.success && statusRes.verified) {
        if (pollTimerRef.current) clearInterval(pollTimerRef.current);
        setPendingBookingId(statusRes.booking_id);
        setStage('payment_verified');
      }
    } catch (err) {
      console.error('Simulate capture error:', err);
    }
  };

  // Confirm Booking Action: Saves booking in MySQL & generates separate event entry QR ticket
  const handleConfirmBooking = async () => {
    setStage('confirming');
    setError('');

    try {
      let confirmRes;

      if (isFree || pendingBookingId === 'free') {
        confirmRes = await api.bookEvent({
          event_id: event.id,
          num_seats: quantity,
          tickets_count: quantity
        });
      } else {
        if (!pendingBookingId) {
          throw new Error('Pending booking ID not found. Please check My Bookings to confirm.');
        }
        confirmRes = await api.confirmBooking(pendingBookingId);
      }

      if (!confirmRes.success) {
        throw new Error(confirmRes.message || 'Failed to complete booking confirmation.');
      }

      const targetBookingId = confirmRes.booking?.id || confirmRes.booking?.booking_reference || pendingBookingId;

      // Navigate immediately to the separate confirmation page at the TOP of the screen
      navigate(`/booking-confirmation/${targetBookingId}`, {
        state: {
          bookingData: confirmRes
        }
      });

    } catch (err) {
      console.error('Confirmation failure:', err);
      setStage('failed');
      setFailureReason(err.message || 'Confirmation failed. Your payment details are securely logged.');
    }
  };

  const minutesRemaining = Math.floor(timeRemaining / 60);
  const secondsRemaining = timeRemaining % 60;
  const timeFormatted = `${minutesRemaining}:${secondsRemaining < 10 ? '0' : ''}${secondsRemaining}`;

  return (
    <div className="container" style={{ padding: '20px 20px 80px', maxWidth: 840 }}>
      
      {/* Top Breadcrumb & Navigation */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <Link 
          to={`/events/${event.id}`} 
          className="btn btn-secondary"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 13, padding: '7px 14px' }}
        >
          <ArrowLeft size={15} />
          <span>Back to Event Details</span>
        </Link>

        <span style={{ fontSize: 12, color: 'var(--text-dim)', fontWeight: 600 }}>
          {stage === 'payment_qr' ? 'Step: Payment QR' : stage === 'payment_verified' ? 'Step: Confirm Booking' : 'Step: Select Slot & Quantity'}
        </span>
      </div>

      {/* Main Booking Card (Starts directly at the TOP of the page) */}
      <div className="luxe-card" style={{ padding: '24px 28px', background: '#0e1526', border: '1px solid rgba(99, 102, 241, 0.35)', borderRadius: 20 }}>
        
        {/* Selected Event Header */}
        <div style={{ display: 'flex', gap: 20, alignItems: 'center', paddingBottom: 20, borderBottom: '1px solid var(--border-subtle)', flexWrap: 'wrap' }}>
          {event.banner_url && (
            <img 
              src={event.banner_url} 
              alt={event.title}
              style={{ width: 90, height: 90, borderRadius: 14, objectFit: 'cover', flexShrink: 0, boxShadow: '0 8px 20px rgba(0,0,0,0.5)' }} 
            />
          )}
          <div style={{ flex: 1, minWidth: 240 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <span className="badge badge-indigo" style={{ fontSize: 11 }}>
                {event.category || 'Campus Event'}
              </span>
              <span style={{ fontSize: 12, fontWeight: 700, color: isSoldOut ? '#f43f5e' : '#34d399' }}>
                • {isSoldOut ? 'Sold Out' : `${available} Available Slots`}
              </span>
            </div>
            
            <h1 style={{ fontSize: 'clamp(1.35rem, 2.5vw, 1.8rem)', fontWeight: 800, color: '#fff', lineHeight: 1.25, marginBottom: 6 }}>
              {event.title}
            </h1>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, fontSize: 12.5, color: 'var(--text-muted)' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <Calendar size={13} color="#6366f1" />
                <span>{formattedEventDate}</span>
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <Clock size={13} color="#06b6d4" />
                <span>{event.start_time || '09:00'} - {event.end_time || '17:00'}</span>
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <MapPin size={13} color="#10b981" />
                <span>{event.venue}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Global Error Banner */}
        {error && (
          <div style={{
            background: 'rgba(244, 63, 94, 0.15)',
            border: '1px solid rgba(244, 63, 94, 0.4)',
            borderRadius: 12,
            padding: '12px 16px',
            color: '#f87171',
            fontSize: 13,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            marginTop: 18
          }}>
            <AlertTriangle size={18} />
            <span>{error}</span>
          </div>
        )}

        {/* ============================================================== */}
        {/* STAGE 1: SELECT SLOT & TICKET QUANTITY                         */}
        {/* ============================================================== */}
        {stage === 'select' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20, marginTop: 20 }}>
            
            {/* Attendee Details Check */}
            <div style={{
              background: 'rgba(255, 255, 255, 0.02)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 14,
              padding: '16px 20px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <User size={16} color="#818cf8" />
                  <span style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>
                    Attendee Information
                  </span>
                </div>
                {userState ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ fontSize: 12, color: '#34d399', fontWeight: 600 }}>
                      Logged in as:
                    </span>
                    <strong style={{ color: '#fff', fontSize: 13 }}>
                      {userState.name} ({userState.email})
                    </strong>
                  </div>
                ) : (
                  <span style={{ fontSize: 12, color: '#f59e0b', fontWeight: 600 }}>
                    Please enter your name & email
                  </span>
                )}
              </div>

              {!userState && (
                <form onSubmit={handleQuickAuth} style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {loginError && (
                    <div style={{ color: '#f87171', fontSize: 12 }}>
                      {loginError}
                    </div>
                  )}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 10 }}>
                    <input
                      type="text"
                      placeholder="Your Full Name"
                      value={loginName}
                      onChange={e => setLoginName(e.target.value)}
                      style={{ padding: '9px 12px', background: '#0b1120', border: '1px solid var(--border-subtle)', borderRadius: 8, color: '#fff', fontSize: 13 }}
                      required
                    />
                    <input
                      type="email"
                      placeholder="Your Email"
                      value={loginEmail}
                      onChange={e => setLoginEmail(e.target.value)}
                      style={{ padding: '9px 12px', background: '#0b1120', border: '1px solid var(--border-subtle)', borderRadius: 8, color: '#fff', fontSize: 13 }}
                      required
                    />
                    <input
                      type="password"
                      placeholder="Password"
                      value={loginPassword}
                      onChange={e => setLoginPassword(e.target.value)}
                      style={{ padding: '9px 12px', background: '#0b1120', border: '1px solid var(--border-subtle)', borderRadius: 8, color: '#fff', fontSize: 13 }}
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={loginLoading}
                    className="btn btn-secondary"
                    style={{ alignSelf: 'flex-start', padding: '7px 16px', fontSize: 12 }}
                  >
                    {loginLoading ? 'Saving...' : 'Set Attendee Account'}
                  </button>
                </form>
              )}
            </div>

            {/* Available Slots / Ticket Options */}
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text-dim)', textTransform: 'uppercase', marginBottom: 8 }}>
                Select Event Slot & Entry Option
              </label>
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                gap: 12
              }}>
                <div 
                  onClick={() => setSelectedSlot('Standard General Entry')}
                  style={{
                    padding: '14px 16px',
                    borderRadius: 12,
                    background: selectedSlot.includes('Standard') || selectedSlot.includes('General') ? 'rgba(99, 102, 241, 0.12)' : 'rgba(255,255,255,0.02)',
                    border: selectedSlot.includes('Standard') || selectedSlot.includes('General') ? '2px solid #6366f1' : '1px solid var(--border-subtle)',
                    cursor: 'pointer'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong style={{ color: '#fff', fontSize: 14 }}>Standard Admission Pass</strong>
                    <span style={{ fontSize: 11, color: '#38bdf8', fontWeight: 700 }}>
                      {available} Slots
                    </span>
                  </div>
                  <span style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginTop: 4 }}>
                    General admission seating with unique digital QR ticket.
                  </span>
                </div>

                <div 
                  onClick={() => setSelectedSlot('Priority Gate Pass')}
                  style={{
                    padding: '14px 16px',
                    borderRadius: 12,
                    background: selectedSlot.includes('Priority') ? 'rgba(99, 102, 241, 0.12)' : 'rgba(255,255,255,0.02)',
                    border: selectedSlot.includes('Priority') ? '2px solid #6366f1' : '1px solid var(--border-subtle)',
                    cursor: 'pointer'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong style={{ color: '#fff', fontSize: 14 }}>Priority Entry Slot</strong>
                    <span style={{ fontSize: 11, color: '#a5b4fc', fontWeight: 700 }}>
                      Fast Check-in
                    </span>
                  </div>
                  <span style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginTop: 4 }}>
                    Express gate verification lane for rapid entry.
                  </span>
                </div>
              </div>
            </div>

            {/* Ticket Quantity & Total Amount */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
              gap: 16,
              background: 'rgba(0,0,0,0.25)',
              padding: '18px 20px',
              borderRadius: 14,
              border: '1px solid rgba(255,255,255,0.04)'
            }}>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text-dim)', textTransform: 'uppercase', marginBottom: 8 }}>
                  Ticket Quantity
                </label>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <button
                    type="button"
                    onClick={handleDecrease}
                    disabled={quantity <= 1}
                    className="btn btn-secondary"
                    style={{ width: 40, height: 40, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  >
                    <Minus size={16} />
                  </button>
                  <span style={{ fontSize: 20, fontWeight: 900, color: '#fff', minWidth: 32, textAlign: 'center' }}>
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={handleIncrease}
                    disabled={quantity >= maxAllowed || isSoldOut}
                    className="btn btn-secondary"
                    style={{ width: 40, height: 40, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  >
                    <Plus size={16} />
                  </button>
                  <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                    (Max 5)
                  </span>
                </div>
              </div>

              <div style={{ textAlign: 'right' }}>
                <span style={{ fontSize: 12, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 700, display: 'block' }}>
                  Total Amount
                </span>
                <div style={{ fontSize: 28, fontWeight: 900, color: isFree ? '#34d399' : '#fff', marginTop: 2 }}>
                  {isFree ? 'FREE' : `₹${totalAmount.toFixed(2)}`}
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                  {isFree ? 'Complimentary Pass' : `${quantity} × ₹${pricePerTicket.toFixed(2)}`}
                </div>
              </div>
            </div>

            {/* Action: Proceed to Payment */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 4 }}>
              <button
                type="button"
                onClick={handleProceedToPayment}
                disabled={isSoldOut}
                className="btn btn-emerald"
                style={{
                  padding: '16px 24px',
                  fontSize: 16,
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 10,
                  boxShadow: '0 4px 20px rgba(16, 185, 129, 0.4)'
                }}
              >
                <CreditCard size={18} />
                <span>
                  {isSoldOut ? 'Sold Out' : (isFree ? 'Reserve Free Pass' : `Proceed to Payment (₹${totalAmount.toFixed(2)})`)}
                </span>
              </button>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontSize: 12, color: 'var(--text-dim)' }}>
                <ShieldCheck size={14} color="#10b981" />
                <span>Pessimistic row-level locking with 10-minute hold in MySQL. Zero-overbooking guarantee.</span>
              </div>
            </div>

          </div>
        )}

        {/* ============================================================== */}
        {/* STAGE: GENERATING PAYMENT QR SPINNER                           */}
        {/* ============================================================== */}
        {stage === 'generating_qr' && (
          <div style={{ textAlign: 'center', padding: '48px 20px' }}>
            <RefreshCw size={36} color="#6366f1" className="spin-animation" style={{ margin: '0 auto 16px' }} />
            <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>
              Generating Payment QR for ₹{totalAmount.toFixed(2)}...
            </h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>
              Contacting configured payment gateway and locking your seats for 10 minutes.
            </p>
          </div>
        )}

        {/* ============================================================== */}
        {/* STAGE 2: DYNAMIC PAYMENT QR DISPLAY (Scan to Pay)               */}
        {/* ============================================================== */}
        {stage === 'payment_qr' && paymentQrData && (
          <div style={{
            marginTop: 20,
            background: 'linear-gradient(180deg, rgba(99, 102, 241, 0.08) 0%, rgba(14, 21, 38, 0.95) 100%)',
            border: '2px solid rgba(99, 102, 241, 0.4)',
            borderRadius: 20,
            padding: '24px 20px',
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center'
          }}>
            {/* Top Badge: Scan to Pay */}
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              background: 'rgba(56, 189, 248, 0.15)',
              border: '1px solid rgba(56, 189, 248, 0.35)',
              padding: '4px 14px',
              borderRadius: 20,
              color: '#38bdf8',
              fontSize: 12,
              fontWeight: 800,
              letterSpacing: '0.05em',
              textTransform: 'uppercase',
              marginBottom: 12
            }}>
              <QrCode size={15} />
              <span>Scan to Pay</span>
            </div>

            {/* Exact Total Amount in ₹ */}
            <h2 style={{ fontSize: 26, fontWeight: 900, color: '#fff', marginBottom: 4 }}>
              Amount: ₹{paymentQrData.amount.toFixed(2)}
            </h2>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
              {paymentQrData.quantity} Ticket(s) for <strong>{paymentQrData.event_title}</strong>
            </p>

            {/* Dynamic Payment QR Image */}
            <div style={{
              width: 220,
              height: 220,
              background: '#ffffff',
              padding: 12,
              borderRadius: 16,
              margin: '0 auto 14px auto',
              boxShadow: '0 12px 35px rgba(0,0,0,0.8)',
              border: '3px solid #6366f1',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {paymentQrData.qr_image_url ? (
                <img 
                  src={paymentQrData.qr_image_url} 
                  alt="Dynamic Payment QR" 
                  style={{ width: '100%', height: '100%', display: 'block', borderRadius: 4 }}
                />
              ) : (
                <QrCode size={60} color="#6366f1" />
              )}
            </div>

            {/* Live Verification Status (No "I Have Paid" button!) */}
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              background: 'rgba(234, 179, 8, 0.12)',
              border: '1px solid rgba(234, 179, 8, 0.3)',
              padding: '6px 16px',
              borderRadius: 20,
              color: '#fef08a',
              fontSize: 12.5,
              fontWeight: 600,
              marginBottom: 10
            }}>
              <RefreshCw size={14} className="spin-animation" color="#facc15" />
              <span>Awaiting payment verification from gateway / bank...</span>
            </div>

            <div style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 16 }}>
              Seat hold active: <strong style={{ color: '#38bdf8' }}>{timeFormatted}</strong> remaining
            </div>

            {/* Test Simulation Tool (For Viva / Local Evaluators without real UPI banking app) */}
            <div style={{
              marginTop: 10,
              padding: '12px 18px',
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px dashed rgba(255, 255, 255, 0.15)',
              borderRadius: 12,
              maxWidth: 460
            }}>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 8 }}>
                College Viva Evaluation Helper:
              </div>
              <button
                type="button"
                onClick={handleSimulatePaymentCapture}
                className="btn btn-secondary"
                style={{ padding: '8px 16px', fontSize: 12, color: '#38bdf8', borderColor: 'rgba(56, 189, 248, 0.4)' }}
              >
                Simulate Gateway Bank Approval (Test Mode)
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* STAGE: GATEWAY SETUP REQUIRED MESSAGE (Requirement)            */}
        {/* ============================================================== */}
        {stage === 'gateway_setup_required' && gatewaySetupInfo && (
          <div style={{
            marginTop: 20,
            background: 'rgba(245, 158, 11, 0.08)',
            border: '2px solid rgba(245, 158, 11, 0.4)',
            borderRadius: 16,
            padding: 24,
            textAlign: 'left'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div style={{
                padding: 8,
                borderRadius: 8,
                background: 'rgba(245, 158, 11, 0.2)',
                color: '#fbbf24'
              }}>
                <Key size={22} />
              </div>
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>
                  {gatewaySetupInfo.title || 'Payment Gateway Configuration Required'}
                </h3>
                <span style={{ fontSize: 12, color: '#fef08a' }}>
                  Dynamic payment QR generation requires configured credentials
                </span>
              </div>
            </div>

            <p style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.5, marginBottom: 16 }}>
              {gatewaySetupInfo.description || 'To accept dynamic payment QR codes, configure your Razorpay Test API keys in backend/.env.'}
            </p>

            <div style={{
              background: 'rgba(0, 0, 0, 0.4)',
              border: '1px solid rgba(255, 255, 255, 0.06)',
              borderRadius: 12,
              padding: '14px 18px',
              marginBottom: 20
            }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#38bdf8', textTransform: 'uppercase', marginBottom: 8 }}>
                Setup Steps:
              </div>
              <ol style={{ paddingLeft: 18, margin: 0, fontSize: 12.5, color: '#94a3b8', lineHeight: 1.6 }}>
                {gatewaySetupInfo.steps?.map((step, idx) => (
                  <li key={idx} style={{ marginBottom: 4 }}>
                    {step}
                  </li>
                ))}
              </ol>
            </div>

            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button
                type="button"
                onClick={() => setStage('select')}
                className="btn btn-primary"
                style={{ padding: '9px 18px', fontSize: 13 }}
              >
                Back to Ticket Selection
              </button>
              <Link to="/events" className="btn btn-secondary" style={{ padding: '9px 18px', fontSize: 13 }}>
                Browse Events
              </Link>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* STAGE 3: PAYMENT VERIFIED -> SHOW "CONFIRM BOOKING"             */}
        {/* ============================================================== */}
        {stage === 'payment_verified' && (
          <div style={{
            marginTop: 20,
            background: 'rgba(16, 185, 129, 0.1)',
            border: '2px solid #10b981',
            borderRadius: 18,
            padding: '28px 24px',
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 16
          }}>
            <div style={{
              width: 58,
              height: 58,
              borderRadius: '50%',
              background: 'rgba(16, 185, 129, 0.2)',
              border: '2px solid #10b981',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 0 30px rgba(16, 185, 129, 0.4)'
            }}>
              <CheckCircle size={34} color="#10b981" />
            </div>

            <div>
              <span className="badge badge-emerald" style={{ fontSize: 11, marginBottom: 8 }}>
                VERIFIED BY BACKEND GATEWAY
              </span>
              <h2 style={{ fontSize: 24, fontWeight: 900, color: '#fff', marginTop: 4 }}>
                Payment Successful
              </h2>
              <p style={{ fontSize: 13.5, color: '#cbd5e1', marginTop: 6, maxWidth: 480 }}>
                {isFree 
                  ? 'Your free pass reservation is held. Click Confirm Booking to generate your digital event entry QR pass.'
                  : `Your payment of ₹${totalAmount.toFixed(2)} has been verified. Click Confirm Booking to save your booking in MySQL and generate your event entry QR ticket.`
                }
              </p>
            </div>

            {/* Requirement: "Confirm Booking" Button */}
            <button
              type="button"
              onClick={handleConfirmBooking}
              className="btn btn-primary"
              style={{
                padding: '16px 40px',
                fontSize: 16,
                fontWeight: 900,
                background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                color: '#fff',
                border: 'none',
                borderRadius: 14,
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: 10,
                boxShadow: '0 6px 25px rgba(16, 185, 129, 0.5)'
              }}
            >
              <CheckCircle size={20} />
              <span>Confirm Booking</span>
            </button>
          </div>
        )}

        {/* ============================================================== */}
        {/* STAGE: CONFIRMING IN PROGRESS SPINNER                          */}
        {/* ============================================================== */}
        {stage === 'confirming' && (
          <div style={{ textAlign: 'center', padding: '48px 20px' }}>
            <RefreshCw size={36} color="#6366f1" className="spin-animation" style={{ margin: '0 auto 16px' }} />
            <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>
              Saving Booking & Generating Entry QR Ticket...
            </h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>
              Committing transaction in MySQL and issuing digital gate ticket pass.
            </p>
          </div>
        )}

        {/* ============================================================== */}
        {/* STAGE: FAILURE                                                 */}
        {/* ============================================================== */}
        {stage === 'failed' && (
          <div style={{
            marginTop: 20,
            background: 'rgba(244, 63, 94, 0.1)',
            border: '1px solid rgba(244, 63, 94, 0.4)',
            borderRadius: 16,
            padding: 24,
            textAlign: 'center'
          }}>
            <AlertTriangle size={36} color="#f43f5e" style={{ margin: '0 auto 12px' }} />
            <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>
              Booking Could Not Be Completed
            </h3>
            <p style={{ fontSize: 13, color: '#fca5a5', margin: '8px auto 16px', maxWidth: 480 }}>
              {failureReason || 'An error occurred during payment processing. No seats were charged.'}
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
              <button
                type="button"
                onClick={() => {
                  setStage('select');
                  setError('');
                }}
                className="btn btn-primary"
                style={{ padding: '10px 18px', fontSize: 13 }}
              >
                Try Again
              </button>
              <Link to="/events" className="btn btn-secondary" style={{ padding: '10px 18px', fontSize: 13 }}>
                Back to Events
              </Link>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
