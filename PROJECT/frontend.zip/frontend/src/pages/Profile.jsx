import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Phone, Shield, Calendar, Ticket, CheckCircle2, LogOut, Save, AlertCircle } from 'lucide-react';
import { api, getUser, setUser, removeToken, removeUser } from '../services/api';

export default function Profile() {
  const [profile, setProfile] = useState(null);
  const [stats, setStats] = useState(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    setLoading(true);
    try {
      const res = await api.getMe();
      setProfile(res.user);
      setStats(res.stats);
      setName(res.user.name || '');
      setPhone(res.user.phone || '');
    } catch (err) {
      setError(err.message || 'Failed to load profile. Please log in.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMsg('');
    setError('');

    try {
      const res = await api.updateProfile({ name, phone });
      setMsg('Profile updated successfully!');
      setUser(res.user);
      setProfile(res.user);
      setTimeout(() => setMsg(''), 4000);
    } catch (err) {
      setError(err.message || 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = () => {
    removeToken();
    removeUser();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: '80px 20px', textAlign: 'center', color: 'var(--text-dim)' }}>
        Loading profile details...
      </div>
    );
  }

  return (
    <div className="container" style={{ padding: '40px 20px 80px 20px', maxWidth: 780 }}>
      
      {/* Page Title */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.4rem)', fontWeight: 800, marginBottom: 6 }}>
          Attendee Account & Profile
        </h1>
        <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
          Manage your personal credentials, phone number, and view your campus participation metrics
        </p>
      </div>

      {msg && (
        <div style={{
          background: 'rgba(16, 185, 129, 0.15)',
          border: '1px solid rgba(16, 185, 129, 0.4)',
          borderRadius: 10,
          padding: '12px 16px',
          color: '#34d399',
          fontSize: 13,
          marginBottom: 20,
          display: 'flex',
          alignItems: 'center',
          gap: 8
        }}>
          <CheckCircle2 size={18} />
          <span>{msg}</span>
        </div>
      )}

      {error && (
        <div style={{
          background: 'rgba(244, 63, 94, 0.15)',
          border: '1px solid rgba(244, 63, 94, 0.4)',
          borderRadius: 10,
          padding: '12px 16px',
          color: '#f87171',
          fontSize: 13,
          marginBottom: 20,
          display: 'flex',
          alignItems: 'center',
          gap: 8
        }}>
          <AlertCircle size={18} />
          <span>{error}</span>
        </div>
      )}

      {/* Participation Stats Bar */}
      {stats && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
          gap: 16,
          marginBottom: 28
        }}>
          <div className="luxe-card" style={{ padding: 18, textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase', marginBottom: 4 }}>
              Total Bookings
            </div>
            <div style={{ fontSize: 26, fontWeight: 900, color: '#38bdf8' }}>
              {stats.totalBookings}
            </div>
          </div>

          <div className="luxe-card" style={{ padding: 18, textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase', marginBottom: 4 }}>
              Active Tickets
            </div>
            <div style={{ fontSize: 26, fontWeight: 900, color: '#a5b4fc' }}>
              {stats.activeTickets}
            </div>
          </div>

          <div className="luxe-card" style={{ padding: 18, textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase', marginBottom: 4 }}>
              Gate Verified
            </div>
            <div style={{ fontSize: 26, fontWeight: 900, color: '#34d399' }}>
              {stats.checkedInTickets}
            </div>
          </div>
        </div>
      )}

      {/* Profile Form Card */}
      <div className="luxe-card" style={{ padding: 32 }}>
        
        {/* User Identity Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 18, marginBottom: 28, paddingBottom: 20, borderBottom: '1px solid var(--border-subtle)' }}>
          <div style={{
            width: 64,
            height: 64,
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #6366f1, #06b6d4)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontSize: 26,
            fontWeight: 800
          }}>
            {profile?.name ? profile.name.charAt(0).toUpperCase() : 'U'}
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <h2 style={{ fontSize: 20, fontWeight: 800, color: '#fff' }}>{profile?.name}</h2>
              <span className={`badge ${profile?.role === 'admin' ? 'badge-cyan' : 'badge-emerald'}`}>
                {profile?.role === 'admin' ? 'Administrator' : 'Verified Attendee'}
              </span>
            </div>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>
              Account registered: {profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : 'Active'}
            </p>
          </div>
        </div>

        <form onSubmit={handleUpdate} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              className="form-input"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Email Address (Immutable)</label>
            <input
              type="email"
              disabled
              value={profile?.email || ''}
              className="form-input"
              style={{ opacity: 0.6, cursor: 'not-allowed' }}
            />
            <span style={{ fontSize: 11, color: 'var(--text-dim)' }}>
              Primary identifier saved in MongoDB collection
            </span>
          </div>

          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input
              type="tel"
              placeholder="+91 9876543210"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="form-input"
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
            <button
              type="button"
              onClick={handleLogout}
              className="btn btn-danger"
              style={{ padding: '10px 18px' }}
            >
              <LogOut size={16} />
              <span>Log Out</span>
            </button>

            <button
              type="submit"
              disabled={saving}
              className="btn btn-primary"
              style={{ padding: '10px 24px' }}
            >
              <Save size={16} />
              <span>{saving ? 'Saving Changes...' : 'Save Profile'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
