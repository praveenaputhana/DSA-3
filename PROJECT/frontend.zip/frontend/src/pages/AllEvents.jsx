import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, Calendar, MapPin, IndianRupee, ArrowUpDown, X, Tag } from 'lucide-react';
import { api } from '../services/api';
import EventCard from '../components/EventCard';
import BookingModal from '../components/BookingModal';

export default function AllEvents() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'All';
  const initialSearch = searchParams.get('search') || '';
  const initialDate = searchParams.get('date') || '';
  const initialLocation = searchParams.get('location') || '';
  const initialPriceTier = searchParams.get('priceTier') || 'all';

  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedDate, setSelectedDate] = useState(initialDate);
  const [selectedLocation, setSelectedLocation] = useState(initialLocation);
  const [priceTier, setPriceTier] = useState(initialPriceTier);
  const [sortBy, setSortBy] = useState('date-asc');
  const [loading, setLoading] = useState(true);
  const [bookingEvent, setBookingEvent] = useState(null);

  useEffect(() => {
    loadCategories();
  }, []);

  useEffect(() => {
    loadEvents();
  }, [selectedCategory, searchQuery, selectedDate, selectedLocation, priceTier]);

  const loadCategories = async () => {
    try {
      const res = await api.getCategories();
      setCategories(res.categories || []);
    } catch (err) {
      console.error('Failed to load categories:', err);
    }
  };

  const loadEvents = async () => {
    setLoading(true);
    try {
      const params = {};
      if (selectedCategory && selectedCategory !== 'All') {
        params.category = selectedCategory;
      }
      if (searchQuery.trim()) {
        params.search = searchQuery.trim();
      }
      if (selectedDate) {
        params.date = selectedDate;
      }
      if (selectedLocation && selectedLocation !== 'all') {
        params.location = selectedLocation;
      }
      if (priceTier === 'free') {
        params.maxPrice = 0;
      } else if (priceTier === 'under100') {
        params.maxPrice = 100;
      } else if (priceTier === 'under200') {
        params.maxPrice = 200;
      } else if (priceTier === 'above200') {
        params.minPrice = 200.01;
      }

      const res = await api.getEvents(params);
      setEvents(res.events || []);
    } catch (err) {
      console.error('Failed to load events:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryClick = (catName) => {
    setSelectedCategory(catName);
    const newParams = new URLSearchParams(searchParams);
    if (catName === 'All') {
      newParams.delete('category');
    } else {
      newParams.set('category', catName);
    }
    setSearchParams(newParams);
  };

  const handleClearAllFilters = () => {
    setSelectedCategory('All');
    setSearchQuery('');
    setSelectedDate('');
    setSelectedLocation('');
    setPriceTier('all');
    setSearchParams({});
  };

  const hasActiveFilters = selectedCategory !== 'All' || searchQuery || selectedDate || selectedLocation || priceTier !== 'all';

  // Sorting
  const sortedEvents = [...events].sort((a, b) => {
    if (sortBy === 'date-asc') {
      return new Date(a.event_date || a.eventDate) - new Date(b.event_date || b.eventDate);
    }
    if (sortBy === 'date-desc') {
      return new Date(b.event_date || b.eventDate) - new Date(a.event_date || a.eventDate);
    }
    if (sortBy === 'price-low') {
      return (a.price || 0) - (b.price || 0);
    }
    if (sortBy === 'price-high') {
      return (b.price || 0) - (a.price || 0);
    }
    if (sortBy === 'seats-left') {
      const aSeats = a.available_seats !== undefined ? a.available_seats : a.availableSeats;
      const bSeats = b.available_seats !== undefined ? b.available_seats : b.availableSeats;
      return aSeats - bSeats;
    }
    return 0;
  });

  // Extract unique locations from events for dropdown
  const uniqueLocations = Array.from(new Set(events.map(e => e.location || 'Campus Main Block'))).filter(Boolean);

  return (
    <div className="container" style={{ padding: '40px 20px 80px 20px' }}>
      
      {/* Page Title */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.6rem)', fontWeight: 800, marginBottom: 8, color: '#fff' }}>
          Explore Campus Events
        </h1>
        <p style={{ fontSize: 14, color: 'var(--text-muted)' }}>
          Discover cultural recitals, concerts, fests, hackathons, and technical workshops with live MySQL seat tracking
        </p>
      </div>

      {/* Main Filter & Search Control Panel */}
      <div className="luxe-card" style={{ padding: 22, marginBottom: 28 }}>
        
        {/* Row 1: Keyword Search + Sort + Clear */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: 14,
          alignItems: 'center',
          marginBottom: 16
        }}>
          {/* Keyword Search */}
          <div style={{ position: 'relative' }}>
            <Search
              size={18}
              color="var(--text-dim)"
              style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }}
            />
            <input
              type="text"
              placeholder="Search title, venue, or keywords..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="form-input"
              style={{ paddingLeft: 42 }}
            />
          </div>

          {/* Date Filter */}
          <div style={{ position: 'relative' }}>
            <Calendar
              size={17}
              color="var(--text-dim)"
              style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }}
            />
            <input
              type="date"
              value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)}
              className="form-input"
              style={{ paddingLeft: 42, colorScheme: 'dark' }}
              title="Filter by Event Date"
            />
          </div>

          {/* Location Filter */}
          <div style={{ position: 'relative' }}>
            <MapPin
              size={17}
              color="var(--text-dim)"
              style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }}
            />
            <select
              value={selectedLocation}
              onChange={e => setSelectedLocation(e.target.value)}
              className="form-input"
              style={{ paddingLeft: 42, cursor: 'pointer' }}
            >
              <option value="">All Venues & Blocks</option>
              {uniqueLocations.map(loc => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </div>

          {/* Price Range Filter */}
          <div style={{ position: 'relative' }}>
            <IndianRupee
              size={17}
              color="var(--text-dim)"
              style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }}
            />
            <select
              value={priceTier}
              onChange={e => setPriceTier(e.target.value)}
              className="form-input"
              style={{ paddingLeft: 42, cursor: 'pointer' }}
            >
              <option value="all">All Prices</option>
              <option value="free">Free Admission Only</option>
              <option value="under100">Under ₹100</option>
              <option value="under200">Under ₹200</option>
              <option value="above200">₹200 and Above</option>
            </select>
          </div>

          {/* Sort Order */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <ArrowUpDown size={18} color="var(--text-dim)" />
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className="form-input"
              style={{ cursor: 'pointer' }}
            >
              <option value="date-asc">Date: Soonest First</option>
              <option value="date-desc">Date: Furthest First</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="seats-left">Fewest Seats Remaining</option>
            </select>
          </div>
        </div>

        {/* Filter Summary & Clear Action */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10, marginBottom: 16 }}>
          <span style={{ fontSize: 13, color: 'var(--text-dim)' }}>
            Showing <strong style={{ color: '#fff' }}>{sortedEvents.length}</strong> events in MySQL
          </span>
          {hasActiveFilters && (
            <button
              onClick={handleClearAllFilters}
              className="btn btn-secondary"
              style={{ padding: '6px 12px', fontSize: 12, display: 'flex', alignItems: 'center', gap: 6 }}
            >
              <X size={14} />
              <span>Reset All Filters</span>
            </button>
          )}
        </div>

        {/* Category Pills Strip */}
        <div style={{
          paddingTop: 14,
          borderTop: '1px solid var(--border-subtle)',
          display: 'flex',
          gap: 8,
          overflowX: 'auto',
          paddingBottom: 4
        }}>
          <button
            onClick={() => handleCategoryClick('All')}
            className={`category-pill ${selectedCategory === 'All' ? 'active' : ''}`}
          >
            All Events
          </button>
          {categories.map(cat => (
            <button
              key={cat.id || cat.name}
              onClick={() => handleCategoryClick(cat.name)}
              className={`category-pill ${selectedCategory === cat.name ? 'active' : ''}`}
            >
              {cat.is_cultural ? '🎭 ' : '⚡ '}
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Events Grid / Empty State */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '80px 0', color: 'var(--text-dim)' }}>
          Loading filtered events from MySQL database...
        </div>
      ) : sortedEvents.length === 0 ? (
        <div className="luxe-card" style={{ textAlign: 'center', padding: '60px 20px', maxWidth: 540, margin: '40px auto' }}>
          <Calendar size={48} color="var(--text-dim)" style={{ marginBottom: 16 }} />
          <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8, color: '#fff' }}>No Events Found</h3>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 20 }}>
            No campus events match your active filters. Try clearing dates, adjusting price, or choosing "All Events".
          </p>
          <button onClick={handleClearAllFilters} className="btn btn-primary">
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid-events">
          {sortedEvents.map(event => (
            <EventCard
              key={event.id || event._id}
              event={event}
            />
          ))}
        </div>
      )}
    </div>
  );
}
