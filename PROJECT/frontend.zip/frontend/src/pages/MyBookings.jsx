import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, MapPin, Ticket, AlertTriangle, CheckCircle, XCircle, ArrowRight, Download, ShieldCheck, QrCode, X } from 'lucide-react';
import QRCode from 'qrcode';
import { api, getUser } from '../services/api';

export default function MyBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState(null);
  const [confirmingId, setConfirmingId] = useState(null);
  const [actionMsg, setActionMsg] = useState('');
  const [selectedQrBooking, setSelectedQrBooking] = useState(null);
  const [qrModalDataUrl, setQrModalDataUrl] = useState('');
  const currentUser = getUser();

  useEffect(() => {
    loadBookings();
  }, []);

  const handleConfirmPending = async (bookingId) => {
    setConfirmingId(bookingId);
    try {
      const res = await api.confirmBooking(bookingId);
      setActionMsg('Booking confirmed! Official entry QR ticket generated.');
      await loadBookings();
      setTimeout(() => setActionMsg(''), 4000);
    } catch (err) {
      alert(err.message || 'Failed to confirm booking.');
    } finally {
      setConfirmingId(null);
    }
  };

  const loadBookings = async () => {
    setLoading(true);
    try {
      const res = await api.getMyBookings();
      setBookings(res.bookings || []);
    } catch (err) {
      console.error('Failed to load bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelBooking = async (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this booking? Reserved seats will be released back to the event pool.')) {
      return;
    }

    setCancellingId(bookingId);
    try {
      const res = await api.cancelBooking(bookingId);
      setActionMsg(res.message || 'Booking cancelled successfully.');
      loadBookings();
      setTimeout(() => setActionMsg(''), 4000);
    } catch (err) {
      alert(err.message || 'Failed to cancel booking.');
    } finally {
      setCancellingId(null);
    }
  };

  const handleShowQrModal = async (b) => {
    setSelectedQrBooking(b);
    setQrModalDataUrl('');
    const ticketCode = b.ticket_code || b.booking_reference || `BK-${b.id}`;
    const qrPayload = JSON.stringify({
      ticketCode,
      bookingRef: b.booking_reference,
      eventId: b.event?.id || b.event_id,
      eventTitle: b.event?.title || b.event_title,
      attendee: currentUser?.name || 'Attendee',
      paymentRef: b.payment_id || 'Free Pass',
      status: 'CONFIRMED'
    });

    try {
      const url = await QRCode.toDataURL(qrPayload, {
        errorCorrectionLevel: 'H',
        margin: 2,
        width: 320,
        color: { dark: '#0f172a', light: '#ffffff' }
      });
      setQrModalDataUrl(url);
    } catch (err) {
      console.error('Failed to generate modal QR:', err);
    }
  };

  const handleDownloadTicket = async (b) => {
    const ev = b.event || {};
    const attendeeName = currentUser?.name || 'Registered Attendee';
    const attendeeEmail = currentUser?.email || '';
    const totalDisplay = parseFloat(b.total_amount) === 0 ? 'Free Pass' : `₹${parseFloat(b.total_amount).toFixed(2)}`;
    const dateFormatted = ev.event_date ? new Date(ev.event_date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }) : 'Scheduled Date';
    const ticketCode = b.ticket_code || b.booking_reference;
    const paymentRef = b.payment_id || b.payment_reference || 'N/A (Free)';

    let qrDataUrl = '';
    try {
      qrDataUrl = await QRCode.toDataURL(JSON.stringify({
        ticketCode,
        bookingRef: b.booking_reference,
        paymentRef,
        attendee: attendeeName,
        eventTitle: ev.title
      }), {
        errorCorrectionLevel: 'H',
        margin: 2,
        width: 300,
        color: { dark: '#0f172a', light: '#ffffff' }
      });
    } catch (e) {
      console.error(e);
    }

    const ticketHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>EventHub Pass - ${ticketCode}</title>
          <meta charset="utf-8">
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #060913; color: #fff; padding: 40px 20px; display: flex; justify-content: center; }
            .ticket-card { width: 100%; max-width: 520px; background: #0e1526; border: 2px dashed #6366f1; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
            .poster { width: 100%; height: 180px; object-fit: cover; }
            .body { padding: 24px; }
            .title { font-size: 22px; font-weight: 800; color: #fff; margin-bottom: 8px; }
            .badge-row { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }
            .badge { display: inline-block; background: #10b981; color: #fff; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; }
            .badge-pay { background: #6366f1; color: #fff; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; background: rgba(255,255,255,0.03); padding: 14px; border-radius: 12px; font-size: 13px; }
            .grid dt { color: #94a3b8; font-size: 11px; text-transform: uppercase; font-weight: 600; margin-bottom: 2px; }
            .grid dd { color: #fff; font-weight: 600; word-break: break-all; }
            .qr-box { text-align: center; padding: 18px; background: rgba(0,0,0,0.3); border-radius: 14px; margin-top: 10px; }
            .qr-box img { width: 160px; height: 160px; background: #fff; padding: 10px; border-radius: 10px; display: block; margin: 0 auto 10px; }
            .code { font-family: monospace; font-size: 16px; font-weight: 800; color: #38bdf8; letter-spacing: 1px; }
            .btn-print { margin-top: 20px; width: 100%; padding: 12px; background: #6366f1; color: #fff; border: none; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; }
            @media print { .btn-print { display: none; } body { background: #fff; color: #000; padding: 0; } .ticket-card { border-color: #000; box-shadow: none; } }
          </style>
        </head>
        <body>
          <div class="ticket-card">
            ${ev.banner_url ? `<img src="${ev.banner_url}" class="poster" alt="" />` : ''}
            <div class="body">
              <div class="badge-row">
                <span class="badge">BOOKING CONFIRMED</span>
                <span class="badge-pay">PAYMENT SUCCESSFUL</span>
              </div>
              <h1 class="title">${ev.title || 'Event Pass'}</h1>
              <div class="grid">
                <div><dt>Attendee</dt><dd>${attendeeName}</dd></div>
                <div><dt>Email</dt><dd>${attendeeEmail}</dd></div>
                <div><dt>Booking ID</dt><dd>${b.booking_reference}</dd></div>
                <div><dt>Payment Ref</dt><dd>${paymentRef}</dd></div>
                <div><dt>Event Date</dt><dd>${dateFormatted}</dd></div>
                <div><dt>Timing</dt><dd>${ev.start_time || '09:00'} - ${ev.end_time || '17:00'}</dd></div>
                <div style="grid-column: span 2;"><dt>Venue</dt><dd>${ev.venue || 'Campus Venue'}</dd></div>
                <div><dt>Number of Tickets</dt><dd>${b.num_seats} Seat(s)</dd></div>
                <div><dt>Total Amount</dt><dd>${totalDisplay}</dd></div>
              </div>
              <div class="qr-box">
                ${qrDataUrl ? `<img src="${qrDataUrl}" alt="QR Pass" />` : ''}
                <div class="code">${ticketCode}</div>
                <div style="font-size: 11px; color: #94a3b8; margin-top: 6px;">
                  Present this digital QR pass at the venue entrance for gate verification
                </div>
              </div>
              <button class="btn-print" onclick="window.print()">Print / Save PDF</button>
            </div>
          </div>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(ticketHtml);
      printWindow.document.close();
    } else {
      const blob = new Blob([ticketHtml], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `EventHub_Pass_${ticketCode}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="container" style={{ padding: '40px 20px 80px 20px', maxWidth: 900 }}>
      
      {/* Page Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontSize: 'clamp(1.8rem, 3vw, 2.4rem)', fontWeight: 800, marginBottom: 6 }}>
            My Event Bookings
          </h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
            Manage your seat reservations, view ticket references, or release seats
          </p>
        </div>
        <Link to="/my-tickets" className="btn btn-emerald" style={{ fontSize: 13, padding: '8px 16px' }}>
          <Ticket size={16} />
          <span>My QR Tickets</span>
        </Link>
      </div>

      {actionMsg && (
        <div style={{
          background: 'rgba(16, 185, 129, 0.15)',
          border: '1px solid rgba(16, 185, 129, 0.4)',
          borderRadius: 10,
          padding: '12px 16px',
          color: '#34d399',
          fontSize: 13,
          marginBottom: 20,
          display: 'flex',
          alignItems: 'center',
          gap: 8
        }}>
          <CheckCircle size={18} />
          <span>{actionMsg}</span>
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-dim)' }}>
          Loading your verified booking records from MySQL database...
        </div>
      ) : bookings.length === 0 ? (
        <div className="luxe-card" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <Ticket size={48} color="var(--text-dim)" style={{ marginBottom: 16 }} />
          <h3 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>No Bookings Yet</h3>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>
            You haven't reserved any events yet. Explore upcoming hackathons and technical fests!
          </p>
          <Link to="/events" className="btn btn-primary">
            Explore Events
          </Link>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {bookings.map((b) => {
            const isConfirmed = b.status === 'CONFIRMED';
            const isPending = b.status === 'PENDING_CONFIRMATION';
            const isCancelled = b.status === 'CANCELLED';
            const eventDate = b.event?.event_date ? new Date(b.event.event_date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : 'Upcoming';
            const eventTargetId = b.event_id || b.event?.id || b.eventId;

            return (
              <div
                key={b.id}
                className="luxe-card"
                style={{
                  padding: 24,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 16,
                  borderColor: isConfirmed ? 'var(--border-subtle)' : (isPending ? 'rgba(234, 179, 8, 0.4)' : 'rgba(244, 63, 94, 0.2)')
                }}
              >
                {/* Top Bar: Reference & Status */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 13, fontWeight: 700, color: '#38bdf8', fontFamily: 'monospace' }}>
                      REF: {b.booking_reference}
                    </span>
                    <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                      Booked on {new Date(b.booked_at).toLocaleDateString()}
                    </span>
                    {b.payment_id && (
                      <span style={{
                        fontSize: 11,
                        color: '#a5b4fc',
                        fontFamily: 'monospace',
                        background: 'rgba(99, 102, 241, 0.12)',
                        border: '1px solid rgba(99, 102, 241, 0.25)',
                        padding: '2px 8px',
                        borderRadius: 6
                      }}>
                        Pay Ref: {b.payment_id}
                      </span>
                    )}
                  </div>

                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    {isConfirmed ? (
                      <>
                        <span className="badge badge-emerald" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                          <CheckCircle size={12} />
                          <span>Payment: Successful</span>
                        </span>
                        <span className="badge badge-active">
                          Confirmed
                        </span>
                      </>
                    ) : isPending ? (
                      <>
                        <span className="badge badge-emerald" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                          <CheckCircle size={12} />
                          <span>Payment: Verified</span>
                        </span>
                        <span className="badge badge-amber">
                          Pending Final Confirmation
                        </span>
                      </>
                    ) : (
                      <span className="badge badge-rose">
                        Cancelled
                      </span>
                    )}
                  </div>
                </div>

                {/* Event Details Content */}
                <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
                  {b.event?.banner_url && (
                    <img
                      src={b.event.banner_url}
                      alt=""
                      style={{ width: 84, height: 84, borderRadius: 12, objectFit: 'cover', flexShrink: 0 }}
                    />
                  )}
                    <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: '#818cf8', textTransform: 'uppercase' }}>
                      {b.event?.category || 'Campus Event'}
                    </div>
                    <Link to={`/booking-confirmation/${b.id}`} style={{ textDecoration: 'none' }}>
                      <h3 style={{ fontSize: 17, fontWeight: 700, color: '#fff', marginBottom: 4, transition: 'color 0.2s' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = '#fff'}>
                        {b.event?.title || 'Event Record'}
                      </h3>
                    </Link>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, fontSize: 13, color: 'var(--text-muted)' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Calendar size={13} color="#6366f1" />
                        <span>{eventDate}</span>
                      </span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                        <MapPin size={13} color="#06b6d4" />
                        <span>{b.event?.venue}</span>
                      </span>
                    </div>
                  </div>

                  {/* Seats & Cost */}
                  <div style={{ textAlign: 'right', minWidth: 100 }}>
                    <div style={{ fontSize: 16, fontWeight: 800, color: '#fff' }}>
                      {b.num_seats} Seat{b.num_seats > 1 ? 's' : ''}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                      {parseFloat(b.total_amount) === 0 ? 'Free Entry' : `₹${parseFloat(b.total_amount).toFixed(2)}`}
                    </div>
                  </div>
                </div>

                {/* Pending Confirmation Alert Banner (Requirement 9: Finish confirmation later from My Bookings) */}
                {isPending && (
                  <div style={{
                    background: 'rgba(234, 179, 8, 0.1)',
                    border: '1px solid rgba(234, 179, 8, 0.35)',
                    borderRadius: 12,
                    padding: '12px 16px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: 10
                  }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: '#fef08a' }}>
                        ⚠️ Payment Verified: Ready for Confirmation
                      </div>
                      <div style={{ fontSize: 12, color: '#cbd5e1', marginTop: 2 }}>
                        Seats are reserved in MySQL. Click Confirm Booking to generate your digital QR entry ticket.
                      </div>
                    </div>
                    <button
                      onClick={() => handleConfirmPending(b.id)}
                      disabled={confirmingId === b.id}
                      className="btn btn-primary"
                      style={{ padding: '8px 16px', fontSize: 13, fontWeight: 800, background: '#10b981', display: 'inline-flex', alignItems: 'center', gap: 6 }}
                    >
                      <CheckCircle size={15} />
                      <span>{confirmingId === b.id ? 'Confirming...' : 'Confirm Booking'}</span>
                    </button>
                  </div>
                )}

                {/* Bottom Actions: View Booking & QR Ticket Page, Download Ticket, Cancel */}
                <div style={{
                  paddingTop: 14,
                  borderTop: '1px solid var(--border-subtle)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: 10
                }}>
                  <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                    {b.ticket_code ? (
                      <span>Ticket Pass: <strong style={{ color: '#34d399' }}>{b.ticket_code}</strong></span>
                    ) : (
                      <span>{isPending ? 'Pending Final Confirmation' : 'Pass not active'}</span>
                    )}
                  </div>

                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    {isConfirmed && (
                      <>
                        <button
                          onClick={() => handleCancelBooking(b.id)}
                          disabled={cancellingId === b.id}
                          className="btn btn-danger"
                          style={{ padding: '6px 12px', fontSize: 12 }}
                        >
                          {cancellingId === b.id ? 'Cancelling...' : 'Cancel Booking'}
                        </button>
                        <Link
                          to={`/booking-confirmation/${b.id}`}
                          className="btn btn-emerald"
                          style={{ padding: '6px 12px', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: 5 }}
                          title="Open Booking Details and QR Ticket Page"
                        >
                          <QrCode size={13} />
                          <span>View Booking & QR Ticket</span>
                        </Link>
                        <button
                          onClick={() => handleDownloadTicket(b)}
                          className="btn btn-secondary"
                          style={{ padding: '6px 12px', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: 5 }}
                          title="Download Printable Pass"
                        >
                          <Download size={13} />
                          <span>Download Ticket</span>
                        </button>
                      </>
                    )}

                    {eventTargetId && (
                      <Link
                        to={`/events/${eventTargetId}`}
                        className="btn btn-secondary"
                        style={{ padding: '6px 12px', fontSize: 12, display: 'inline-flex', alignItems: 'center', gap: 5, color: '#38bdf8' }}
                      >
                        <span>View Event Details</span>
                        <ArrowRight size={13} />
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Instant QR Pass Modal */}
      {selectedQrBooking && (
        <div className="modal-backdrop" onClick={() => setSelectedQrBooking(null)}>
          <div 
            className="modal-content" 
            onClick={e => e.stopPropagation()}
            style={{
              maxWidth: 440,
              width: '90%',
              background: '#0d1322',
              border: '1px solid var(--border-glow, rgba(99, 102, 241, 0.4))',
              borderRadius: 20,
              padding: 24,
              textAlign: 'center',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.8)'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#38bdf8', fontSize: 12, fontWeight: 700, textTransform: 'uppercase' }}>
                <QrCode size={16} />
                <span>Verified Entrance Pass</span>
              </div>
              <button 
                type="button" 
                onClick={() => setSelectedQrBooking(null)}
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
              >
                <X size={20} />
              </button>
            </div>

            <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff', marginBottom: 4 }}>
              {selectedQrBooking.event?.title || selectedQrBooking.event_title || 'Campus Event'}
            </h3>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 16 }}>
              Booking ID: <strong style={{ color: '#fff' }}>{selectedQrBooking.booking_reference}</strong> • {selectedQrBooking.num_seats} Seat(s)
            </p>

            {/* High-Resolution Scannable QR Image Container */}
            <div style={{
              width: 180,
              height: 180,
              background: '#ffffff',
              padding: 10,
              borderRadius: 16,
              margin: '0 auto 12px auto',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.6)',
              border: '3px solid #6366f1',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {qrModalDataUrl ? (
                <img 
                  src={qrModalDataUrl} 
                  alt="Scannable QR Pass" 
                  style={{ width: '100%', height: '100%', display: 'block', borderRadius: 6 }}
                />
              ) : (
                <div style={{ color: '#64748b', fontSize: 12 }}>Generating QR...</div>
              )}
            </div>

            <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 900, color: '#38bdf8', letterSpacing: '0.06em' }}>
              {selectedQrBooking.ticket_code || selectedQrBooking.booking_reference}
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 6 }}>
              Present this pass at the entrance gate for instant attendee check-in.
            </div>

            <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
              {qrModalDataUrl && (
                <a
                  href={qrModalDataUrl}
                  download={`EventHub_QR_${selectedQrBooking.ticket_code || selectedQrBooking.booking_reference}.png`}
                  className="btn btn-secondary"
                  style={{
                    flex: 1,
                    padding: '10px 14px',
                    fontSize: 12.5,
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 6
                  }}
                >
                  <Download size={14} />
                  <span>Save .PNG</span>
                </a>
              )}
              <button
                type="button"
                onClick={() => {
                  setSelectedQrBooking(null);
                  handleDownloadTicket(selectedQrBooking);
                }}
                className="btn btn-primary"
                style={{
                  flex: 1,
                  padding: '10px 14px',
                  fontSize: 12.5,
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6
                }}
              >
                <Download size={14} />
                <span>Print Ticket</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
