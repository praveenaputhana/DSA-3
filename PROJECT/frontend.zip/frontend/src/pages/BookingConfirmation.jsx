import React, { useState, useEffect } from 'react';
import { useParams, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  CheckCircle, 
  Calendar, 
  MapPin, 
  Clock, 
  Ticket, 
  Download, 
  ArrowRight, 
  ShieldCheck, 
  QrCode, 
  CreditCard, 
  User, 
  Sparkles,
  RefreshCw,
  Home,
  ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';
import QRCode from 'qrcode';
import { api, getUser } from '../services/api';

export default function BookingConfirmation() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const currentUser = getUser();

  const [bookingData, setBookingData] = useState(location.state?.bookingData || null);
  const [loading, setLoading] = useState(!location.state?.bookingData);
  const [error, setError] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');

  useEffect(() => {
    // Launch celebratory confetti
    try {
      confetti({
        particleCount: 130,
        spread: 100,
        origin: { y: 0.55 }
      });
    } catch (e) {}

    if (!bookingData && id) {
      loadBooking();
    } else if (bookingData) {
      initQr(bookingData);
    }
  }, [id]);

  const initQr = async (data) => {
    if (data.qr_code_data_url) {
      setQrDataUrl(data.qr_code_data_url);
      return;
    }

    const bk = data.booking || data;
    const tkt = data.tickets?.[0] || {};
    const tktCode = tkt.ticketCode || tkt.ticket_code || bk.ticket_code || bk.booking_reference || `TKT-${id}`;

    const payload = JSON.stringify({
      ticketCode: tktCode,
      bookingRef: bk.booking_reference || bk.bookingReference || id,
      eventId: bk.event?.id || bk.event_id,
      eventTitle: bk.event?.title || bk.event_title,
      attendee: bk.attendeeName || bk.attendee_name || currentUser?.name || 'Attendee',
      status: 'CONFIRMED'
    });

    try {
      const url = await QRCode.toDataURL(payload, {
        errorCorrectionLevel: 'H',
        margin: 2,
        width: 340,
        color: { dark: '#0f172a', light: '#ffffff' }
      });
      setQrDataUrl(url);
    } catch (err) {
      console.error('Failed to generate QR client-side:', err);
    }
  };

  const loadBooking = async () => {
    setLoading(true);
    try {
      const res = await api.getBookingById(id);
      if (res.success && res.booking) {
        setBookingData(res);
        initQr(res);
      } else {
        throw new Error(res.message || 'Could not locate booking confirmation record.');
      }
    } catch (err) {
      console.error('Failed to load booking confirmation:', err);
      setError(err.message || 'Booking confirmation not found.');
    } finally {
      setLoading(false);
    }
  };

  // Working Download QR Ticket Function (Saves PNG QR Pass and HTML Boarding Pass)
  const handleDownloadQrTicket = () => {
    if (!bookingData) return;
    const bk = bookingData.booking || bookingData;
    const ev = bk.event || {};
    const tkt = bookingData.tickets?.[0] || {};
    const ticketCode = tkt.ticketCode || tkt.ticket_code || bk.ticket_code || bk.booking_reference || 'TKT-PASS';
    const attendeeName = bk.attendeeName || bk.attendee_name || currentUser?.name || 'Registered Attendee';
    const attendeeEmail = bk.attendeeEmail || bk.attendee_email || currentUser?.email || '';
    const dateFormatted = ev.eventDate || ev.event_date ? new Date(ev.eventDate || ev.event_date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }) : 'Scheduled Date';
    const totalDisplay = parseFloat(bk.totalAmount || bk.total_amount || 0) === 0 ? 'Free Pass' : `₹${parseFloat(bk.totalAmount || bk.total_amount || 0).toFixed(2)}`;

    // 1. Trigger Direct Download of PNG QR Image if available
    if (qrDataUrl) {
      const a = document.createElement('a');
      a.href = qrDataUrl;
      a.download = `EventHub_Ticket_${ticketCode}_QR.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }

    // 2. Open printable formatted digital boarding pass window
    const ticketHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>EventHub Entry Pass - ${ticketCode}</title>
          <meta charset="utf-8">
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #060913; color: #fff; padding: 30px 15px; display: flex; justify-content: center; }
            .ticket-card { width: 100%; max-width: 520px; background: #0e1526; border: 2px dashed #6366f1; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
            .poster { width: 100%; height: 170px; object-fit: cover; }
            .body { padding: 24px; }
            .title { font-size: 22px; font-weight: 800; color: #fff; margin-bottom: 8px; }
            .badge-row { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }
            .badge { display: inline-block; background: #10b981; color: #fff; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; }
            .badge-pay { background: #6366f1; color: #fff; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; background: rgba(255,255,255,0.03); padding: 14px; border-radius: 12px; font-size: 13px; }
            .grid dt { color: #94a3b8; font-size: 11px; text-transform: uppercase; font-weight: 600; margin-bottom: 2px; }
            .grid dd { color: #fff; font-weight: 600; word-break: break-all; }
            .qr-box { text-align: center; padding: 18px; background: rgba(0,0,0,0.3); border-radius: 14px; margin-top: 10px; }
            .qr-box img { width: 160px; height: 160px; background: #fff; padding: 10px; border-radius: 10px; display: block; margin: 0 auto 10px; }
            .code { font-family: monospace; font-size: 16px; font-weight: 800; color: #38bdf8; letter-spacing: 1px; }
            .btn-print { margin-top: 20px; width: 100%; padding: 12px; background: #6366f1; color: #fff; border: none; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; }
            @media print { .btn-print { display: none; } body { background: #fff; color: #000; padding: 0; } .ticket-card { border-color: #000; box-shadow: none; } }
          </style>
        </head>
        <body>
          <div class="ticket-card">
            ${ev.bannerUrl || ev.banner_url ? `<img src="${ev.bannerUrl || ev.banner_url}" class="poster" alt="" />` : ''}
            <div class="body">
              <div class="badge-row">
                <span class="badge">BOOKING CONFIRMED</span>
                <span class="badge-pay">PAYMENT VERIFIED</span>
              </div>
              <h1 class="title">${ev.title || 'Event Pass'}</h1>
              <div class="grid">
                <div><dt>Attendee</dt><dd>${attendeeName}</dd></div>
                <div><dt>Attendee Email</dt><dd>${attendeeEmail}</dd></div>
                <div><dt>Booking ID</dt><dd>${bk.booking_reference || bk.bookingReference || id}</dd></div>
                <div><dt>Event Date</dt><dd>${dateFormatted}</dd></div>
                <div><dt>Time / Slot</dt><dd>${ev.startTime || ev.start_time || '09:00'} - ${ev.endTime || ev.end_time || '17:00'}</dd></div>
                <div><dt>Seats</dt><dd>${bk.numSeats || bk.num_seats || 1} Pass(es)</dd></div>
                <div style="grid-column: span 2;"><dt>Venue</dt><dd>${ev.venue || 'Campus Main Venue'}</dd></div>
                <div><dt>Total Paid</dt><dd>${totalDisplay}</dd></div>
                <div><dt>Status</dt><dd>CONFIRMED</dd></div>
              </div>
              <div class="qr-box">
                ${qrDataUrl ? `<img src="${qrDataUrl}" alt="QR Ticket" />` : ''}
                <div class="code">${ticketCode}</div>
                <div style="font-size: 11px; color: #94a3b8; margin-top: 6px;">
                  Present this digital QR ticket at the gate for contactless check-in
                </div>
              </div>
              <button class="btn-print" onclick="window.print()">Print / Save Pass (PDF)</button>
            </div>
          </div>
        </body>
      </html>
    `;

    const printWin = window.open('', '_blank');
    if (printWin) {
      printWin.document.write(ticketHtml);
      printWin.document.close();
    }
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: '24px 20px 80px', maxWidth: 700, textAlign: 'center' }}>
        <div className="luxe-card" style={{ padding: 48 }}>
          <RefreshCw size={36} color="#6366f1" className="spin-animation" style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>Generating QR Ticket...</h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>
            Retrieving verified booking record from MySQL
          </p>
        </div>
      </div>
    );
  }

  if (error || !bookingData) {
    return (
      <div className="container" style={{ padding: '24px 20px 80px', maxWidth: 640, textAlign: 'center' }}>
        <div className="luxe-card" style={{ padding: 40 }}>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: '#f43f5e', marginBottom: 12 }}>Confirmation Not Found</h2>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>
            {error || 'Unable to locate this booking confirmation. Please verify your bookings dashboard.'}
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <Link to="/my-bookings" className="btn btn-primary">
              Go to My Bookings
            </Link>
            <Link to="/events" className="btn btn-secondary">
              Browse Events
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const bk = bookingData.booking || bookingData;
  const ev = bk.event || {};
  const payment = bookingData.payment || {};
  const tkt = bookingData.tickets?.[0] || {};
  const ticketCode = tkt.ticketCode || tkt.ticket_code || bk.ticket_code || bk.booking_reference || `TKT-${id}`;
  const attendeeName = bk.attendeeName || bk.attendee_name || currentUser?.name || 'Registered Attendee';
  const attendeeEmail = bk.attendeeEmail || bk.attendee_email || currentUser?.email || 'attendee@campus.edu';
  const eventId = ev.id || bk.event_id || ev._id;

  const eventDateFormatted = ev.eventDate || ev.event_date ? new Date(ev.eventDate || ev.event_date).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }) : 'Scheduled Date';

  const slotTimeFormatted = `${ev.startTime || ev.start_time || '09:00'} - ${ev.endTime || ev.end_time || '17:00'}`;
  const totalAmountFormatted = parseFloat(bk.totalAmount || bk.total_amount || 0) === 0 ? 'Free Pass' : `₹${parseFloat(bk.totalAmount || bk.total_amount || 0).toFixed(2)}`;
  const bookingIdDisplay = bk.bookingReference || bk.booking_reference || `BK-${bk.id || id}`;

  return (
    <div className="container" style={{ padding: '20px 20px 80px', maxWidth: 840 }}>
      
      {/* Top Heading Banner - Visible Immediately Near the Top (Requirement: "Show: Your booking is confirmed!") */}
      <div style={{ textAlign: 'center', marginBottom: 24 }}>
        <div style={{
          width: 60,
          height: 60,
          borderRadius: '50%',
          background: 'rgba(16, 185, 129, 0.15)',
          border: '3px solid #10b981',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 12px auto',
          boxShadow: '0 0 35px rgba(16, 185, 129, 0.4)'
        }}>
          <CheckCircle size={36} color="#10b981" />
        </div>

        <span className="badge badge-emerald" style={{ fontSize: 11, marginBottom: 8, padding: '4px 12px' }}>
          VERIFIED IN MYSQL DATABASE
        </span>

        <h1 style={{ fontSize: 'clamp(1.75rem, 3.2vw, 2.3rem)', fontWeight: 900, color: '#fff', marginTop: 4 }}>
          Your booking is confirmed!
        </h1>
        <p style={{ fontSize: 13.5, color: 'var(--text-muted)', marginTop: 4 }}>
          Your digital QR ticket has been generated and activated for event entrance.
        </p>
      </div>

      {/* Main Confirmation Content Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
        gap: 20,
        alignItems: 'start'
      }}>
        
        {/* Left Column: Clear QR Ticket Boarding Pass Card */}
        <div className="luxe-card" style={{
          padding: 24,
          textAlign: 'center',
          background: 'linear-gradient(180deg, rgba(99, 102, 241, 0.1) 0%, rgba(14, 21, 38, 0.95) 100%)',
          border: '2px solid rgba(99, 102, 241, 0.45)',
          borderRadius: 20,
          boxShadow: '0 15px 35px rgba(0,0,0,0.6)'
        }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            color: '#38bdf8',
            fontSize: 12,
            fontWeight: 800,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            marginBottom: 14
          }}>
            <QrCode size={16} />
            <span>Digital Entry QR Pass</span>
          </div>

          {/* High-Resolution QR Ticket Display */}
          <div style={{
            width: 200,
            height: 200,
            background: '#ffffff',
            padding: 12,
            borderRadius: 16,
            margin: '0 auto 14px auto',
            boxShadow: '0 10px 30px rgba(0,0,0,0.7)',
            border: '3px solid #6366f1',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            {qrDataUrl ? (
              <img 
                src={qrDataUrl} 
                alt="Entry QR Ticket" 
                style={{ width: '100%', height: '100%', display: 'block', borderRadius: 6 }}
              />
            ) : (
              <RefreshCw size={28} className="spin-animation" color="#6366f1" />
            )}
          </div>

          <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 900, color: '#38bdf8', letterSpacing: '0.06em' }}>
            {ticketCode}
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 6 }}>
            Scan at campus entrance gate for immediate admission verification
          </p>

          {/* Primary Action: Download QR Ticket Button (Requirement: "Download QR Ticket") */}
          <div style={{ marginTop: 18 }}>
            <button
              type="button"
              onClick={handleDownloadQrTicket}
              className="btn btn-emerald"
              style={{
                width: '100%',
                padding: '12px 18px',
                fontSize: 14,
                fontWeight: 800,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                boxShadow: '0 4px 15px rgba(16, 185, 129, 0.4)'
              }}
            >
              <Download size={16} />
              <span>Download QR Ticket</span>
            </button>
          </div>
        </div>

        {/* Right Column: Clear Event, Slot, Attendee & Booking Details */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          
          {/* Detailed Verification Summary Card */}
          <div className="luxe-card" style={{ padding: 22, borderRadius: 18 }}>
            <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginBottom: 16, paddingBottom: 14, borderBottom: '1px solid var(--border-subtle)' }}>
              {ev.banner_url || ev.bannerUrl ? (
                <img 
                  src={ev.banner_url || ev.bannerUrl} 
                  alt="" 
                  style={{ width: 68, height: 68, borderRadius: 12, objectFit: 'cover' }}
                />
              ) : null}
              <div>
                <span className="badge badge-indigo" style={{ fontSize: 10 }}>
                  {ev.category || 'Cultural & Technical'}
                </span>
                <h2 style={{ fontSize: 17, fontWeight: 800, color: '#fff', marginTop: 4 }}>
                  {ev.title || 'Campus Event'}
                </h2>
              </div>
            </div>

            {/* Structured Key Details (Requirement: event name, booked slot, date, time, venue, booking ID, and attendee name) */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: 12,
              fontSize: 13,
              background: 'rgba(0,0,0,0.25)',
              padding: 16,
              borderRadius: 14,
              border: '1px solid rgba(255,255,255,0.04)'
            }}>
              <div>
                <span style={{ fontSize: 11, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Booking ID
                </span>
                <div style={{ color: '#38bdf8', fontWeight: 800, fontFamily: 'monospace', fontSize: 13 }}>
                  {bookingIdDisplay}
                </div>
              </div>

              <div>
                <span style={{ fontSize: 11, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Attendee Name
                </span>
                <div style={{ color: '#fff', fontWeight: 700, fontSize: 13 }}>
                  {attendeeName}
                </div>
              </div>

              <div>
                <span style={{ fontSize: 11, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Event Date
                </span>
                <div style={{ color: '#fff', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Calendar size={12} color="#6366f1" />
                  <span>{eventDateFormatted}</span>
                </div>
              </div>

              <div>
                <span style={{ fontSize: 11, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Booked Slot & Time
                </span>
                <div style={{ color: '#fff', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Clock size={12} color="#06b6d4" />
                  <span>{slotTimeFormatted}</span>
                </div>
              </div>

              <div style={{ gridColumn: 'span 2' }}>
                <span style={{ fontSize: 11, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Venue
                </span>
                <div style={{ color: '#fff', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <MapPin size={12} color="#10b981" />
                  <span>{ev.venue || 'Campus Auditorium'}</span>
                </div>
              </div>

              <div>
                <span style={{ fontSize: 11, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Reserved Seats
                </span>
                <div style={{ color: '#34d399', fontWeight: 800 }}>
                  {bk.numSeats || bk.num_seats || 1} Seat(s)
                </div>
              </div>

              <div>
                <span style={{ fontSize: 11, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
                  Total Amount
                </span>
                <div style={{ color: '#fff', fontWeight: 800 }}>
                  {totalAmountFormatted}
                </div>
              </div>
            </div>
          </div>

          {/* Requirements: Add working "View Booked Event" and "My Bookings" buttons */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Link 
              to={eventId ? `/events/${eventId}` : '/events'} 
              className="btn btn-secondary"
              style={{
                padding: '12px 16px',
                fontSize: 13.5,
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8
              }}
            >
              <ExternalLink size={15} />
              <span>View Booked Event</span>
            </Link>

            <Link 
              to="/my-bookings" 
              className="btn btn-primary"
              style={{
                padding: '12px 16px',
                fontSize: 13.5,
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8
              }}
            >
              <Ticket size={15} />
              <span>My Bookings</span>
            </Link>
          </div>

        </div>

      </div>

    </div>
  );
}
