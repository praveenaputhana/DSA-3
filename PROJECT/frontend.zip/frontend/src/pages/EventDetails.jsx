import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Tag, 
  Star, 
  ArrowLeft, 
  CheckCircle, 
  AlertCircle,
  Share2,
  Ticket,
  QrCode,
  Download,
  ExternalLink,
  X
} from 'lucide-react';
import QRCode from 'qrcode';
import { api, getUser } from '../services/api';
import BookingModal from '../components/BookingModal';

export default function EventDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [userBooking, setUserBooking] = useState(null);
  const [userQrUrl, setUserQrUrl] = useState('');
  const [showQrModal, setShowQrModal] = useState(false);
  const [confirmingBooking, setConfirmingBooking] = useState(false);
  const currentUser = getUser();

  useEffect(() => {
    loadEventDetails();
  }, [id]);

  const loadEventDetails = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getEventById(id);
      setEvent(res.event);

      // Check if current logged in user has booked this event
      if (currentUser) {
        try {
          const myRes = await api.getMyBookings();
          if (myRes?.bookings) {
            const found = myRes.bookings.find(b =>
              (parseInt(b.event_id, 10) === parseInt(id, 10) || String(b.event?.id) === String(id) || String(b.eventId) === String(id)) &&
              (b.status === 'CONFIRMED' || b.status === 'PENDING_CONFIRMATION')
            );
            if (found) {
              setUserBooking(found);
              const tkt = found.tickets?.[0] || {};
              const ticketCode = tkt.ticketCode || tkt.ticket_code || found.booking_reference;
              const qrPayload = tkt.qrData || JSON.stringify({
                ticketCode,
                bookingRef: found.booking_reference,
                eventId: found.event_id,
                attendee: currentUser?.name || 'Attendee',
                status: found.status
              });

              QRCode.toDataURL(qrPayload, {
                errorCorrectionLevel: 'H',
                margin: 2,
                width: 320,
                color: { dark: '#0f172a', light: '#ffffff' }
              }).then(url => setUserQrUrl(url)).catch(err => console.error(err));
            } else {
              setUserBooking(null);
              setUserQrUrl('');
            }
          }
        } catch (myErr) {
          console.error('Failed to load user booking status:', myErr);
        }
      }
    } catch (err) {
      setError(err.message || 'Failed to load event details.');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmPendingBooking = async () => {
    if (!userBooking) return;
    setConfirmingBooking(true);
    try {
      await api.confirmBooking(userBooking.id);
      await loadEventDetails();
    } catch (err) {
      alert(err.message || 'Failed to confirm booking.');
    } finally {
      setConfirmingBooking(false);
    }
  };

  const handleDownloadTicket = () => {
    if (!userBooking) return;
    const attendeeName = currentUser?.name || userBooking.attendee_name || 'Attendee';
    const attendeeEmail = currentUser?.email || userBooking.attendee_email || '';
    const bookingRef = userBooking.booking_reference || `BK-${userBooking.id}`;
    const firstTkt = userBooking.tickets?.[0] || {};
    const ticketCode = firstTkt.ticketCode || firstTkt.ticket_code || bookingRef;
    const totalPaidDisplay = parseFloat(userBooking.total_amount) === 0 ? 'Free Pass' : `₹${parseFloat(userBooking.total_amount).toFixed(2)}`;

    const ticketHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>EventHub Entry Pass - ${ticketCode}</title>
          <meta charset="utf-8">
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #060913; color: #fff; padding: 40px 20px; display: flex; justify-content: center; }
            .ticket-card { width: 100%; max-width: 520px; background: #0e1526; border: 2px dashed #6366f1; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
            .poster { width: 100%; height: 180px; object-fit: cover; }
            .body { padding: 24px; }
            .title { font-size: 22px; font-weight: 800; color: #fff; margin-bottom: 8px; }
            .badge { display: inline-block; background: #10b981; color: #fff; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; margin-bottom: 16px; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; background: rgba(255,255,255,0.03); padding: 14px; border-radius: 12px; font-size: 13px; }
            .grid dt { color: #94a3b8; font-size: 11px; text-transform: uppercase; font-weight: 600; margin-bottom: 2px; }
            .grid dd { color: #fff; font-weight: 600; word-break: break-all; }
            .qr-box { text-align: center; padding: 18px; background: rgba(0,0,0,0.3); border-radius: 14px; margin-top: 10px; }
            .qr-box img { width: 160px; height: 160px; background: #fff; padding: 10px; border-radius: 10px; display: block; margin: 0 auto 10px; }
            .code { font-family: monospace; font-size: 16px; font-weight: 800; color: #38bdf8; letter-spacing: 1px; }
            .btn-print { margin-top: 20px; width: 100%; padding: 12px; background: #6366f1; color: #fff; border: none; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; }
            @media print { .btn-print { display: none; } body { background: #fff; color: #000; padding: 0; } .ticket-card { border-color: #000; box-shadow: none; } }
          </style>
        </head>
        <body>
          <div class="ticket-card">
            ${event.banner_url || event.bannerUrl ? `<img src="${event.banner_url || event.bannerUrl}" class="poster" alt="" />` : ''}
            <div class="body">
              <span class="badge">OFFICIAL GATE ENTRY PASS</span>
              <h1 class="title">${event.title}</h1>
              <div class="grid">
                <div><dt>Attendee</dt><dd>${attendeeName}</dd></div>
                <div><dt>Email</dt><dd>${attendeeEmail}</dd></div>
                <div><dt>Booking ID</dt><dd>${bookingRef}</dd></div>
                <div><dt>Status</dt><dd>${userBooking.status}</dd></div>
                <div><dt>Date</dt><dd>${event.event_date || 'Upcoming'}</dd></div>
                <div><dt>Time</dt><dd>${event.start_time || '09:00'} - ${event.end_time || '17:00'}</dd></div>
                <div style="grid-column: span 2;"><dt>Venue</dt><dd>${event.venue}</dd></div>
                <div><dt>Reserved Seats</dt><dd>${userBooking.num_seats} Seat(s)</dd></div>
                <div><dt>Amount Paid</dt><dd>${totalPaidDisplay}</dd></div>
              </div>
              <div class="qr-box">
                ${userQrUrl ? `<img src="${userQrUrl}" alt="QR Entry Pass" />` : ''}
                <div class="code">${ticketCode}</div>
                <div style="font-size: 11px; color: #94a3b8; margin-top: 6px;">
                  Present this scannable QR ticket at the campus entrance gate for check-in verification
                </div>
              </div>
              <button class="btn-print" onclick="window.print()">Print / Save PDF</button>
            </div>
          </div>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(ticketHtml);
      printWindow.document.close();
    } else {
      const blob = new Blob([ticketHtml], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `EventHub_Ticket_${ticketCode}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: '80px 20px', textAlign: 'center', color: 'var(--text-dim)' }}>
        Loading event details from database...
      </div>
    );
  }

  if (error || !event) {
    return (
      <div className="container" style={{ padding: '80px 20px', textAlign: 'center' }}>
        <div className="luxe-card" style={{ maxWidth: 500, margin: '0 auto', padding: 40 }}>
          <AlertCircle size={44} color="#f43f5e" style={{ marginBottom: 16 }} />
          <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>Event Not Found</h2>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>
            {error || 'The requested event does not exist or has been removed.'}
          </p>
          <Link to="/events" className="btn btn-primary">
            Back to All Events
          </Link>
        </div>
      </div>
    );
  }

  const available = event.available_seats !== undefined ? event.available_seats : event.availableSeats;
  const total = event.total_capacity || event.totalCapacity || 100;
  const isSoldOut = available <= 0;
  const priceVal = parseFloat(event.price || 0);

  const eventDateObj = new Date(event.event_date || event.eventDate);
  const formattedDate = !isNaN(eventDateObj) ? eventDateObj.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  }) : 'Upcoming';

  return (
    <div className="container" style={{ padding: '30px 20px 80px 20px' }}>
      
      {/* Top Navigation Breadcrumb */}
      <div style={{ marginBottom: 20 }}>
        <button
          onClick={() => navigate(-1)}
          className="btn btn-secondary"
          style={{ padding: '6px 14px', fontSize: 13 }}
        >
          <ArrowLeft size={16} />
          <span>Back</span>
        </button>
      </div>

      {/* Main Two-Column Layout */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 1.8fr) minmax(0, 1.2fr)',
        gap: 36,
        alignItems: 'start'
      }} className="event-details-grid">
        
        {/* LEFT COLUMN: Media, Description, Schedule & Reviews */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
          
          {/* Hero Banner */}
          <div style={{
            position: 'relative',
            borderRadius: 'var(--radius-lg)',
            overflow: 'hidden',
            height: 'clamp(260px, 35vw, 400px)',
            background: '#090d18',
            boxShadow: 'var(--shadow-card)'
          }}>
            <img
              src={event.banner_url || event.bannerUrl || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200'}
              alt={event.title}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
            <div style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(to top, rgba(6, 9, 19, 0.95) 0%, transparent 60%)'
            }} />

            {/* Category Badge & Rating */}
            <div style={{ position: 'absolute', top: 18, left: 18 }}>
              <span className="badge badge-indigo" style={{ padding: '6px 14px', fontSize: 12 }}>
                <Tag size={14} />
                <span>{event.category || event.categoryName}</span>
              </span>
            </div>

            {parseFloat(event.avg_rating) > 0 && (
              <div style={{
                position: 'absolute',
                top: 18,
                right: 18,
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: 'rgba(0, 0, 0, 0.75)',
                padding: '6px 12px',
                borderRadius: 'var(--radius-pill)',
                fontSize: 13,
                color: '#fbbf24',
                fontWeight: 700,
                backdropFilter: 'blur(8px)'
              }}>
                <Star size={14} fill="#fbbf24" />
                <span>{event.avg_rating} / 5</span>
                <span style={{ color: '#94a3b8', fontSize: 11 }}>({event.total_reviews} reviews)</span>
              </div>
            )}
          </div>

          {/* Title & Metadata Badges */}
          <div>
            <h1 style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.5rem)', fontWeight: 800, lineHeight: 1.25, marginBottom: 14 }}>
              {event.title}
            </h1>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, fontSize: 14, color: 'var(--text-muted)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Calendar size={18} color="#6366f1" />
                <span>{formattedDate}</span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Clock size={18} color="#06b6d4" />
                <span>{event.start_time || event.startTime} - {event.end_time || event.endTime}</span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <MapPin size={18} color="#10b981" />
                <span>{event.venue}</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="luxe-card" style={{ padding: 28 }}>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 12, color: '#fff' }}>
              About This Event
            </h3>
            <p style={{ fontSize: 15, color: '#cbd5e1', lineHeight: 1.7, whiteSpace: 'pre-line' }}>
              {event.description}
            </p>
          </div>

          {/* Schedule Breakdown */}
          {event.schedule && event.schedule.length > 0 && (
            <div className="luxe-card" style={{ padding: 28 }}>
              <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20, color: '#fff' }}>
                Event Schedule & Breakdown
              </h3>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 18, position: 'relative' }}>
                {event.schedule.map((item, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      gap: 16,
                      alignItems: 'flex-start',
                      paddingLeft: 12,
                      borderLeft: '2px solid rgba(99, 102, 241, 0.4)'
                    }}
                  >
                    <div style={{
                      minWidth: 90,
                      fontSize: 12,
                      fontWeight: 700,
                      color: '#38bdf8',
                      padding: '4px 8px',
                      background: 'rgba(6, 182, 212, 0.1)',
                      borderRadius: 6,
                      textAlign: 'center'
                    }}>
                      {item.time}
                    </div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 2 }}>
                        {item.title}
                      </div>
                      {item.description && (
                        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                          {item.description}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Attendee Reviews */}
          <div className="luxe-card" style={{ padding: 28 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <h3 style={{ fontSize: 18, fontWeight: 700, color: '#fff' }}>
                Attendee Ratings & Feedback
              </h3>
              <span className="badge badge-amber">
                ⭐ {event.avg_rating} Average
              </span>
            </div>

            {event.reviews && event.reviews.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {event.reviews.map((r, i) => (
                  <div
                    key={r.id || i}
                    style={{
                      background: 'rgba(255, 255, 255, 0.02)',
                      border: '1px solid var(--border-subtle)',
                      borderRadius: 12,
                      padding: 14
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ fontWeight: 700, fontSize: 14 }}>{r.reviewer_name}</span>
                      <div style={{ display: 'flex', gap: 2 }}>
                        {[...Array(5)].map((_, starI) => (
                          <Star
                            key={starI}
                            size={13}
                            fill={starI < r.rating ? "#fbbf24" : "none"}
                            color={starI < r.rating ? "#fbbf24" : "var(--text-dim)"}
                          />
                        ))}
                      </div>
                    </div>
                    <p style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.5 }}>
                      "{r.comments}"
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p style={{ fontSize: 13, color: 'var(--text-dim)' }}>
                No reviews yet. Be the first to attend and share your feedback!
              </p>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Reservation Card & Location Sidebar */}
        <div style={{ position: 'sticky', top: 92, display: 'flex', flexDirection: 'column', gap: 20 }}>
          
          {/* User's Booking Status Card (Requirement 4: Show user's booking status and QR tickets on Event Details page) */}
          {userBooking && (
            <div className="luxe-card" style={{
              padding: 24,
              border: userBooking.status === 'CONFIRMED' ? '2px solid rgba(16, 185, 129, 0.45)' : '2px solid rgba(234, 179, 8, 0.45)',
              background: userBooking.status === 'CONFIRMED' 
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(99, 102, 241, 0.08))'
                : 'linear-gradient(135deg, rgba(234, 179, 8, 0.12), rgba(99, 102, 241, 0.08))',
              boxShadow: '0 12px 35px rgba(0, 0, 0, 0.5)'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <CheckCircle size={18} color={userBooking.status === 'CONFIRMED' ? '#10b981' : '#facc15'} />
                  <span style={{ fontSize: 13, fontWeight: 800, color: '#fff', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Your Booking Status
                  </span>
                </div>
                <span className={userBooking.status === 'CONFIRMED' ? 'badge badge-emerald' : 'badge badge-amber'} style={{ fontSize: 11, padding: '4px 10px' }}>
                  {userBooking.status === 'CONFIRMED' ? 'Confirmed' : 'Pending Confirmation'}
                </span>
              </div>

              {/* Scannable Gate Entry QR Ticket Display */}
              {userBooking.status === 'CONFIRMED' && (
                <div style={{
                  background: '#ffffff',
                  padding: 10,
                  borderRadius: 14,
                  width: 150,
                  height: 150,
                  margin: '0 auto 12px auto',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '2px solid #6366f1',
                  boxShadow: '0 8px 25px rgba(0, 0, 0, 0.5)'
                }}>
                  {userQrUrl ? (
                    <img src={userQrUrl} alt="Gate Entry QR" style={{ width: '100%', height: '100%', display: 'block', borderRadius: 4 }} />
                  ) : (
                    <QrCode size={40} color="#6366f1" />
                  )}
                </div>
              )}

              <div style={{ textAlign: 'center', marginBottom: 14 }}>
                <div style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 800, color: '#38bdf8' }}>
                  {userBooking.booking_reference || `BK-${userBooking.id}`}
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3 }}>
                  {userBooking.num_seats} Seat(s) Reserved • Attendee: <strong style={{ color: '#fff' }}>{currentUser?.name || userBooking.attendee_name || 'Attendee'}</strong>
                </div>
                <div style={{ fontSize: 12, color: '#34d399', fontWeight: 700, marginTop: 2 }}>
                  Total Paid: {parseFloat(userBooking.total_amount) === 0 ? 'Free Pass' : `₹${parseFloat(userBooking.total_amount).toFixed(2)}`}
                </div>
              </div>

              {userBooking.status === 'PENDING_CONFIRMATION' && (
                <div style={{ marginBottom: 14 }}>
                  <p style={{ fontSize: 12, color: '#fef08a', marginBottom: 8, textAlign: 'center' }}>
                    Payment verified! Confirm now to generate your entrance QR ticket.
                  </p>
                  <button
                    onClick={handleConfirmPendingBooking}
                    disabled={confirmingBooking}
                    className="btn btn-primary"
                    style={{ width: '100%', padding: '10px 14px', fontSize: 13, fontWeight: 800, background: '#10b981' }}
                  >
                    {confirmingBooking ? 'Confirming...' : 'Confirm Booking'}
                  </button>
                </div>
              )}

              {/* Four Working Action Buttons (Requirement 5): View QR Ticket, Download Ticket, My Bookings */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
                {userBooking.status === 'CONFIRMED' && (
                  <>
                    <button
                      onClick={() => setShowQrModal(true)}
                      className="btn btn-primary"
                      style={{ padding: '8px 10px', fontSize: 12, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}
                    >
                      <QrCode size={14} />
                      <span>View QR Ticket</span>
                    </button>

                    <button
                      onClick={handleDownloadTicket}
                      className="btn btn-secondary"
                      style={{ padding: '8px 10px', fontSize: 12, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}
                    >
                      <Download size={14} />
                      <span>Download Ticket</span>
                    </button>
                  </>
                )}

                <Link
                  to="/bookings"
                  className="btn btn-secondary"
                  style={{
                    gridColumn: userBooking.status === 'CONFIRMED' ? 'span 2' : 'span 2',
                    padding: '8px 10px',
                    fontSize: 12,
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 5
                  }}
                >
                  <Ticket size={14} />
                  <span>My Bookings</span>
                </Link>
              </div>
            </div>
          )}
          
          <div className="luxe-card" style={{ padding: 28 }}>
            
            {/* Price Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 20 }}>
              <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Ticket Price</span>
              <span style={{ fontSize: 26, fontWeight: 900, color: '#fff' }}>
                {priceVal === 0 ? 'Free' : `₹${priceVal}`}
              </span>
            </div>

            {/* Seat Availability Progress Bar */}
            <div style={{ marginBottom: 24 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 8 }}>
                <span style={{ color: 'var(--text-dim)' }}>Seat Availability</span>
                <span style={{ fontWeight: 700, color: isSoldOut ? '#f43f5e' : '#34d399' }}>
                  {isSoldOut ? 'Sold Out' : `${available} remaining of ${total}`}
                </span>
              </div>

              <div style={{ height: 8, borderRadius: 999, background: 'rgba(255, 255, 255, 0.08)', overflow: 'hidden' }}>
                <div style={{
                  width: `${Math.min(100, Math.round(((total - available) / total) * 100))}%`,
                  height: '100%',
                  background: isSoldOut ? '#f43f5e' : 'linear-gradient(90deg, #6366f1, #06b6d4)',
                  borderRadius: 999
                }} />
              </div>
            </div>

            {/* Key Features Bullet List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13, color: 'var(--text-muted)', marginBottom: 24 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <CheckCircle size={15} color="#10b981" />
                <span>Instant Digital Ticket with QR Verification</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <CheckCircle size={15} color="#10b981" />
                <span>Downloadable Boarding-Pass for Gate Entry</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <CheckCircle size={15} color="#10b981" />
                <span>Self-Service Cancellation Allowed</span>
              </div>
            </div>

            {/* Primary Action Button */}
            <button
              onClick={() => navigate(`/book/${event.id}`)}
              disabled={isSoldOut}
              className={`btn ${isSoldOut ? 'btn-secondary' : 'btn-emerald'}`}
              style={{ width: '100%', padding: '14px 20px', fontSize: 16 }}
            >
              <Ticket size={18} />
              <span>{isSoldOut ? 'Sold Out' : (userBooking ? `Book Additional Passes (₹${priceVal})` : `Book Now (₹${priceVal})`)}</span>
            </button>
          </div>

          {/* Venue & Location Details Box */}
          <div className="luxe-card" style={{ padding: 24 }}>
            <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 12 }}>
              Venue & Location
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13, color: 'var(--text-muted)' }}>
              <div>
                <strong style={{ color: '#fff', display: 'block' }}>{event.venue}</strong>
                <span>{event.location}</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                Organizer: {event.organizer_name}
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Booking Modal */}
      {isBookingOpen && (
        <BookingModal
          event={event}
          onClose={() => setIsBookingOpen(false)}
          onBookingSuccess={() => loadEventDetails()}
        />
      )}

      {/* View QR Ticket Modal Popup (Requirement 5) */}
      {showQrModal && userBooking && (
        <div className="modal-backdrop" onClick={() => setShowQrModal(false)} style={{ zIndex: 1200 }}>
          <div 
            className="modal-content"
            onClick={e => e.stopPropagation()}
            style={{
              maxWidth: 420,
              width: '90%',
              background: '#0d1322',
              border: '2px solid #6366f1',
              borderRadius: 20,
              padding: 24,
              textAlign: 'center',
              boxShadow: '0 25px 60px rgba(0,0,0,0.9)'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#38bdf8', fontSize: 12, fontWeight: 800, textTransform: 'uppercase' }}>
                <QrCode size={16} />
                <span>Verified Entrance Pass</span>
              </div>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer' }}
              >
                <X size={20} />
              </button>
            </div>

            <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff', marginBottom: 4 }}>
              {event.title}
            </h3>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 16 }}>
              Booking Reference: <strong style={{ color: '#fff' }}>{userBooking.booking_reference}</strong>
            </p>

            <div style={{
              width: 220,
              height: 220,
              background: '#ffffff',
              padding: 12,
              borderRadius: 16,
              margin: '0 auto 14px auto',
              boxShadow: '0 10px 30px rgba(0,0,0,0.6)',
              border: '3px solid #6366f1',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {userQrUrl ? (
                <img src={userQrUrl} alt="Scannable QR" style={{ width: '100%', height: '100%', display: 'block', borderRadius: 4 }} />
              ) : (
                <QrCode size={50} color="#6366f1" />
              )}
            </div>

            <div style={{ fontFamily: 'monospace', fontSize: 16, fontWeight: 900, color: '#38bdf8', letterSpacing: '0.08em', marginBottom: 6 }}>
              {userBooking.tickets?.[0]?.ticketCode || userBooking.tickets?.[0]?.ticket_code || userBooking.booking_reference}
            </div>

            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 18 }}>
              Attendee: <strong>{currentUser?.name || userBooking.attendee_name}</strong> • {userBooking.num_seats} Seat(s)
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              {userQrUrl && (
                <a
                  href={userQrUrl}
                  download={`QR_Pass_${userBooking.booking_reference}.png`}
                  className="btn btn-primary"
                  style={{ flex: 1, padding: '10px 14px', fontSize: 13, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
                >
                  <Download size={14} />
                  <span>Save QR (.png)</span>
                </a>
              )}
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="btn btn-secondary"
                style={{ flex: 1, padding: '10px 14px', fontSize: 13 }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Inline Responsive Query for 2-column details */}
      <style>{`
        @media (max-width: 860px) {
          .event-details-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
