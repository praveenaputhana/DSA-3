const API_BASE = '/api';

/**
 * Token and Auth State Helpers
 */
export const getToken = () => localStorage.getItem('eventhub_token');
export const setToken = (token) => localStorage.setItem('eventhub_token', token);
export const removeToken = () => localStorage.removeItem('eventhub_token');

export const getUser = () => {
  const user = localStorage.getItem('eventhub_user');
  try {
    return user ? JSON.parse(user) : null;
  } catch (e) {
    return null;
  }
};
export const setUser = (user) => localStorage.setItem('eventhub_user', JSON.stringify(user));
export const removeUser = () => localStorage.removeItem('eventhub_user');

/**
 * Universal API Request Wrapper
 */
async function apiRequest(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({
    success: false,
    message: 'Invalid response from server'
  }));

  if (!response.ok) {
    if (response.status === 401) {
      removeToken();
      removeUser();
      throw new Error(data.message || 'Session expired. Please sign in to continue.');
    }
    throw new Error(data.message || `Request failed with status ${response.status}`);
  }

  return data;
}

export const api = {
  // Authentication
  login: (credentials) => apiRequest('/auth/login', {
    method: 'POST',
    body: JSON.stringify(credentials)
  }),

  register: (userData) => apiRequest('/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData)
  }),

  getMe: () => apiRequest('/auth/me'),

  updateProfile: (profileData) => apiRequest('/auth/profile', {
    method: 'PUT',
    body: JSON.stringify(profileData)
  }),

  getDashboardStats: () => apiRequest('/stats/dashboard'),

  // Events
  getEvents: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/events${query ? `?${query}` : ''}`);
  },

  getEventById: (id) => apiRequest(`/events/${id}`),

  getCategories: () => apiRequest('/categories'),

  createCategory: (catData) => apiRequest('/categories', {
    method: 'POST',
    body: JSON.stringify(catData)
  }),

  createEvent: (eventData) => apiRequest('/events', {
    method: 'POST',
    body: JSON.stringify(eventData)
  }),

  updateEvent: (id, eventData) => apiRequest(`/events/${id}`, {
    method: 'PUT',
    body: JSON.stringify(eventData)
  }),

  togglePublishEvent: (id) => apiRequest(`/events/${id}/publish`, {
    method: 'PATCH'
  }),

  deleteEvent: (id) => apiRequest(`/events/${id}`, {
    method: 'DELETE'
  }),

  // Bookings & Self-Service
  bookEvent: (bookingData) => apiRequest('/bookings', {
    method: 'POST',
    body: JSON.stringify(bookingData)
  }),

  getMyBookings: () => apiRequest('/bookings/my'),

  getBookingById: (id) => apiRequest(`/bookings/${id}`),

  getAllBookings: () => apiRequest('/bookings/all'),

  getEventBookings: (eventId) => apiRequest(`/bookings/event/${eventId}`),

  cancelBooking: (bookingId) => apiRequest(`/bookings/${bookingId}/cancel`, {
    method: 'POST'
  }),

  confirmBooking: (bookingId) => apiRequest(`/bookings/${bookingId}/confirm`, {
    method: 'POST'
  }),

  // Payment Gateway (Razorpay & Dynamic QR)
  getPaymentConfig: () => apiRequest('/payments/config'),

  generatePaymentQr: (payload) => apiRequest('/payments/generate-qr', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),

  checkPaymentStatus: (orderId) => apiRequest(`/payments/verify-status/${orderId}`),

  simulateQrPayment: (orderId) => apiRequest('/payments/simulate-qr-payment', {
    method: 'POST',
    body: JSON.stringify({ order_id: orderId })
  }),

  createPaymentOrder: (orderData) => apiRequest('/payments/create-order', {
    method: 'POST',
    body: JSON.stringify(orderData)
  }),

  verifyPayment: (verificationData) => apiRequest('/payments/verify', {
    method: 'POST',
    body: JSON.stringify(verificationData)
  }),

  // Digital Tickets
  getMyTickets: () => apiRequest('/tickets/my'),

  getTicketById: (ticketId) => apiRequest(`/tickets/${ticketId}`),

  getTicketByCode: (ticketCode) => apiRequest(`/tickets/code/${ticketCode}`),

  // QR Code Check-In
  scanTicket: (scanData) => apiRequest('/checkin/scan', {
    method: 'POST',
    body: JSON.stringify(scanData)
  }),

  getCheckinStats: () => apiRequest('/checkin/stats'),

  // Rating & Feedback
  submitFeedback: (feedbackData) => apiRequest('/feedback', {
    method: 'POST',
    body: JSON.stringify(feedbackData)
  }),

  getEventFeedback: (eventId) => apiRequest(`/feedback/event/${eventId}`),

  getAllFeedback: () => apiRequest('/feedback/all'),

  // Notifications
  getNotifications: () => apiRequest('/notifications'),

  getUnreadCount: () => apiRequest('/notifications/unread-count'),

  markNotificationRead: (id) => apiRequest(`/notifications/${id}/read`, {
    method: 'PATCH'
  }),

  markAllNotificationsRead: () => apiRequest('/notifications/read-all', {
    method: 'PATCH'
  }),

  sendNotification: (notificationData) => apiRequest('/notifications', {
    method: 'POST',
    body: JSON.stringify(notificationData)
  }),

  // Payment Reference Verification (for personal PhonePe QR)
  submitPaymentReference: (data) => apiRequest('/payments/submit-reference', {
    method: 'POST',
    body: JSON.stringify(data)
  }),

  adminVerifyPayment: (orderId, data) => apiRequest(`/payments/admin-verify/${orderId}`, {
    method: 'PATCH',
    body: JSON.stringify(data)
  }),

  getPendingPaymentReferences: () => apiRequest('/payments/pending-references'),
};

