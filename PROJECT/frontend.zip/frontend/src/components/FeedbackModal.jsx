import React, { useState } from 'react';
import { X, Star, MessageSquare, Send } from 'lucide-react';
import { api } from '../services/api';

export default function FeedbackModal({ event, onClose, onSuccess }) {
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [comments, setComments] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!event) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await api.submitFeedback({
        event_id: event.id,
        rating,
        comments
      });
      onSuccess('Thank you! Your feedback and rating have been recorded.');
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to submit feedback.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 480, padding: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div>
            <h3 style={{ fontSize: 18, fontWeight: 700 }}>Event Feedback & Rating</h3>
            <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>{event.title}</p>
          </div>
          <button 
            onClick={onClose}
            style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
          >
            <X size={18} />
          </button>
        </div>

        {error && (
          <div style={{
            background: 'rgba(244, 63, 94, 0.15)',
            border: '1px solid rgba(244, 63, 94, 0.3)',
            borderRadius: 8,
            padding: 10,
            color: '#fb7185',
            fontSize: 13,
            marginBottom: 14
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Star Rating Selector */}
          <div style={{ textAlign: 'center', padding: '10px 0' }}>
            <label className="input-label" style={{ marginBottom: 10 }}>Overall Experience</label>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 8 }}>
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => setRating(star)}
                  style={{
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    padding: 4,
                    transform: (hoverRating || rating) >= star ? 'scale(1.15)' : 'scale(1)',
                    transition: 'transform 0.15s ease'
                  }}
                >
                  <Star
                    size={32}
                    fill={(hoverRating || rating) >= star ? '#fbbf24' : 'none'}
                    color={(hoverRating || rating) >= star ? '#fbbf24' : '#475569'}
                  />
                </button>
              ))}
            </div>
            <div style={{ fontSize: 12, color: '#fbbf24', marginTop: 6, fontWeight: 600 }}>
              {rating === 5 && 'Outstanding! Loved it'}
              {rating === 4 && 'Very Good experience'}
              {rating === 3 && 'Average / Met expectations'}
              {rating === 2 && 'Below expectations'}
              {rating === 1 && 'Poor experience'}
            </div>
          </div>

          <div>
            <label className="input-label">Detailed Comments & Suggestions</label>
            <textarea
              rows={4}
              required
              placeholder="What did you enjoy most? How can the organizers improve next time?"
              className="input-field"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              style={{ resize: 'vertical' }}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary"
            style={{ width: '100%', padding: '12px' }}
          >
            <Send size={16} />
            <span>{loading ? 'Submitting...' : 'Submit Feedback'}</span>
          </button>
        </form>
      </div>
    </div>
  );
}
