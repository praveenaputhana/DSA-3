import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle, 
  XCircle, 
  QrCode, 
  AlertTriangle, 
  Star, 
  Copy, 
  Check, 
  Download,
  Users
} from 'lucide-react';

export default function TicketCard({ ticket, onCancelBooking, onOpenFeedback }) {
  const [copied, setCopied] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  const isCheckedIn = ticket.ticket_status === 'CHECKED_IN';
  const isCancelled = ticket.ticket_status === 'CANCELLED' || ticket.booking_status === 'CANCELLED';
  const isActive = ticket.ticket_status === 'ACTIVE' && !isCancelled;

  const formattedDate = new Date(ticket.event_date).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  const handleCopyCode = () => {
    navigator.clipboard.writeText(ticket.ticket_code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExecuteCancel = async () => {
    try {
      setCancelling(true);
      await onCancelBooking(ticket.booking_id);
      setConfirmCancel(false);
    } finally {
      setCancelling(false);
    }
  };

  const handleDownloadTicket = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>EventHub Pass - ${ticket.ticket_code}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 40px; background: #0f172a; color: #fff; text-align: center; }
            .card { max-width: 420px; margin: 0 auto; background: #1e1b4b; border-radius: 20px; padding: 30px; border: 2px dashed #6366f1; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
            h2 { margin: 10px 0 16px; font-size: 22px; color: #38bdf8; font-weight: 800; }
            .info { margin: 20px 0; font-size: 13.5px; text-align: left; line-height: 2; color: #cbd5e1; background: rgba(0,0,0,0.3); padding: 16px; border-radius: 12px; }
            .qr { margin: 20px 0; background: #fff; padding: 12px; display: inline-block; border-radius: 12px; }
            .code { font-family: monospace; font-size: 18px; font-weight: bold; letter-spacing: 2px; color: #a5b4fc; }
            .footer { font-size: 12px; color: #94a3b8; margin-top: 14px; }
          </style>
        </head>
        <body>
          <div class="card">
            <div style="font-size: 11px; letter-spacing: 2px; color: #a5b4fc; font-weight: bold;">EVENTHUB DIGITAL PASS</div>
            <h2>${ticket.event_title}</h2>
            <div class="info">
              <div><strong>Attendee:</strong> ${ticket.attendee_name || 'Guest'}</div>
              <div><strong>Date:</strong> ${formattedDate}</div>
              <div><strong>Timing:</strong> ${ticket.start_time?.substring(0, 5)} - ${ticket.end_time?.substring(0, 5)}</div>
              <div><strong>Venue:</strong> ${ticket.venue}</div>
              ${ticket.location ? `<div><strong>Location:</strong> ${ticket.location}</div>` : ''}
              <div><strong>Seats Reserved:</strong> ${ticket.num_seats || 1} Seat(s)</div>
              <div><strong>Booking Ref:</strong> ${ticket.booking_reference}</div>
              <div><strong>Pass Status:</strong> ${ticket.ticket_status}</div>
            </div>
            <div class="qr">
              ${ticket.qr_image ? `<img src="${ticket.qr_image}" width="160" height="160" />` : ''}
            </div>
            <div class="code">${ticket.ticket_code}</div>
            <div class="footer">Please present this digital pass at the entrance scanner.</div>
          </div>
          <script>window.onload = () => { setTimeout(() => { window.print(); }, 400); }</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="ticket-pass" style={{ maxWidth: 440, margin: '0 auto', width: '100%' }}>
      {/* Top Header Section of Ticket */}
      <div style={{
        padding: '20px 22px 14px',
        background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(6, 182, 212, 0.15))',
        borderBottom: '1px solid rgba(255, 255, 255, 0.08)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', color: '#a5b4fc', textTransform: 'uppercase' }}>
            DIGITAL BOARDING PASS
          </span>

          {/* Status Badge */}
          {isActive && (
            <span className="badge badge-active">
              <CheckCircle size={12} />
              ACTIVE PASS
            </span>
          )}
          {isCheckedIn && (
            <span className="badge badge-checkedin">
              <CheckCircle size={12} />
              CHECKED IN
            </span>
          )}
          {isCancelled && (
            <span className="badge badge-cancelled">
              <XCircle size={12} />
              CANCELLED
            </span>
          )}
        </div>

        <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff', marginBottom: 6 }}>
          {ticket.event_title}
        </h3>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-muted)' }}>
          <MapPin size={13} color="var(--accent-cyan)" />
          <span>{ticket.venue}</span>
        </div>
      </div>

      {/* Middle Grid Details */}
      <div style={{ padding: '16px 22px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <div style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
              ATTENDEE
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>
              {ticket.attendee_name || 'Registered Guest'}
            </div>
          </div>

          <div>
            <div style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
              RESERVED SEATS
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#38bdf8', display: 'flex', alignItems: 'center', gap: 4 }}>
              <Users size={14} />
              <span>{ticket.num_seats || 1} Seat(s)</span>
            </div>
          </div>

          <div>
            <div style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
              EVENT DATE
            </div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#cbd5e1' }}>
              {formattedDate}
            </div>
          </div>

          <div>
            <div style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 600 }}>
              TIMING
            </div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#cbd5e1' }}>
              {ticket.start_time?.substring(0, 5)} - {ticket.end_time?.substring(0, 5)}
            </div>
          </div>
        </div>

        {/* Perforated Divider */}
        <div className="ticket-perforation" />

        {/* Bottom Section: Scannable QR Code */}
        <div style={{
          marginTop: 10,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          background: 'rgba(15, 23, 42, 0.7)',
          borderRadius: 16,
          padding: 16,
          border: '1px solid var(--border-glass)'
        }}>
          {/* QR Code Container */}
          <div style={{
            background: '#ffffff',
            padding: 10,
            borderRadius: 12,
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
            marginBottom: 10,
            opacity: isCancelled ? 0.35 : 1,
            filter: isCancelled ? 'grayscale(100%)' : 'none',
            position: 'relative'
          }}>
            {ticket.qr_image ? (
              <img
                src={ticket.qr_image}
                alt="Ticket QR Code"
                style={{ width: 140, height: 140, display: 'block' }}
              />
            ) : (
              <div style={{ width: 140, height: 140, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <QrCode size={90} color="#1e1b4b" />
              </div>
            )}

            {isCancelled && (
              <div style={{
                position: 'absolute',
                inset: 0,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'rgba(244, 63, 94, 0.85)',
                color: '#fff',
                fontWeight: 800,
                fontSize: 14,
                borderRadius: 12,
                transform: 'rotate(-15deg)',
                letterSpacing: '0.1em'
              }}>
                VOID / CANCELLED
              </div>
            )}
          </div>

          {/* Ticket Code and Quick Copy */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: '#cbd5e1', letterSpacing: '0.05em' }}>
              {ticket.ticket_code}
            </span>
            <button
              onClick={handleCopyCode}
              title="Copy code for Admin QR check-in"
              style={{
                background: 'rgba(255, 255, 255, 0.08)',
                border: 'none',
                borderRadius: 6,
                padding: '4px 6px',
                color: copied ? '#34d399' : 'var(--text-muted)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center'
              }}
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
            </button>
          </div>

          <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>
            Booking Ref: {ticket.booking_reference}
          </div>

          {isCheckedIn && ticket.checked_in_at && (
            <div style={{
              marginTop: 8,
              fontSize: 11,
              color: '#38bdf8',
              background: 'rgba(6, 182, 212, 0.12)',
              padding: '4px 10px',
              borderRadius: 6,
              fontWeight: 600
            }}>
              ✓ Verified at {new Date(ticket.checked_in_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
          )}
        </div>

        {/* Self-Service Actions: Cancel Booking or Review Event */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={handleDownloadTicket}
              className="btn btn-secondary"
              style={{ flex: 1, fontSize: 12, padding: '8px 12px' }}
              title="Download or Print Ticket Pass"
            >
              <Download size={14} />
              <span>Download Pass</span>
            </button>

            <button
              onClick={() => onOpenFeedback({ id: ticket.event_id, title: ticket.event_title })}
              className="btn btn-secondary"
              style={{ flex: 1, fontSize: 12, padding: '8px 12px' }}
            >
              <Star size={14} color="#fbbf24" />
              <span>Rate Event</span>
            </button>
          </div>

          {isActive && !confirmCancel && (
            <button
              onClick={() => setConfirmCancel(true)}
              className="btn btn-danger"
              style={{ width: '100%', fontSize: 12, padding: '8px 12px' }}
            >
              Cancel Booking & Release Seats
            </button>
          )}

          {confirmCancel && (
            <div style={{ display: 'flex', gap: 6 }}>
              <button
                onClick={handleExecuteCancel}
                disabled={cancelling}
                className="btn btn-danger"
                style={{ flex: 1, fontSize: 11, padding: '8px' }}
              >
                {cancelling ? 'Releasing Seats...' : 'Yes, Cancel Booking'}
              </button>
              <button
                onClick={() => setConfirmCancel(false)}
                className="btn btn-secondary"
                style={{ fontSize: 11, padding: '8px 14px' }}
              >
                Keep Pass
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
