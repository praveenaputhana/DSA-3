import React from 'react';
import { X, Bell, Calendar, AlertCircle, Info, Check, CheckCheck } from 'lucide-react';
import { api } from '../services/api';

export default function NotificationCenter({ 
  isOpen, 
  onClose, 
  notifications, 
  onRefresh, 
  onNotificationRead 
}) {
  if (!isOpen) return null;

  const handleMarkAsRead = async (id) => {
    try {
      await api.markNotificationRead(id);
      onNotificationRead(id);
    } catch (err) {
      console.error('Error marking notification read:', err);
    }
  };

  const getIconForType = (type) => {
    switch (type) {
      case 'UPDATE':
        return <Info size={16} color="#38bdf8" />;
      case 'REMINDER':
        return <Calendar size={16} color="#a855f7" />;
      case 'CANCELLATION':
        return <AlertCircle size={16} color="#fb7185" />;
      default:
        return <Bell size={16} color="#fbbf24" />;
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className="modal-content" 
        onClick={(e) => e.stopPropagation()} 
        style={{ maxWidth: 500, padding: 22 }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 34,
              height: 34,
              borderRadius: 10,
              background: 'rgba(99, 102, 241, 0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#818cf8'
            }}>
              <Bell size={18} />
            </div>
            <div>
              <h3 style={{ fontSize: 17, fontWeight: 700 }}>Notifications & Alerts</h3>
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                Real-time updates regarding your booked events and venue details
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Notifications List */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 420, overflowY: 'auto' }}>
          {notifications.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '36px 0', color: 'var(--text-dim)', fontSize: 13 }}>
              No notifications yet. You're completely up to date!
            </div>
          ) : (
            notifications.map((n) => (
              <div 
                key={n.id}
                style={{
                  background: n.is_read ? 'rgba(255, 255, 255, 0.02)' : 'rgba(99, 102, 241, 0.08)',
                  border: n.is_read ? '1px solid var(--border-glass)' : '1px solid rgba(99, 102, 241, 0.35)',
                  borderRadius: 14,
                  padding: 14,
                  display: 'flex',
                  gap: 12,
                  transition: 'background 0.2s ease',
                  position: 'relative'
                }}
              >
                <div style={{
                  padding: 8,
                  borderRadius: 10,
                  background: 'rgba(255, 255, 255, 0.04)',
                  height: 'fit-content'
                }}>
                  {getIconForType(n.type)}
                </div>

                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
                    <h5 style={{ fontSize: 14, fontWeight: 700, color: n.is_read ? '#cbd5e1' : '#fff' }}>
                      {n.title}
                    </h5>
                    {!n.is_read && (
                      <span style={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        background: '#6366f1',
                        display: 'inline-block',
                        marginLeft: 6
                      }} />
                    )}
                  </div>

                  <p style={{ fontSize: 12.5, color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: 8 }}>
                    {n.message}
                  </p>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 11, color: 'var(--text-dim)' }}>
                      {new Date(n.created_at).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </span>

                    {!n.is_read && (
                      <button
                        onClick={() => handleMarkAsRead(n.id)}
                        className="btn btn-secondary"
                        style={{ fontSize: 11, padding: '3px 8px', borderRadius: 6 }}
                      >
                        <Check size={12} />
                        <span>Mark read</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
