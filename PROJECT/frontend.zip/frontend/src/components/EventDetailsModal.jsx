import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Tag, 
  CheckCircle, 
  Star, 
  MessageSquare,
  ShieldCheck,
  Ticket
} from 'lucide-react';
import { api } from '../services/api';

export default function EventDetailsModal({ 
  event, 
  onClose, 
  onBook, 
  user, 
  onOpenFeedback,
  userHasBooked 
}) {
  const [eventDetails, setEventDetails] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [numSeats, setNumSeats] = useState(1);

  useEffect(() => {
    if (!event) return;
    loadDetails();
  }, [event]);

  const loadDetails = async () => {
    try {
      setLoading(true);
      const res = await api.getEventById(event.id);
      setEventDetails(res.event);
      setReviews(res.reviews || []);
    } catch (err) {
      console.error('Error fetching event details:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!event) return null;

  const current = eventDetails || event;
  const isSoldOut = current.available_seats <= 0;
  const price = parseFloat(current.price) || 0;
  const totalPrice = price * numSeats;

  const formattedDate = new Date(current.event_date).toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className="modal-content" 
        onClick={(e) => e.stopPropagation()} 
        style={{ maxWidth: 640, borderRadius: 24, overflow: 'hidden' }}
      >
        {/* Banner with Close Button */}
        <div style={{ position: 'relative', height: 220, background: '#1e293b' }}>
          <img
            src={current.banner_url || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200&auto=format&fit=crop&q=80'}
            alt={current.title}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
          <div style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to top, #111827 0%, rgba(17, 24, 39, 0.4) 60%, rgba(0, 0, 0, 0.7) 100%)'
          }} />

          <button
            onClick={onClose}
            style={{
              position: 'absolute',
              top: 16,
              right: 16,
              background: 'rgba(0, 0, 0, 0.6)',
              backdropFilter: 'blur(8px)',
              border: 'none',
              borderRadius: '50%',
              width: 36,
              height: 36,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              cursor: 'pointer'
            }}
          >
            <X size={18} />
          </button>

          <div style={{ position: 'absolute', bottom: 16, left: 20, right: 20 }}>
            <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
              <span className="badge badge-category">
                <Tag size={12} />
                {current.category}
              </span>
              <span style={{
                padding: '4px 10px',
                borderRadius: 9999,
                fontSize: 11,
                fontWeight: 700,
                background: price === 0 ? 'rgba(16, 185, 129, 0.9)' : 'rgba(99, 102, 241, 0.9)',
                color: '#fff'
              }}>
                {price === 0 ? 'FREE ENTRY' : `₹${price.toFixed(2)} / ticket`}
              </span>
            </div>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: '#fff' }}>
              {current.title}
            </h2>
          </div>
        </div>

        {/* Content Body */}
        <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Quick Info Grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: 12,
            background: 'rgba(255, 255, 255, 0.03)',
            border: '1px solid var(--border-glass)',
            borderRadius: 16,
            padding: 14
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ padding: 8, borderRadius: 10, background: 'rgba(99, 102, 241, 0.15)', color: '#818cf8' }}>
                <Calendar size={18} />
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Date</div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{formattedDate}</div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ padding: 8, borderRadius: 10, background: 'rgba(6, 182, 212, 0.15)', color: '#38bdf8' }}>
                <Clock size={18} />
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Timing</div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>
                  {current.start_time?.substring(0, 5)} - {current.end_time?.substring(0, 5)}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ padding: 8, borderRadius: 10, background: 'rgba(16, 185, 129, 0.15)', color: '#34d399' }}>
                <MapPin size={18} />
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Venue</div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{current.venue}</div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ padding: 8, borderRadius: 10, background: 'rgba(245, 158, 11, 0.15)', color: '#fbbf24' }}>
                <Users size={18} />
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Capacity</div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>
                  {current.available_seats} / {current.total_capacity} remaining
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              About This Event
            </h4>
            <p style={{ fontSize: 14, lineHeight: 1.6, color: '#e2e8f0', whiteSpace: 'pre-line' }}>
              {current.description}
            </p>
          </div>

          {/* Schedule Breakdown */}
          {current.schedule && (
            <div>
              <h4 style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Program Agenda & Schedule
              </h4>
              <div style={{
                background: 'rgba(15, 23, 42, 0.6)',
                border: '1px solid var(--border-glass)',
                borderRadius: 14,
                padding: 16
              }}>
                {current.schedule.split('\n').filter(Boolean).map((line, idx) => (
                  <div key={idx} style={{ 
                    display: 'flex', 
                    alignItems: 'flex-start', 
                    gap: 10, 
                    padding: '8px 0',
                    borderBottom: idx < current.schedule.split('\n').length - 1 ? '1px dashed rgba(255, 255, 255, 0.08)' : 'none'
                  }}>
                    <div style={{
                      width: 6,
                      height: 6,
                      borderRadius: '50%',
                      background: 'var(--accent-cyan)',
                      marginTop: 8
                    }} />
                    <span style={{ fontSize: 13.5, color: '#cbd5e1' }}>{line}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Booking Action Box */}
          <div style={{
            background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(6, 182, 212, 0.08))',
            border: '1px solid rgba(99, 102, 241, 0.3)',
            borderRadius: 18,
            padding: 18
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Instant Attendee Self-Service Booking</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                  Generates tamper-proof digital ticket with verified QR code
                </div>
              </div>

              {/* Number of Seats Selector */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Seats:</span>
                <select
                  value={numSeats}
                  onChange={(e) => setNumSeats(parseInt(e.target.value, 10))}
                  disabled={isSoldOut}
                  className="input-field"
                  style={{ width: 64, padding: '6px 8px', textAlign: 'center' }}
                >
                  {[1, 2, 3, 4, 5].filter(n => n <= current.available_seats).map(n => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid rgba(255, 255, 255, 0.1)', paddingTop: 14 }}>
              <div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Total Amount:</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: '#38bdf8' }}>
                  {totalPrice === 0 ? 'FREE' : `₹${totalPrice.toFixed(2)}`}
                </div>
              </div>

              <button
                onClick={() => {
                  onBook(current, numSeats);
                  onClose();
                }}
                disabled={isSoldOut}
                className={`btn ${isSoldOut ? 'btn-secondary' : 'btn-primary'}`}
                style={{ padding: '12px 24px', fontSize: 14 }}
              >
                <Ticket size={18} />
                <span>{isSoldOut ? 'Sold Out' : 'Confirm & Generate QR Ticket'}</span>
              </button>
            </div>
          </div>

          {/* Attendee Ratings & Reviews */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Star size={18} fill="#fbbf24" color="#fbbf24" />
                <h4 style={{ fontSize: 15, fontWeight: 700 }}>
                  Attendee Feedback ({reviews.length})
                </h4>
              </div>

              {userHasBooked && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenFeedback(current);
                  }}
                  className="btn btn-secondary"
                  style={{ fontSize: 12, padding: '6px 12px' }}
                >
                  <MessageSquare size={14} />
                  <span>Write Review</span>
                </button>
              )}
            </div>

            {reviews.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '20px 0', color: 'var(--text-dim)', fontSize: 13 }}>
                No feedback submitted yet. Be the first to attend and rate this event!
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {reviews.map((rev) => (
                  <div key={rev.id} style={{
                    background: 'rgba(255, 255, 255, 0.03)',
                    border: '1px solid var(--border-glass)',
                    borderRadius: 12,
                    padding: 12
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                      <span style={{ fontSize: 13, fontWeight: 700 }}>{rev.reviewer_name}</span>
                      <div style={{ display: 'flex', gap: 2 }}>
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            size={12} 
                            fill={i < rev.rating ? "#fbbf24" : "none"} 
                            color={i < rev.rating ? "#fbbf24" : "var(--text-dim)"} 
                          />
                        ))}
                      </div>
                    </div>
                    {rev.comments && (
                      <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>{rev.comments}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
