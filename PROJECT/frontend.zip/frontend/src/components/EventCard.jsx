import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, MapPin, Users, Star, ArrowRight, Tag } from 'lucide-react';

export default function EventCard({ event, onBook }) {
  const isSoldOut = event.available_seats <= 0 || event.availableSeats <= 0;
  const available = event.available_seats !== undefined ? event.available_seats : event.availableSeats;
  const total = event.total_capacity || event.totalCapacity || 100;
  const fillPct = Math.round(((total - available) / total) * 100);

  const eventDateObj = new Date(event.event_date || event.eventDate);
  const formattedDate = !isNaN(eventDateObj) ? eventDateObj.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric'
  }) : 'Upcoming';

  const startTime = event.start_time || event.startTime || '';
  const priceVal = parseFloat(event.price || 0);

  return (
    <div className="luxe-card" style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%'
    }}>
      {/* Banner Image & Top Badges */}
      <div style={{ position: 'relative', height: 180, overflow: 'hidden', background: '#0b1120' }}>
        <img
          src={event.banner_url || event.bannerUrl || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=80'}
          alt={event.title}
          style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.4s ease' }}
          onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
          onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
          loading="lazy"
        />
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(to top, rgba(11, 17, 32, 0.95) 0%, rgba(11, 17, 32, 0.2) 60%, transparent 100%)'
        }} />

        {/* Category Pill */}
        <div style={{ position: 'absolute', top: 12, left: 12 }}>
          <span className="badge badge-indigo">
            <Tag size={12} />
            <span>{event.category || event.categoryName || 'General'}</span>
          </span>
        </div>

        {/* Price Pill */}
        <div style={{ position: 'absolute', top: 12, right: 12 }}>
          <span style={{
            padding: '4px 10px',
            borderRadius: 'var(--radius-pill)',
            fontSize: 11,
            fontWeight: 800,
            background: priceVal === 0 ? 'rgba(16, 185, 129, 0.95)' : 'rgba(99, 102, 241, 0.95)',
            color: '#fff',
            backdropFilter: 'blur(8px)',
            boxShadow: '0 2px 8px rgba(0,0,0,0.4)'
          }}>
            {priceVal === 0 ? 'Free' : `₹${priceVal}`}
          </span>
        </div>

        {/* Rating Badge */}
        {parseFloat(event.avg_rating) > 0 && (
          <div style={{
            position: 'absolute',
            bottom: 10,
            right: 12,
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            background: 'rgba(0, 0, 0, 0.75)',
            padding: '2px 8px',
            borderRadius: 6,
            fontSize: 11,
            color: '#fbbf24',
            fontWeight: 700
          }}>
            <Star size={12} fill="#fbbf24" />
            <span>{event.avg_rating}</span>
            <span style={{ color: '#94a3b8', fontSize: 10 }}>({event.total_reviews})</span>
          </div>
        )}
      </div>

      {/* Card Content Body */}
      <div style={{ padding: 20, display: 'flex', flexDirection: 'column', flex: 1, gap: 14 }}>
        <h3 style={{ fontSize: 17, fontWeight: 700, lineHeight: 1.35, color: '#fff', minHeight: 46 }}>
          {event.title}
        </h3>

        {/* Metadata Details */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 13, color: 'var(--text-muted)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Calendar size={14} color="#6366f1" />
            <span>{formattedDate} {startTime ? `• ${startTime}` : ''}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <MapPin size={14} color="#06b6d4" />
            <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {event.venue}
            </span>
          </div>
        </div>

        {/* Seat Availability Meter */}
        <div style={{ marginTop: 'auto', paddingTop: 8 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 6 }}>
            <span style={{ color: 'var(--text-dim)', display: 'flex', alignItems: 'center', gap: 4 }}>
              <Users size={12} />
              <span>Available Seats</span>
            </span>
            <span style={{ fontWeight: 700, color: isSoldOut ? '#f43f5e' : available <= 10 ? '#f59e0b' : '#34d399' }}>
              {isSoldOut ? 'Sold Out' : `${available} of ${total}`}
            </span>
          </div>

          <div style={{ height: 6, borderRadius: 999, background: 'rgba(255, 255, 255, 0.08)', overflow: 'hidden' }}>
            <div style={{
              width: `${Math.min(100, fillPct)}%`,
              height: '100%',
              background: isSoldOut ? '#f43f5e' : available <= 10 ? '#f59e0b' : 'linear-gradient(90deg, #6366f1, #06b6d4)',
              borderRadius: 999,
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>

        {/* Action Buttons: View Details & Book Now */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 4 }}>
          <Link
            to={`/events/${event.id || event._id}`}
            className="btn btn-secondary"
            style={{ fontSize: 13, padding: '8px 12px' }}
          >
            <span>View Details</span>
          </Link>

          <Link
            to={isSoldOut ? '#' : `/book/${event.id || event._id}`}
            className={`btn ${isSoldOut ? 'btn-secondary' : 'btn-emerald'}`}
            style={{ 
              fontSize: 13, 
              padding: '8px 12px',
              textAlign: 'center',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: isSoldOut ? 'not-allowed' : 'pointer',
              opacity: isSoldOut ? 0.6 : 1
            }}
            onClick={(e) => {
              if (isSoldOut) e.preventDefault();
            }}
          >
            {isSoldOut ? 'Sold Out' : 'Book Now'}
          </Link>
        </div>
      </div>
    </div>
  );
}
