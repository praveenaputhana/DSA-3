import React, { useState, useEffect } from 'react';
import { Link, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { 
  Compass, 
  Calendar, 
  Ticket, 
  Bell, 
  User, 
  ShieldCheck, 
  LogOut, 
  LogIn, 
  Menu, 
  X,
  Sparkles,
  QrCode
} from 'lucide-react';
import { getUser, removeToken, removeUser, api } from '../services/api';

export default function Navbar() {
  const [currentUser, setCurrentUser] = useState(getUser());
  const [unreadCount, setUnreadCount] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Listen to storage or route change to keep auth in sync
  useEffect(() => {
    setCurrentUser(getUser());
    setMobileMenuOpen(false); // Close mobile drawer on navigation

    if (getUser()) {
      api.getUnreadCount()
        .then(res => setUnreadCount(res.unread_count || 0))
        .catch(() => {});
    }
  }, [location.pathname]);

  const handleLogout = () => {
    removeToken();
    removeUser();
    setCurrentUser(null);
    navigate('/');
  };

  return (
    <header className="glass-header">
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 72 }}>
        
        {/* Brand Logo */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
          <div style={{
            width: 40,
            height: 40,
            borderRadius: 12,
            background: 'linear-gradient(135deg, #6366f1 0%, #06b6d4 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 4px 14px rgba(99, 102, 241, 0.4)'
          }}>
            <Sparkles size={22} color="#ffffff" />
          </div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-0.02em', color: '#fff', lineHeight: 1.2 }}>
              Event<span style={{ color: '#38bdf8' }}>Hub</span>
            </div>
            <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-dim)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              Attendee Self-Service
            </div>
          </div>
        </Link>

        {/* Desktop Navigation Links */}
        <nav style={{ display: 'none', md: 'flex', gap: 6, alignItems: 'center' }} className="desktop-nav">
          <NavLink
            to="/"
            end
            style={({ isActive }) => ({
              padding: '8px 16px',
              borderRadius: 'var(--radius-pill)',
              fontSize: 14,
              fontWeight: 600,
              color: isActive ? '#fff' : 'var(--text-muted)',
              background: isActive ? 'rgba(99, 102, 241, 0.15)' : 'transparent',
              border: isActive ? '1px solid rgba(99, 102, 241, 0.3)' : '1px solid transparent',
              transition: 'all 0.15s ease'
            })}
          >
            Home
          </NavLink>

          <NavLink
            to="/events"
            style={({ isActive }) => ({
              padding: '8px 16px',
              borderRadius: 'var(--radius-pill)',
              fontSize: 14,
              fontWeight: 600,
              color: isActive ? '#fff' : 'var(--text-muted)',
              background: isActive ? 'rgba(99, 102, 241, 0.15)' : 'transparent',
              border: isActive ? '1px solid rgba(99, 102, 241, 0.3)' : '1px solid transparent',
              transition: 'all 0.15s ease'
            })}
          >
            Explore Events
          </NavLink>

          {currentUser && (
            <>
              <NavLink
                to="/my-bookings"
                style={({ isActive }) => ({
                  padding: '8px 16px',
                  borderRadius: 'var(--radius-pill)',
                  fontSize: 14,
                  fontWeight: 600,
                  color: isActive ? '#fff' : 'var(--text-muted)',
                  background: isActive ? 'rgba(99, 102, 241, 0.15)' : 'transparent',
                  border: isActive ? '1px solid rgba(99, 102, 241, 0.3)' : '1px solid transparent'
                })}
              >
                My Bookings
              </NavLink>

              <NavLink
                to="/my-tickets"
                style={({ isActive }) => ({
                  padding: '8px 16px',
                  borderRadius: 'var(--radius-pill)',
                  fontSize: 14,
                  fontWeight: 600,
                  color: isActive ? '#fff' : 'var(--text-muted)',
                  background: isActive ? 'rgba(16, 185, 129, 0.15)' : 'transparent',
                  border: isActive ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid transparent',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6
                })}
              >
                <Ticket size={16} color={location.pathname === '/my-tickets' ? '#34d399' : '#94a3b8'} />
                <span>My Tickets</span>
              </NavLink>
            </>
          )}

          {currentUser && currentUser.role === 'admin' && (
            <NavLink
              to="/admin"
              style={({ isActive }) => ({
                padding: '8px 16px',
                borderRadius: 'var(--radius-pill)',
                fontSize: 14,
                fontWeight: 600,
                color: isActive ? '#38bdf8' : '#cbd5e1',
                background: 'rgba(6, 182, 212, 0.12)',
                border: '1px solid rgba(6, 182, 212, 0.3)',
                display: 'flex',
                alignItems: 'center',
                gap: 6
              })}
            >
              <ShieldCheck size={16} color="#38bdf8" />
              <span>Admin Portal</span>
            </NavLink>
          )}
        </nav>

        {/* Right Action Icons / Profile */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          
          {/* Notifications Link */}
          {currentUser && (
            <Link
              to="/notifications"
              style={{
                position: 'relative',
                padding: 10,
                borderRadius: '50%',
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid var(--border-subtle)',
                color: '#fff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
              title="Notifications"
            >
              <Bell size={18} />
              {unreadCount > 0 && (
                <span style={{
                  position: 'absolute',
                  top: -2,
                  right: -2,
                  background: '#f43f5e',
                  color: '#fff',
                  borderRadius: '50%',
                  fontSize: 10,
                  fontWeight: 800,
                  width: 18,
                  height: 18,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 0 8px rgba(244, 63, 94, 0.8)'
                }}>
                  {unreadCount}
                </span>
              )}
            </Link>
          )}

          {/* User Auth Pills */}
          {currentUser ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Link
                to="/profile"
                className="btn btn-secondary"
                style={{ padding: '8px 14px', fontSize: 13 }}
              >
                <User size={15} color="#818cf8" />
                <span>{currentUser.name ? currentUser.name.split(' ')[0] : 'Profile'}</span>
              </Link>

              <button
                onClick={handleLogout}
                className="btn btn-secondary"
                style={{ padding: '8px 12px' }}
                title="Log Out"
              >
                <LogOut size={15} color="#f43f5e" />
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Link to="/login" className="btn btn-secondary" style={{ padding: '8px 16px', fontSize: 13 }}>
                <LogIn size={15} />
                <span>Sign In</span>
              </Link>
              <Link to="/register" className="btn btn-primary" style={{ padding: '8px 16px', fontSize: 13 }}>
                <span>Register</span>
              </Link>
            </div>
          )}

          {/* Mobile Hamburger Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="mobile-hamburger"
            style={{
              padding: 8,
              borderRadius: 8,
              background: 'rgba(255, 255, 255, 0.05)',
              border: '1px solid var(--border-subtle)',
              color: '#fff',
              display: 'flex',
              cursor: 'pointer'
            }}
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div style={{
          background: '#090e1c',
          borderBottom: '1px solid var(--border-subtle)',
          padding: '16px 20px',
          display: 'flex',
          flexDirection: 'column',
          gap: 10
        }}>
          <Link to="/" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
            <Compass size={18} color="#818cf8" />
            <span>Home</span>
          </Link>
          <Link to="/events" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
            <Calendar size={18} color="#06b6d4" />
            <span>Explore All Events</span>
          </Link>

          {currentUser && (
            <>
              <Link to="/my-bookings" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
                <Calendar size={18} color="#a855f7" />
                <span>My Bookings</span>
              </Link>
              <Link to="/my-tickets" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
                <Ticket size={18} color="#10b981" />
                <span>My QR Tickets</span>
              </Link>
              <Link to="/notifications" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
                <Bell size={18} color="#f59e0b" />
                <span>Notifications ({unreadCount})</span>
              </Link>
              <Link to="/profile" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
                <User size={18} color="#38bdf8" />
                <span>My Profile</span>
              </Link>
            </>
          )}

          {currentUser && currentUser.role === 'admin' && (
            <div style={{ marginTop: 6, paddingTop: 10, borderTop: '1px solid rgba(255, 255, 255, 0.1)', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#38bdf8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Admin Controls
              </div>
              <Link to="/admin" className="btn btn-cyan" style={{ justifyContent: 'flex-start' }}>
                <ShieldCheck size={18} />
                <span>Admin Dashboard</span>
              </Link>
              <Link to="/admin/events" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
                <Calendar size={18} />
                <span>Manage Events</span>
              </Link>
              <Link to="/admin/checkin" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
                <QrCode size={18} />
                <span>QR Check-In Station</span>
              </Link>
              <Link to="/admin/feedback" className="btn btn-secondary" style={{ justifyContent: 'flex-start' }}>
                <Sparkles size={18} />
                <span>Feedback & Broadcasts</span>
              </Link>
            </div>
          )}
        </div>
      )}

      {/* Inline style helper for responsive navbar */}
      <style>{`
        @media (min-width: 900px) {
          .desktop-nav { display: flex !important; }
          .mobile-hamburger { display: none !important; }
        }
        @media (max-width: 899px) {
          .desktop-nav { display: none !important; }
          .mobile-hamburger { display: flex !important; }
        }
      `}</style>
    </header>
  );
}
