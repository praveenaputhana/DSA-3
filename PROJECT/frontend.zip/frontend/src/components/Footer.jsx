import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Calendar, Ticket, ShieldCheck, Heart, Database } from 'lucide-react';

export default function Footer() {
  return (
    <footer style={{
      background: '#04070f',
      borderTop: '1px solid var(--border-subtle)',
      padding: '50px 0 25px 0',
      marginTop: 'auto',
      position: 'relative',
      zIndex: 10
    }}>
      <div className="container">
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: 36,
          marginBottom: 40
        }}>
          
          {/* Brand Col */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{
                width: 34,
                height: 34,
                borderRadius: 10,
                background: 'linear-gradient(135deg, #6366f1 0%, #06b6d4 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Sparkles size={18} color="#fff" />
              </div>
              <span style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>
                Event<span style={{ color: '#38bdf8' }}>Hub</span>
              </span>
            </div>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.6, marginBottom: 16 }}>
              Event Management Mobile Application for Attendee Self-Service.
              Empowering students to independently browse campus events, reserve seats, and generate digital boarding-pass QR tickets.
            </p>
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              background: 'rgba(99, 102, 241, 0.1)',
              border: '1px solid rgba(99, 102, 241, 0.25)',
              padding: '4px 10px',
              borderRadius: 'var(--radius-pill)',
              fontSize: 11,
              color: '#a5b4fc',
              fontWeight: 600
            }}>
              <Database size={12} />
              <span>MongoDB • Express • React • Node.js</span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#fff', marginBottom: 14 }}>
              Attendee Self-Service
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13, color: 'var(--text-muted)' }}>
              <Link to="/events" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                Explore Hackathons & Events
              </Link>
              <Link to="/my-bookings" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                My Reservation History
              </Link>
              <Link to="/my-tickets" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                My Digital QR Tickets
              </Link>
              <Link to="/notifications" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                Campus Announcements
              </Link>
            </div>
          </div>

          {/* Admin & Security */}
          <div>
            <h4 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#fff', marginBottom: 14 }}>
              Organizer & Admin
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13, color: 'var(--text-muted)' }}>
              <Link to="/admin" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                Admin Dashboard & Analytics
              </Link>
              <Link to="/admin/events" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                Create & Publish Events
              </Link>
              <Link to="/admin/checkin" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                Venue QR Scanner & Verification
              </Link>
              <Link to="/admin/feedback" style={{ transition: 'color 0.15s ease' }} onMouseEnter={e => e.currentTarget.style.color = '#38bdf8'} onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
                Attendee Reviews & Alerts
              </Link>
            </div>
          </div>

          {/* Project Academic Info */}
          <div>
            <h4 style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#fff', marginBottom: 14 }}>
              DBMS Project Team
            </h4>
            <p style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 8, lineHeight: 1.4 }}>
              Course: Distributed Backend & Database Systems (25CS1302E)
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12, color: '#cbd5e1' }}>
              <div>• <strong>P. Srija</strong> (2520090053)</div>
              <div>• <strong>P. Praveena</strong> (2520090057)</div>
              <div>• <strong>D. Varun Teja Reddy</strong> (2520090221)</div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div style={{
          borderTop: '1px solid var(--border-subtle)',
          paddingTop: 20,
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 12,
          fontSize: 12,
          color: 'var(--text-dim)'
        }}>
          <div>
            © 2026-2027 EventHub DBMS Project. All rights reserved.
          </div>
          <div style={{ display: 'flex', gap: 16 }}>
            <span>MongoDB Version 8.0</span>
            <span>•</span>
            <span>REST API Active</span>
            <span>•</span>
            <span>Secured with Bcrypt & JWT</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
