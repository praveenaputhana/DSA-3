import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Eye, 
  EyeOff, 
  QrCode, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Users, 
  Calendar, 
  Send, 
  Star, 
  BarChart3, 
  Search,
  Check,
  RefreshCw,
  Bell,
  Clock,
  Sparkles,
  Camera,
  FolderPlus,
  Folder,
  X
} from 'lucide-react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { api } from '../services/api';
import confetti from 'canvas-confetti';

export default function AdminDashboard({ onEventUpdated }) {
  const [activeAdminTab, setActiveAdminTab] = useState('checkin'); // 'checkin' | 'events' | 'categories' | 'bookings' | 'notifications' | 'feedback'
  
  // Data states
  const [events, setEvents] = useState([]);
  const [categoriesList, setCategoriesList] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats] = useState(null);
  const [feedbackList, setFeedbackList] = useState([]);
  const [loading, setLoading] = useState(false);

  // Category form states
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [catSuccess, setCatSuccess] = useState('');

  // QR Check-in states
  const [scanCodeInput, setScanCodeInput] = useState('');
  const [checkinResult, setCheckinResult] = useState(null);
  const [checkinLoading, setCheckinLoading] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  // Live Camera Scanner Lifecycle
  useEffect(() => {
    let scanner = null;
    if (isCameraOpen) {
      const timer = setTimeout(() => {
        try {
          scanner = new Html5QrcodeScanner(
            'qr-reader',
            { fps: 10, qrbox: { width: 220, height: 220 } },
            false
          );
          scanner.render(
            (decodedText) => {
              handlePerformCheckin(decodedText);
              setIsCameraOpen(false);
              scanner.clear().catch(() => {});
            },
            () => {}
          );
        } catch (e) {
          console.error('Camera init error:', e);
        }
      }, 100);

      return () => {
        clearTimeout(timer);
        if (scanner) {
          scanner.clear().catch(() => {});
        }
      };
    }
  }, [isCameraOpen]);

  // Event modal states (Create / Edit)
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [eventForm, setEventForm] = useState({
    title: '',
    category: 'Technology',
    description: '',
    banner_url: '',
    event_date: '',
    start_time: '09:00:00',
    end_time: '17:00:00',
    venue: '',
    schedule: '',
    total_capacity: 100,
    price: 0.00,
    is_published: true
  });

  // Notification form states
  const [notifTargetEvent, setNotifTargetEvent] = useState('');
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifType, setNotifType] = useState('GENERAL');
  const [notifSuccess, setNotifSuccess] = useState('');

  // Initial load
  useEffect(() => {
    loadAllAdminData();
  }, []);

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [eventsRes, bookingsRes, statsRes, feedbackRes, catsRes] = await Promise.all([
        api.getEvents({ includeUnpublished: 'true' }),
        api.getAllBookings(),
        api.getCheckinStats(),
        api.getAllFeedback(),
        api.getCategories()
      ]);

      setEvents(eventsRes.events || []);
      setBookings(bookingsRes.bookings || []);
      setStats(statsRes.stats || []);
      setFeedbackList(feedbackRes.reviews || []);
      setCategoriesList(catsRes.categories || []);
    } catch (err) {
      console.error('Failed to load admin dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCategory = async (e) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      await api.createCategory({ name: newCatName.trim(), description: newCatDesc.trim() });
      setCatSuccess(`Category "${newCatName.trim()}" created successfully!`);
      setNewCatName('');
      setNewCatDesc('');
      loadAllAdminData();
      if (onEventUpdated) onEventUpdated();
      setTimeout(() => setCatSuccess(''), 3500);
    } catch (err) {
      alert(err.message || 'Failed to create category.');
    }
  };

  // =========================================================================
  // QR Check-in Action Handler:
  // Calls POST /api/checkin/scan which strictly enforces duplicate check-in
  // prevention and validates cancellations.
  // =========================================================================
  const handlePerformCheckin = async (codeToScan) => {
    const targetCode = (codeToScan || scanCodeInput).trim();
    if (!targetCode) return;

    setCheckinLoading(true);
    setCheckinResult(null);

    try {
      const res = await api.scanTicket({ qr_code_or_ticket_code: targetCode });
      setCheckinResult({
        type: 'success',
        message: res.message,
        attendee: res.attendee
      });
      setScanCodeInput('');

      // Trigger celebratory confetti for successful check-in
      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {}

      // Refresh list to update badge status
      loadAllAdminData();
    } catch (err) {
      setCheckinResult({
        type: 'error',
        message: err.message
      });
    } finally {
      setCheckinLoading(false);
    }
  };

  // Event CRUD Actions
  const handleOpenCreateEvent = () => {
    setEditingEvent(null);
    setEventForm({
      title: '',
      category: 'Technology',
      description: '',
      banner_url: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200&auto=format&fit=crop&q=80',
      event_date: new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0],
      start_time: '10:00:00',
      end_time: '16:00:00',
      venue: 'Main Campus Auditorium',
      schedule: '10:00 AM - Keynote Address\n11:30 AM - Technical Session\n02:00 PM - Workshop Lab\n04:00 PM - Closing Ceremony',
      total_capacity: 100,
      price: 0.00,
      is_published: true
    });
    setIsEventModalOpen(true);
  };

  const handleOpenEditEvent = (ev) => {
    setEditingEvent(ev);
    setEventForm({
      title: ev.title,
      category: ev.category,
      description: ev.description,
      banner_url: ev.banner_url || '',
      event_date: ev.event_date ? new Date(ev.event_date).toISOString().split('T')[0] : '',
      start_time: ev.start_time || '09:00:00',
      end_time: ev.end_time || '17:00:00',
      venue: ev.venue,
      schedule: ev.schedule || '',
      total_capacity: ev.total_capacity,
      price: ev.price,
      is_published: !!ev.is_published
    });
    setIsEventModalOpen(true);
  };

  const handleSaveEvent = async (e) => {
    e.preventDefault();
    try {
      if (editingEvent) {
        const idToUpdate = editingEvent.id || editingEvent._id;
        await api.updateEvent(idToUpdate, eventForm);
      } else {
        await api.createEvent(eventForm);
      }
      setIsEventModalOpen(false);
      loadAllAdminData();
      if (onEventUpdated) onEventUpdated();
    } catch (err) {
      alert(err.message || 'Failed to save event.');
    }
  };

  const handleTogglePublish = async (eventId) => {
    try {
      await api.togglePublishEvent(eventId);
      loadAllAdminData();
      if (onEventUpdated) onEventUpdated();
    } catch (err) {
      alert(err.message || 'Failed to toggle status.');
    }
  };

  const handleDeleteEvent = async (eventId, title) => {
    if (!window.confirm(`Are you sure you want to permanently delete event "${title}"? This will delete all associated bookings and tickets.`)) {
      return;
    }
    try {
      await api.deleteEvent(eventId);
      loadAllAdminData();
      if (onEventUpdated) onEventUpdated();
    } catch (err) {
      alert(err.message || 'Failed to delete event.');
    }
  };

  // Broadcast Notification
  const handleSendNotification = async (e) => {
    e.preventDefault();
    try {
      await api.sendNotification({
        event_id: notifTargetEvent ? parseInt(notifTargetEvent, 10) : null,
        title: notifTitle,
        message: notifMessage,
        type: notifType
      });
      setNotifSuccess('Notification sent successfully to attendees!');
      setNotifTitle('');
      setNotifMessage('');
      setTimeout(() => setNotifSuccess(''), 4000);
    } catch (err) {
      alert(err.message || 'Failed to send notification.');
    }
  };

  // Aggregate Metrics
  const totalEvents = events.length;
  const totalBookingsCount = bookings.length;
  const totalConfirmedAttendees = bookings.filter(b => b.booking_status === 'CONFIRMED').length;
  const checkedInCount = bookings.filter(b => b.ticket_status === 'CHECKED_IN').length;
  const checkinRate = totalConfirmedAttendees > 0 
    ? Math.round((checkedInCount / totalConfirmedAttendees) * 100) 
    : 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      {/* Admin Title Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 24, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span>🛡️ Admin Command Center</span>
            <span className="badge badge-active" style={{ fontSize: 11 }}>Database Live</span>
          </h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
            Manage events, monitor live attendee bookings, verify QR tickets, and dispatch broadcasts
          </p>
        </div>

        <button 
          onClick={loadAllAdminData} 
          disabled={loading}
          className="btn btn-secondary"
          style={{ fontSize: 13 }}
        >
          <RefreshCw size={14} className={loading ? 'pulse-glow' : ''} />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* KPI Summary Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: 14
      }}>
        <div className="glass-panel" style={{ padding: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: 12, marginBottom: 8 }}>
            <span>Total Events</span>
            <Calendar size={16} color="#6366f1" />
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#fff' }}>{totalEvents}</div>
          <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4 }}>
            {events.filter(e => e.is_published).length} Published • {events.filter(e => !e.is_published).length} Drafts
          </div>
        </div>

        <div className="glass-panel" style={{ padding: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: 12, marginBottom: 8 }}>
            <span>Confirmed Bookings</span>
            <Users size={16} color="#06b6d4" />
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#38bdf8' }}>{totalConfirmedAttendees}</div>
          <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4 }}>
            Across all active campus events
          </div>
        </div>

        <div className="glass-panel" style={{ padding: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: 12, marginBottom: 8 }}>
            <span>Checked-In At Venue</span>
            <CheckCircle size={16} color="#10b981" />
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#34d399' }}>{checkedInCount}</div>
          <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4 }}>
            Unique verified attendee entries
          </div>
        </div>

        <div className="glass-panel" style={{ padding: 18 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: 12, marginBottom: 8 }}>
            <span>Turnout Rate</span>
            <BarChart3 size={16} color="#fbbf24" />
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#fbbf24' }}>{checkinRate}%</div>
          <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4 }}>
            Check-ins vs Confirmed RSVPs
          </div>
        </div>
      </div>

      {/* Admin Sub Navigation Tabs */}
      <div style={{
        display: 'flex',
        gap: 8,
        borderBottom: '1px solid var(--border-glass)',
        paddingBottom: 8,
        overflowX: 'auto'
      }}>
        <button
          onClick={() => setActiveAdminTab('checkin')}
          className={`btn ${activeAdminTab === 'checkin' ? 'btn-primary' : 'btn-secondary'}`}
          style={{ fontSize: 13, padding: '8px 16px' }}
        >
          <QrCode size={16} />
          <span>QR Check-In Station</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('events')}
          className={`btn ${activeAdminTab === 'events' ? 'btn-primary' : 'btn-secondary'}`}
          style={{ fontSize: 13, padding: '8px 16px' }}
        >
          <Calendar size={16} />
          <span>Manage Events ({events.length})</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('bookings')}
          className={`btn ${activeAdminTab === 'bookings' ? 'btn-primary' : 'btn-secondary'}`}
          style={{ fontSize: 13, padding: '8px 16px' }}
        >
          <Users size={16} />
          <span>Attendees & Bookings ({bookings.length})</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('notifications')}
          className={`btn ${activeAdminTab === 'notifications' ? 'btn-primary' : 'btn-secondary'}`}
          style={{ fontSize: 13, padding: '8px 16px' }}
        >
          <Bell size={16} />
          <span>Send Broadcast Alerts</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('feedback')}
          className={`btn ${activeAdminTab === 'feedback' ? 'btn-primary' : 'btn-secondary'}`}
          style={{ fontSize: 13, padding: '8px 16px' }}
        >
          <Star size={16} />
          <span>Attendee Reviews ({feedbackList.length})</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('categories')}
          className={`btn ${activeAdminTab === 'categories' ? 'btn-primary' : 'btn-secondary'}`}
          style={{ fontSize: 13, padding: '8px 16px' }}
        >
          <FolderPlus size={16} />
          <span>Categories ({categoriesList.length})</span>
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB 1: QR CHECK-IN STATION                                    */}
      {/* ------------------------------------------------------------- */}
      {activeAdminTab === 'checkin' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20 }}>
          {/* Scanner / Ticket Entry Box */}
          <div className="glass-panel" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ padding: 8, borderRadius: 10, background: 'rgba(99, 102, 241, 0.15)', color: '#818cf8' }}>
                <QrCode size={22} />
              </div>
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700 }}>Ticket QR Scanner & Verification</h3>
                <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                  Scans barcode/QR camera string or manual ticket code. Prevents double check-ins.
                </p>
              </div>
            </div>

            {/* Quick Simulation helper for demo */}
            <div style={{
              background: 'rgba(6, 182, 212, 0.08)',
              border: '1px solid rgba(6, 182, 212, 0.25)',
              borderRadius: 12,
              padding: 12
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 700, color: '#38bdf8', marginBottom: 8 }}>
                <Sparkles size={14} />
                <span>College Review Quick Demo: Choose an Attendee Ticket to Test</span>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {bookings.slice(0, 4).map((b) => (
                  <button
                    key={b.booking_id}
                    type="button"
                    onClick={() => {
                      setScanCodeInput(b.ticket_code);
                      handlePerformCheckin(b.ticket_code);
                    }}
                    className="btn btn-secondary"
                    style={{ fontSize: 11, padding: '5px 10px' }}
                  >
                    <span>{b.attendee_name}: </span>
                    <strong style={{ marginLeft: 4 }}>{b.ticket_code}</strong>
                    <span style={{ 
                      marginLeft: 6, 
                      color: b.ticket_status === 'CHECKED_IN' ? '#38bdf8' : b.ticket_status === 'CANCELLED' ? '#fb7185' : '#34d399'
                    }}>
                      [{b.ticket_status}]
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Input Form & Camera Scanner Trigger */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <form onSubmit={(e) => { e.preventDefault(); handlePerformCheckin(); }} style={{ display: 'flex', gap: 10 }}>
                <input
                  type="text"
                  placeholder="Scan or enter Ticket Code (e.g. TKT-AI-8831)"
                  className="input-field"
                  value={scanCodeInput}
                  onChange={(e) => setScanCodeInput(e.target.value)}
                  style={{ fontSize: 15, fontFamily: 'monospace' }}
                />
                <button
                  type="submit"
                  disabled={checkinLoading || !scanCodeInput.trim()}
                  className="btn btn-primary"
                  style={{ padding: '10px 20px', whiteSpace: 'nowrap' }}
                >
                  {checkinLoading ? 'Verifying...' : 'Check In'}
                </button>

                <button
                  type="button"
                  onClick={() => setIsCameraOpen(!isCameraOpen)}
                  className={`btn ${isCameraOpen ? 'btn-danger' : 'btn-secondary'}`}
                  style={{ padding: '10px 14px', whiteSpace: 'nowrap' }}
                  title={isCameraOpen ? 'Close Camera' : 'Scan using Camera'}
                >
                  {isCameraOpen ? <X size={18} /> : <Camera size={18} />}
                  <span>{isCameraOpen ? 'Close Cam' : 'Webcam Scan'}</span>
                </button>
              </form>

              {/* Live Camera Scanner Box */}
              {isCameraOpen && (
                <div style={{
                  background: 'rgba(0, 0, 0, 0.4)',
                  border: '1px solid var(--border-active)',
                  borderRadius: 14,
                  padding: 16,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center'
                }}>
                  <div style={{ fontSize: 12, color: '#38bdf8', marginBottom: 10, fontWeight: 600 }}>
                    📷 Hold an attendee's digital QR ticket in front of your camera
                  </div>
                  <div id="qr-reader" style={{ width: '100%', maxWidth: 320, background: '#000', borderRadius: 12, overflow: 'hidden' }} />
                </div>
              )}
            </div>

            {/* Verification Result Notification Card */}
            {checkinResult && (
              <div style={{
                borderRadius: 16,
                padding: 18,
                border: checkinResult.type === 'success' 
                  ? '1px solid rgba(16, 185, 129, 0.4)' 
                  : '1px solid rgba(244, 63, 94, 0.4)',
                background: checkinResult.type === 'success' 
                  ? 'rgba(16, 185, 129, 0.12)' 
                  : 'rgba(244, 63, 94, 0.12)',
                animation: 'slideUp 0.25s ease'
              }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                  {checkinResult.type === 'success' ? (
                    <CheckCircle size={26} color="#34d399" style={{ marginTop: 2 }} />
                  ) : (
                    <AlertTriangle size={26} color="#fb7185" style={{ marginTop: 2 }} />
                  )}

                  <div style={{ flex: 1 }}>
                    <div style={{
                      fontWeight: 800,
                      fontSize: 16,
                      color: checkinResult.type === 'success' ? '#34d399' : '#fb7185',
                      marginBottom: 4
                    }}>
                      {checkinResult.type === 'success' ? 'ENTRY AUTHORIZED' : 'CHECK-IN BLOCKED'}
                    </div>

                    <p style={{ fontSize: 13.5, color: '#f1f5f9', marginBottom: checkinResult.attendee ? 12 : 0 }}>
                      {checkinResult.message}
                    </p>

                    {checkinResult.attendee && (
                      <div style={{
                        background: 'rgba(0, 0, 0, 0.25)',
                        padding: 12,
                        borderRadius: 10,
                        display: 'grid',
                        gridTemplateColumns: 'repeat(2, 1fr)',
                        gap: 8,
                        fontSize: 12
                      }}>
                        <div>
                          <span style={{ color: 'var(--text-dim)' }}>Attendee: </span>
                          <strong style={{ color: '#fff' }}>{checkinResult.attendee.name}</strong>
                        </div>
                        <div>
                          <span style={{ color: 'var(--text-dim)' }}>Event: </span>
                          <strong style={{ color: '#fff' }}>{checkinResult.attendee.eventTitle}</strong>
                        </div>
                        <div>
                          <span style={{ color: 'var(--text-dim)' }}>Ticket Code: </span>
                          <strong style={{ fontFamily: 'monospace', color: '#a5b4fc' }}>{checkinResult.attendee.ticketCode}</strong>
                        </div>
                        <div>
                          <span style={{ color: 'var(--text-dim)' }}>Seats: </span>
                          <strong style={{ color: '#38bdf8' }}>{checkinResult.attendee.numSeats} Seat(s)</strong>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Real-time Event Check-in Statistics List */}
          <div className="glass-panel" style={{ padding: 22 }}>
            <h3 style={{ fontSize: 17, fontWeight: 700, marginBottom: 14 }}>
              Live Attendance Breakdown by Event
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {stats && stats.map((st) => (
                <div key={st.event_id} style={{
                  background: 'rgba(255, 255, 255, 0.03)',
                  border: '1px solid var(--border-glass)',
                  borderRadius: 12,
                  padding: 14
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{st.title}</div>
                    <span style={{ fontSize: 12, fontWeight: 700, color: '#38bdf8' }}>
                      {st.checked_in_count} / {st.confirmed_attendees} Checked In
                    </span>
                  </div>

                  {/* Progress Meter */}
                  <div style={{ height: 6, background: 'rgba(255, 255, 255, 0.1)', borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{
                      height: '100%',
                      width: `${st.checkin_percentage || 0}%`,
                      background: 'linear-gradient(90deg, #6366f1, #10b981)'
                    }} />
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-dim)', marginTop: 6 }}>
                    <span>Capacity: {st.total_capacity} seats</span>
                    <span>{st.checkin_percentage || 0}% turnout rate</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 2: MANAGE EVENTS                                          */}
      {/* ------------------------------------------------------------- */}
      {activeAdminTab === 'events' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: 18, fontWeight: 700 }}>Campus Events ({events.length})</h3>
            <button onClick={handleOpenCreateEvent} className="btn btn-primary" style={{ fontSize: 13 }}>
              <Plus size={16} />
              <span>Create New Event</span>
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
            {events.map((ev) => (
              <div key={ev.id} className="glass-panel" style={{ padding: 18, display: 'flex', flexDirection: 'column', gap: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <span className="badge badge-category" style={{ marginBottom: 6 }}>{ev.category}</span>
                    <h4 style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>{ev.title}</h4>
                  </div>
                  <span className={`badge ${ev.is_published ? 'badge-active' : 'badge-cancelled'}`}>
                    {ev.is_published ? 'Published' : 'Draft / Hidden'}
                  </span>
                </div>

                <div style={{ fontSize: 12, color: 'var(--text-muted)', display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <div>📅 {new Date(ev.event_date).toLocaleDateString()} ({ev.start_time?.substring(0, 5)} - {ev.end_time?.substring(0, 5)})</div>
                  <div>📍 {ev.venue}</div>
                  <div>👥 {ev.available_seats} / {ev.total_capacity} seats left (Fee: ₹{parseFloat(ev.price).toFixed(2)})</div>
                </div>

                <div style={{ display: 'flex', gap: 8, marginTop: 'auto', paddingTop: 8, borderTop: '1px solid var(--border-glass)' }}>
                  <button
                    onClick={() => handleTogglePublish(ev.id)}
                    className="btn btn-secondary"
                    style={{ flex: 1, fontSize: 12, padding: '6px 10px' }}
                    title={ev.is_published ? 'Hide event from attendees' : 'Publish event live'}
                  >
                    {ev.is_published ? <EyeOff size={14} /> : <Eye size={14} />}
                    <span>{ev.is_published ? 'Unpublish' : 'Publish'}</span>
                  </button>

                  <button
                    onClick={() => handleOpenEditEvent(ev)}
                    className="btn btn-secondary"
                    style={{ fontSize: 12, padding: '6px 10px' }}
                    title="Edit Event"
                  >
                    <Edit3 size={14} />
                    <span>Edit</span>
                  </button>

                  <button
                    onClick={() => handleDeleteEvent(ev.id, ev.title)}
                    className="btn btn-danger"
                    style={{ fontSize: 12, padding: '6px 10px' }}
                    title="Delete Event"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 3: ATTENDEES & BOOKINGS                                   */}
      {/* ------------------------------------------------------------- */}
      {activeAdminTab === 'bookings' && (
        <div className="glass-panel" style={{ padding: 20 }}>
          <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 14 }}>
            All Attendee Registrations & Ticket Status ({bookings.length})
          </h3>

          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-glass)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '10px 12px' }}>Attendee</th>
                  <th style={{ padding: '10px 12px' }}>Event</th>
                  <th style={{ padding: '10px 12px' }}>Ticket Code</th>
                  <th style={{ padding: '10px 12px' }}>Seats</th>
                  <th style={{ padding: '10px 12px' }}>Status</th>
                  <th style={{ padding: '10px 12px' }}>Quick Check-In</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b.booking_id} style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.05)' }}>
                    <td style={{ padding: '12px' }}>
                      <div style={{ fontWeight: 700, color: '#fff' }}>{b.attendee_name}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>{b.attendee_email}</div>
                    </td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ fontWeight: 600 }}>{b.event_title}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>Ref: {b.booking_reference}</div>
                    </td>
                    <td style={{ padding: '12px', fontFamily: 'monospace', color: '#a5b4fc', fontWeight: 600 }}>
                      {b.ticket_code}
                    </td>
                    <td style={{ padding: '12px' }}>
                      <span className="glass-pill" style={{ padding: '3px 8px', fontSize: 11 }}>
                        {b.num_seats} Seat(s)
                      </span>
                    </td>
                    <td style={{ padding: '12px' }}>
                      {b.ticket_status === 'CHECKED_IN' && (
                        <span className="badge badge-checkedin">CHECKED IN</span>
                      )}
                      {b.ticket_status === 'ACTIVE' && (
                        <span className="badge badge-active">ACTIVE</span>
                      )}
                      {b.ticket_status === 'CANCELLED' && (
                        <span className="badge badge-cancelled">CANCELLED</span>
                      )}
                    </td>
                    <td style={{ padding: '12px' }}>
                      {b.ticket_status === 'ACTIVE' ? (
                        <button
                          onClick={() => {
                            setActiveAdminTab('checkin');
                            handlePerformCheckin(b.ticket_code);
                          }}
                          className="btn btn-primary"
                          style={{ fontSize: 11, padding: '4px 10px' }}
                        >
                          Check In Now
                        </button>
                      ) : (
                        <span style={{ fontSize: 11, color: 'var(--text-dim)' }}>
                          {b.ticket_status === 'CHECKED_IN' ? 'Verified' : 'Void'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 4: SEND NOTIFICATIONS                                     */}
      {/* ------------------------------------------------------------- */}
      {activeAdminTab === 'notifications' && (
        <div className="glass-panel" style={{ maxWidth: 600, margin: '0 auto', width: '100%', padding: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <div style={{ padding: 8, borderRadius: 10, background: 'rgba(99, 102, 241, 0.15)', color: '#818cf8' }}>
              <Send size={20} />
            </div>
            <div>
              <h3 style={{ fontSize: 18, fontWeight: 700 }}>Dispatch Attendee Notification</h3>
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                Broadcast venue instructions, timing updates, or alerts to attendees
              </p>
            </div>
          </div>

          {notifSuccess && (
            <div style={{
              background: 'rgba(16, 185, 129, 0.15)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              borderRadius: 10,
              padding: '10px 14px',
              color: '#34d399',
              fontSize: 13,
              marginBottom: 16
            }}>
              {notifSuccess}
            </div>
          )}

          <form onSubmit={handleSendNotification} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label className="input-label">Target Audience</label>
              <select
                className="input-field"
                value={notifTargetEvent}
                onChange={(e) => setNotifTargetEvent(e.target.value)}
              >
                <option value="">📢 All Registered Users & Attendees (Global Broadcast)</option>
                {events.map((ev) => (
                  <option key={ev.id} value={ev.id}>
                    🎯 Attendees of: {ev.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="input-label">Notification Type</label>
              <select
                className="input-field"
                value={notifType}
                onChange={(e) => setNotifType(e.target.value)}
              >
                <option value="GENERAL">General Announcement</option>
                <option value="UPDATE">Schedule / Venue Update</option>
                <option value="REMINDER">Event Reminder</option>
                <option value="CANCELLATION">Cancellation Alert</option>
              </select>
            </div>

            <div>
              <label className="input-label">Notification Title</label>
              <input
                type="text"
                required
                placeholder="e.g. Auditorium Hall Venue Gate Timing Update"
                className="input-field"
                value={notifTitle}
                onChange={(e) => setNotifTitle(e.target.value)}
              />
            </div>

            <div>
              <label className="input-label">Message Details</label>
              <textarea
                rows={4}
                required
                placeholder="Type your message for attendees here..."
                className="input-field"
                value={notifMessage}
                onChange={(e) => setNotifMessage(e.target.value)}
                style={{ resize: 'vertical' }}
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ padding: '12px' }}>
              <Send size={16} />
              <span>Broadcast Notification Now</span>
            </button>
          </form>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 5: ATTENDEE FEEDBACK                                      */}
      {/* ------------------------------------------------------------- */}
      {activeAdminTab === 'feedback' && (
        <div className="glass-panel" style={{ padding: 20 }}>
          <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 14 }}>
            Attendee Feedback & Ratings Archive ({feedbackList.length})
          </h3>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 14 }}>
            {feedbackList.map((fb) => (
              <div key={fb.id} style={{
                background: 'rgba(255, 255, 255, 0.03)',
                border: '1px solid var(--border-glass)',
                borderRadius: 14,
                padding: 16,
                display: 'flex',
                flexDirection: 'column',
                gap: 8
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontWeight: 700, fontSize: 14, color: '#fff' }}>{fb.reviewer_name}</span>
                  <div style={{ display: 'flex', gap: 2 }}>
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={13}
                        fill={i < fb.rating ? "#fbbf24" : "none"}
                        color={i < fb.rating ? "#fbbf24" : "var(--text-dim)"}
                      />
                    ))}
                  </div>
                </div>

                <div style={{ fontSize: 12, color: '#38bdf8', fontWeight: 600 }}>
                  Event: {fb.event_title}
                </div>

                {fb.comments && (
                  <p style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.5 }}>
                    "{fb.comments}"
                  </p>
                )}

                <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 'auto' }}>
                  Submitted on {new Date(fb.created_at).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 6: EVENT CATEGORIES MANAGEMENT                            */}
      {/* ------------------------------------------------------------- */}
      {activeAdminTab === 'categories' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div className="glass-panel" style={{ padding: 22 }}>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 6, display: 'flex', alignItems: 'center', gap: 8 }}>
              <FolderPlus size={20} color="#38bdf8" />
              <span>Create New Event Category</span>
            </h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
              Add new categories into the MySQL database to group hackathons, technical conferences, or campus contests.
            </p>

            {catSuccess && (
              <div style={{
                background: 'rgba(16, 185, 129, 0.15)',
                border: '1px solid rgba(16, 185, 129, 0.4)',
                borderRadius: 8,
                padding: '10px 14px',
                fontSize: 13,
                color: '#34d399',
                marginBottom: 14,
                display: 'flex',
                alignItems: 'center',
                gap: 8
              }}>
                <CheckCircle size={16} />
                <span>{catSuccess}</span>
              </div>
            )}

            <form onSubmit={handleCreateCategory} style={{ display: 'grid', gridTemplateColumns: '1fr 2fr auto', gap: 12, alignItems: 'flex-end' }}>
              <div>
                <label className="input-label">Category Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AI Summits, Robotics"
                  className="input-field"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                />
              </div>

              <div>
                <label className="input-label">Category Description</label>
                <input
                  type="text"
                  placeholder="e.g. State-level student competitions and artificial intelligence symposiums"
                  className="input-field"
                  value={newCatDesc}
                  onChange={(e) => setNewCatDesc(e.target.value)}
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ height: 44, padding: '0 20px', whiteSpace: 'nowrap' }}>
                <Plus size={16} />
                <span>Add Category</span>
              </button>
            </form>
          </div>

          <div className="glass-panel" style={{ padding: 20 }}>
            <h4 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>
              Active Database Categories ({categoriesList.length})
            </h4>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 14 }}>
              {categoriesList.map((cat, idx) => (
                <div
                  key={cat.id || idx}
                  style={{
                    background: 'rgba(255, 255, 255, 0.03)',
                    border: '1px solid var(--border-glass)',
                    borderRadius: 12,
                    padding: 14,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 6
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{cat.name}</span>
                    <span style={{ fontSize: 10, background: 'rgba(99, 102, 241, 0.15)', color: '#818cf8', padding: '2px 8px', borderRadius: 999 }}>
                      ID #{cat.id || idx + 1}
                    </span>
                  </div>
                  <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0, lineHeight: 1.4 }}>
                    {cat.description || 'No description provided.'}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* CREATE / EDIT EVENT MODAL                                     */}
      {/* ------------------------------------------------------------- */}
      {isEventModalOpen && (
        <div className="modal-overlay" onClick={() => setIsEventModalOpen(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 640, padding: 24 }}>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 16 }}>
              {editingEvent ? 'Edit Campus Event' : 'Create New Campus Event'}
            </h3>

            <form onSubmit={handleSaveEvent} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label className="input-label">Event Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AI & Robotics Hackathon 2026"
                  className="input-field"
                  value={eventForm.title}
                  onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div>
                  <label className="input-label">Category</label>
                  <select
                    className="input-field"
                    value={eventForm.category}
                    onChange={(e) => setEventForm({ ...eventForm, category: e.target.value })}
                  >
                    {categoriesList.length > 0 ? (
                      categoriesList.map((c) => (
                        <option key={c.id || c.name} value={c.name}>
                          {c.name}
                        </option>
                      ))
                    ) : (
                      <>
                        <option value="Hackathons">Hackathons</option>
                        <option value="Coding Contests">Coding Contests</option>
                        <option value="Workshops">Workshops</option>
                        <option value="Tech Talks">Tech Talks</option>
                        <option value="Conferences">Conferences</option>
                        <option value="Seminars">Seminars</option>
                        <option value="Cultural Events">Cultural Events</option>
                        <option value="Music Events">Music Events</option>
                        <option value="Sports Events">Sports Events</option>
                        <option value="Business Events">Business Events</option>
                      </>
                    )}
                  </select>
                </div>

                <div>
                  <label className="input-label">Ticket Fee (₹, 0 for Free)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    className="input-field"
                    value={eventForm.price}
                    onChange={(e) => setEventForm({ ...eventForm, price: e.target.value })}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
                <div>
                  <label className="input-label">Event Date</label>
                  <input
                    type="date"
                    required
                    className="input-field"
                    value={eventForm.event_date}
                    onChange={(e) => setEventForm({ ...eventForm, event_date: e.target.value })}
                  />
                </div>
                <div>
                  <label className="input-label">Start Time</label>
                  <input
                    type="time"
                    required
                    className="input-field"
                    value={eventForm.start_time}
                    onChange={(e) => setEventForm({ ...eventForm, start_time: e.target.value })}
                  />
                </div>
                <div>
                  <label className="input-label">End Time</label>
                  <input
                    type="time"
                    required
                    className="input-field"
                    value={eventForm.end_time}
                    onChange={(e) => setEventForm({ ...eventForm, end_time: e.target.value })}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12 }}>
                <div>
                  <label className="input-label">Venue Location</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Auditorium Hall A, Tech Wing"
                    className="input-field"
                    value={eventForm.venue}
                    onChange={(e) => setEventForm({ ...eventForm, venue: e.target.value })}
                  />
                </div>
                <div>
                  <label className="input-label">Total Capacity</label>
                  <input
                    type="number"
                    required
                    min="1"
                    className="input-field"
                    value={eventForm.total_capacity}
                    onChange={(e) => setEventForm({ ...eventForm, total_capacity: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="input-label">Banner Image URL</label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/..."
                  className="input-field"
                  value={eventForm.banner_url}
                  onChange={(e) => setEventForm({ ...eventForm, banner_url: e.target.value })}
                />
              </div>

              <div>
                <label className="input-label">Event Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Comprehensive event details and benefits for attendees..."
                  className="input-field"
                  value={eventForm.description}
                  onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
                />
              </div>

              <div>
                <label className="input-label">Schedule Breakdown (One per line)</label>
                <textarea
                  rows={3}
                  placeholder="09:30 AM - Keynote Address&#10;11:00 AM - Live Workshop"
                  className="input-field"
                  value={eventForm.schedule}
                  onChange={(e) => setEventForm({ ...eventForm, schedule: e.target.value })}
                />
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <input
                  type="checkbox"
                  id="publishCheckbox"
                  checked={eventForm.is_published}
                  onChange={(e) => setEventForm({ ...eventForm, is_published: e.target.checked })}
                  style={{ width: 18, height: 18 }}
                />
                <label htmlFor="publishCheckbox" style={{ fontSize: 13, cursor: 'pointer' }}>
                  Publish immediately (visible to attendees for booking)
                </label>
              </div>

              <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                <button
                  type="button"
                  onClick={() => setIsEventModalOpen(false)}
                  className="btn btn-secondary"
                  style={{ flex: 1 }}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" style={{ flex: 1 }}>
                  {editingEvent ? 'Save Changes' : 'Create Event'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
