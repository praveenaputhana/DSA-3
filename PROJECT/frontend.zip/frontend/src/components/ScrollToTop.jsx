import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

/**
 * ScrollToTop Component
 * Resets the window and document scroll position to the top (0, 0)
 * on every page navigation and route change.
 */
export default function ScrollToTop() {
  const { pathname, search } = useLocation();

  useEffect(() => {
    // Reset window scroll immediately
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'instant'
    });

    // Reset document elements as well for cross-browser reliability
    if (document.documentElement) {
      document.documentElement.scrollTop = 0;
    }
    if (document.body) {
      document.body.scrollTop = 0;
    }
  }, [pathname, search]);

  return null;
}
